import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const trackingModule = readFileSync(new URL('../public/loan-tracking.js', import.meta.url), 'utf8');
const trackingUrl = `data:text/javascript;base64,${Buffer.from(trackingModule).toString('base64')}`;
const { getLoanDueStatus } = await import(trackingUrl);

test('getLoanDueStatus uses the end time on the due date', () => {
  const loan = {
    dueDate: '2026-11-16',
    endTime: '15:30:00',
    isConsumable: false,
    outstanding: 1
  };

  assert.equal(getLoanDueStatus([loan], new Date(2026, 10, 16, 15, 29)), 'due-soon');
  assert.equal(getLoanDueStatus([loan], new Date(2026, 10, 16, 15, 30)), 'due-soon');
  assert.equal(getLoanDueStatus([loan], new Date(2026, 10, 16, 15, 31)), 'overdue');
});

test('getLoanDueStatus preserves end-of-day deadlines for legacy loans without end times', () => {
  const loan = {
    dueDate: '2026-11-16',
    isConsumable: false,
    outstanding: 1
  };

  assert.equal(getLoanDueStatus([loan], new Date(2026, 10, 16, 23, 59, 59)), 'due-soon');
  assert.equal(getLoanDueStatus([loan], new Date(2026, 10, 17, 0, 0)), 'overdue');
});

test('getLoanDueStatus marks deadlines beyond seven days as pending', () => {
  const loan = {
    dueDate: '2026-11-24',
    endTime: '15:30:00',
    isConsumable: false,
    outstanding: 1
  };

  assert.equal(getLoanDueStatus([loan], new Date(2026, 10, 16, 15, 30)), 'pending');
});
