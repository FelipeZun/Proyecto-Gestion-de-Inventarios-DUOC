const test = require('node:test');
const assert = require('node:assert/strict');
const {
  parseProduct,
  parseClient,
  parseLoan,
  parseInvoice,
  normalizeSupplierRut,
  parseWriteOff,
  parseUserCredentials,
  requireAdmin,
  isValidProductId
} = require('../server');

test('requireAdmin rejects non-admin sessions and permits administrator sessions', () => {
  const response = {
    statusCode: null,
    body: null,
    status(statusCode) {
      this.statusCode = statusCode;
      return this;
    },
    json(body) {
      this.body = body;
      return this;
    }
  };
  let nextCalled = false;

  requireAdmin({ session: { isAdmin: false } }, response, () => {
    nextCalled = true;
  });
  assert.equal(response.statusCode, 403);
  assert.equal(nextCalled, false);

  requireAdmin({ session: { isAdmin: true } }, response, () => {
    nextCalled = true;
  });
  assert.equal(nextCalled, true);
});

test('parseUserCredentials normalizes email and validates initial password', () => {
  assert.deepEqual(
    parseUserCredentials({ email: ' New.User@Example.com ', password: 'a-secure-password' }),
    { email: 'new.user@example.com', password: 'a-secure-password' }
  );
  assert.match(parseUserCredentials({ email: 'invalid', password: 'a-secure-password' }), /correo/i);
  assert.match(parseUserCredentials({ email: 'user@example.com', password: 'short' }), /contraseña/i);
  assert.match(
    parseUserCredentials({ email: 'user@example.com', password: 'é'.repeat(37) }),
    /contraseña/i
  );
});

test('normalizeSupplierRut validates and formats Chilean supplier RUTs', () => {
  assert.equal(normalizeSupplierRut('123456785'), '12.345.678-5');
  assert.equal(normalizeSupplierRut('12.345.678-5'), '12.345.678-5');
  assert.equal(normalizeSupplierRut('76.543.210-3'), '76.543.210-3');
  assert.equal(normalizeSupplierRut('12.345.678-9'), null);
  assert.equal(normalizeSupplierRut('1234567A'), null);
  assert.equal(normalizeSupplierRut('123456'), null);
});

test('parseInvoice validates provider RUT and invoice number', () => {
  assert.deepEqual(parseInvoice({
    supplierRut: '123456785',
    invoiceNumber: ' F-001 '
  }), {
    supplierRut: '12.345.678-5',
    invoiceNumber: 'F-001'
  });
  assert.match(parseInvoice({ supplierRut: '12.345.678-9', invoiceNumber: 'F-001' }), /RUT/i);
  assert.match(parseInvoice({ supplierRut: '12.345.678-5', invoiceNumber: '' }), /número de factura/i);
  assert.match(parseInvoice({
    supplierRut: '12.345.678-5',
    invoiceNumber: 'x'.repeat(101)
  }), /número de factura/i);
});

test('parseClient validates name, Chilean RUT, email, and allowed areas', () => {
  const validClient = {
    name: 'Ana Pérez',
    rut: '12.345.678-5',
    email: 'ana@example.cl',
    area: 'Pañolero'
  };
  assert.equal(parseClient(validClient).area, 'Pañolero');
  assert.deepEqual(parseClient({
    name: '  Ana Pérez ',
    rut: '123456785',
    email: ' ANA@EXAMPLE.CL ',
    area: 'Estudiante'
  }), {
    name: 'Ana Pérez',
    rut: '12.345.678-5',
    email: 'ana@example.cl',
    area: 'Estudiante'
  });
  assert.match(parseClient({
    name: 'Ana Pérez',
    rut: '12.345.678-9',
    email: 'ana@example.cl',
    area: 'Estudiante'
  }), /RUT/i);
  assert.match(parseClient({
    name: 'Ana Pérez',
    rut: '12.345.678-5',
    email: 'correo-inválido',
    area: 'Estudiante'
  }), /correo/i);
  assert.match(parseClient({
    name: 'Ana Pérez',
    rut: '12.345.678-5',
    email: 'ana@example.cl',
    area: 'Visitante'
  }), /área/i);
});

test('parseWriteOff validates product, date, location, quantity, and reason', () => {
  assert.deepEqual(parseWriteOff({
    productId: '23',
    date: '2026-11-16',
    location: 'Bodega central, estante 4',
    quantity: 2,
    reason: 'Producto dañado',
    observation: 'No tiene reparación'
  }), {
    productId: '23',
    date: '2026-11-16',
    location: 'Bodega central, estante 4',
    quantity: 2,
    reason: 'Producto dañado',
    observation: 'No tiene reparación'
  });
  assert.match(parseWriteOff({
    productId: '0',
    date: '2026-11-16',
    location: 'Bodega',
    quantity: 1,
    reason: 'Dañado'
  }), /producto/i);
  assert.match(parseWriteOff({
    productId: '23',
    date: '2026-02-30',
    location: 'Bodega',
    quantity: 1,
    reason: 'Dañado'
  }), /fecha/i);
  assert.match(parseWriteOff({
    productId: '23',
    date: '2026-11-16',
    location: '',
    quantity: 1,
    reason: 'Dañado'
  }), /ubicación/i);
  assert.match(parseWriteOff({
    productId: '23',
    date: '2026-11-16',
    location: 'Bodega',
    quantity: 0,
    reason: 'Dañado'
  }), /cantidad/i);
  assert.match(parseWriteOff({
    productId: '23',
    date: '2026-11-16',
    location: 'Bodega',
    quantity: 1,
    reason: ''
  }), /razón/i);
});

test('parseProduct accepts valid product details', () => {
  assert.deepEqual(
    parseProduct({
      name: 'Wireless Mouse',
      barcode: '1234567890123',
      campusId: '1',
      category: 'Accessories',
      categoryId: null,
      subcategoryId: null,
      unitOfMeasure: 'Unidades',
      supplier: 'Northpeak',
      stock: 12,
      reorderLevel: 3,
      price: 18.5,
      isConsumable: false,
      state: 'Disponible',
      quality: 'Buena',
      characteristics: 'Wireless, ergonomic design',
      description: 'Wireless mouse suitable for daily office use.',
      imageData: null,
      imageMimeType: null
    }),
    {
      name: 'Wireless Mouse',
      barcode: '1234567890123',
      campusId: '1',
      category: 'Accessories',
      categoryId: null,
      subcategoryId: null,
      unitOfMeasure: 'Unidades',
      supplier: 'Northpeak',
      stock: 12,
      reorderLevel: 3,
      price: 18.5,
      isConsumable: false,
      state: 'Disponible',
      quality: 'Buena',
      characteristics: 'Wireless, ergonomic design',
      description: 'Wireless mouse suitable for daily office use.',
      imageData: null,
      imageMimeType: null
    }
  );
});

test('parseProduct accepts fungible products with valid state and quality', () => {
  const product = parseProduct({
    name: 'Cleaning solution',
    campusId: '1',
    category: 'Maintenance',
    supplier: 'Northpeak',
    stock: 4,
    reorderLevel: 1,
    price: 2.5,
    isConsumable: true,
    state: 'Disponible',
    quality: 'Regular'
  });

  assert.equal(product.isConsumable, true);
  assert.equal(product.state, 'Disponible');
  assert.equal(product.quality, 'Regular');
});

test('parseProduct rejects invalid stock values and oversized fields', () => {
  const validProduct = {
    name: 'Wireless Mouse',
    campusId: '1',
    category: 'Accessories',
    supplier: 'Northpeak',
    stock: 12,
    reorderLevel: 3,
    price: 18.5
  };

  assert.match(parseProduct({ ...validProduct, stock: -1 }), /stock/i);
  assert.match(parseProduct({ ...validProduct, stock: 1.5 }), /stock/i);
  assert.match(parseProduct({ ...validProduct, price: 1.001 }), /precio/i);
  assert.match(parseProduct({ ...validProduct, name: 'x'.repeat(161) }), /nombre/i);
  assert.match(parseProduct({ ...validProduct, campusId: 'inválido' }), /sede/i);
  assert.match(parseProduct({ ...validProduct, isConsumable: 'yes' }), /fungible/i);
  assert.match(parseProduct({ ...validProduct, state: 'Lost' }), /estado/i);
  assert.match(parseProduct({ ...validProduct, quality: 'Perfect' }), /calidad/i);
  assert.match(parseProduct({ ...validProduct, characteristics: 'x'.repeat(2001) }), /características/i);
  assert.match(parseProduct({ ...validProduct, description: 'x'.repeat(5001) }), /descripción/i);
});

test('parseProduct defaults optional text and product attributes when omitted', () => {
  const product = parseProduct({
    name: 'Basic product',
    campusId: '1',
    category: 'Office',
    supplier: 'Northpeak',
    stock: 1,
    reorderLevel: 0,
    price: 1
  });

  assert.equal(product.isConsumable, false);
  assert.equal(product.state, 'Disponible');
  assert.equal(product.quality, 'Buena');
  assert.equal(product.characteristics, '');
  assert.equal(product.description, '');
  assert.equal(product.imageData, null);
  assert.equal(product.imageMimeType, null);
  assert.equal(product.unitOfMeasure, 'Unidades');
  assert.equal(product.barcode, '');
});

test('parseProduct validates optional barcode text and length', () => {
  const validProduct = {
    name: 'Basic product',
    campusId: '1',
    category: 'Office',
    supplier: 'Northpeak',
    stock: 1,
    reorderLevel: 0,
    price: 1
  };

  assert.equal(parseProduct({ ...validProduct, barcode: '  12345  ' }).barcode, '12345');
  assert.match(parseProduct({ ...validProduct, barcode: 12345 }), /código de barras/i);
  assert.match(parseProduct({ ...validProduct, barcode: 'x'.repeat(81) }), /código de barras/i);
});

test('parseProduct accepts taxonomy identifiers and validates unit name format', () => {
  const product = parseProduct({
    name: 'Copper wire',
    campusId: '1',
    category: 'Material',
    categoryId: '4',
    subcategoryId: '12',
    unitOfMeasure: 'Metros',
    supplier: 'Northpeak',
    stock: 5,
    reorderLevel: 1,
    price: 2
  });

  assert.equal(product.categoryId, '4');
  assert.equal(product.subcategoryId, '12');
  assert.equal(product.unitOfMeasure, 'Metros');
  assert.match(parseProduct({
    name: 'Copper wire',
    campusId: '1',
    category: 'Material',
    categoryId: 'invalid',
    unitOfMeasure: 'Metros',
    supplier: 'Northpeak',
    stock: 5,
    reorderLevel: 1,
    price: 2
  }), /categoría/i);
  assert.match(parseProduct({
    name: 'Copper wire',
    campusId: '1',
    category: 'Material',
    unitOfMeasure: 'x'.repeat(21),
    supplier: 'Northpeak',
    stock: 5,
    reorderLevel: 1,
    price: 2
  }), /unidad de medida/i);
  assert.match(parseProduct({
    name: 'Copper wire',
    campusId: '1',
    category: 'Material',
    unitOfMeasure: '',
    supplier: 'Northpeak',
    stock: 5,
    reorderLevel: 1,
    price: 2
  }), /unidad de medida/i);
});

test('parseProduct validates uploaded image type, encoding, and size', () => {
  const validProduct = {
    name: 'Image product',
    campusId: '1',
    category: 'Office',
    supplier: 'Northpeak',
    stock: 1,
    reorderLevel: 0,
    price: 1
  };
  const product = parseProduct({
    ...validProduct,
    imageData: 'iVBORw0KGgo=',
    imageMimeType: 'image/png'
  });

  assert.equal(product.imageMimeType, 'image/png');
  assert.match(parseProduct({
    ...validProduct,
    imageData: 'bm90IGFuIGltYWdl',
    imageMimeType: 'image/png'
  }), /contenido/i);
  assert.match(parseProduct({
    ...validProduct,
    imageData: 'a'.repeat(2_800_000),
    imageMimeType: 'image/jpeg'
  }), /tamaño máximo de 2 MB/i);
});

test('parseLoan accepts valid loan details', () => {
  assert.deepEqual(
    parseLoan({
      campusId: '1',
      journey: 'Vespertina',
      loanDate: '2026-11-11',
      startTime: '09:30',
      endTime: '17:00',
      dueDate: '2026-11-15',
      rut: '12.345.678-5',
      area: 'Laboratory',
      subject: 'Physics',
      items: [{ productId: '23', quantity: 2 }]
    }),
    {
      campusId: '1',
      careerId: null,
      subjectId: null,
      clientId: null,
      journey: 'Vespertina',
      loanDate: '2026-11-11',
      dueDate: '2026-11-15',
      startTime: '09:30',
      endTime: '17:00',
      rut: '12.345.678-5',
      area: 'Laboratory',
      subject: 'Physics',
      items: [{ productId: '23', quantity: 2 }]
    }
  );
  assert.deepEqual(
    parseLoan({
      campusId: '1',
      journey: 'Vespertina',
      loanDate: '2026-11-11',
      startTime: '09:30',
      endTime: '17:00',
      dueDate: '2026-11-15',
      rut: '12.345.678-5',
      area: 'Laboratory',
      subject: 'Physics',
      productId: '23',
      quantity: 2
    }).items,
    [{ productId: '23', quantity: 2 }]
  );
});

test('parseLoan rejects invalid dates, products, quantities, and oversized text', () => {
  const validLoan = {
    campusId: '1',
    journey: 'Diurna',
    loanDate: '2026-11-11',
    startTime: '09:30',
    endTime: '17:00',
    dueDate: '2026-11-15',
    rut: '12.345.678-5',
    area: 'Laboratory',
    subject: 'Physics',
    productId: '23',
    quantity: 2
  };

  assert.match(parseLoan({ ...validLoan, loanDate: '2026-02-30' }), /fecha/i);
  assert.match(parseLoan({ ...validLoan, dueDate: '2026-02-30' }), /fecha límite/i);
  assert.match(parseLoan({ ...validLoan, dueDate: '2026-11-10' }), /anterior/i);
  assert.equal(parseLoan({ ...validLoan, dueDate: '' }).dueDate, null);
  assert.match(parseLoan({ ...validLoan, startTime: '24:00' }), /hora de inicio/i);
  assert.match(parseLoan({ ...validLoan, endTime: '25:00' }), /hora de término/i);
  assert.match(parseLoan({
    ...validLoan,
    dueDate: '2026-11-11',
    endTime: '09:30'
  }), /posterior a la hora de inicio/i);
  assert.equal(parseLoan({ ...validLoan, journey: undefined }).journey, 'Sin especificar');
  assert.match(parseLoan({ ...validLoan, journey: 'Nocturna' }), /jornada/i);
  assert.match(parseLoan({ ...validLoan, campusId: 'inválido' }), /sede/i);
  assert.match(parseLoan({ ...validLoan, productId: '0' }), /producto/i);
  assert.match(parseLoan({ ...validLoan, quantity: 0 }), /cantidad/i);
  assert.match(parseLoan({ ...validLoan, area: 'x'.repeat(121) }), /área/i);
  assert.match(parseLoan({ ...validLoan, rut: '12.345.678-9' }), /RUT chileno válido/i);
  assert.equal(parseLoan({ ...validLoan, rut: '123456785' }).rut, '12.345.678-5');
});

test('parseLoan validates optional career and subject references', () => {
  const validLoan = {
    campusId: '1',
    journey: 'Diurna',
    loanDate: '2026-11-11',
    startTime: '09:30',
    endTime: '17:00',
    rut: '12.345.678-5',
    area: 'Laboratory',
    items: [{ productId: '23', quantity: 1 }]
  };

  assert.deepEqual(parseLoan(validLoan), {
    campusId: '1',
    careerId: null,
    subjectId: null,
    clientId: null,
    loanDate: '2026-11-11',
    dueDate: null,
    startTime: '09:30',
    endTime: '17:00',
    journey: 'Diurna',
    rut: '12.345.678-5',
    area: 'Laboratory',
    subject: '',
    items: [{ productId: '23', quantity: 1 }]
  });
  assert.equal(parseLoan({ ...validLoan, careerId: '3', subjectId: '8' }).careerId, '3');
  assert.deepEqual(parseLoan({
    ...validLoan,
    clientId: '4',
    rut: '',
    area: ''
  }).clientId, '4');
  assert.match(parseLoan({ ...validLoan, clientId: '0' }), /cliente/i);
  assert.match(parseLoan({ ...validLoan, careerId: '0' }), /carrera/i);
  assert.match(parseLoan({ ...validLoan, subjectId: '0' }), /asignatura/i);
  assert.match(parseLoan({ ...validLoan, subjectId: '8' }), /carrera/i);
  assert.match(parseLoan({ ...validLoan, subject: 'x'.repeat(161) }), /asignatura/i);
});

test('parseLoan accepts multiple unique products and rejects invalid product lines', () => {
  const multiProductLoan = {
    campusId: '1',
    journey: 'Vespertina',
    loanDate: '2026-11-11',
    startTime: '09:30',
    endTime: '17:00',
    dueDate: '2026-11-15',
    rut: '12.345.678-5',
    area: 'Laboratory',
    subject: 'Physics',
    items: [
      { productId: '23', quantity: 2 },
      { productId: '24', quantity: 1 }
    ]
  };
  assert.deepEqual(parseLoan(multiProductLoan).items, multiProductLoan.items);
  assert.match(parseLoan({
    ...multiProductLoan,
    items: [...multiProductLoan.items, { productId: '23', quantity: 1 }]
  }), /repitas un producto/i);
  assert.match(parseLoan({
    ...multiProductLoan,
    items: [{ productId: '24', quantity: 0 }]
  }), /cantidad/i);
  assert.match(parseLoan({ ...multiProductLoan, items: [] }), /entre 1 y 50/i);
  assert.match(parseLoan({
    ...multiProductLoan,
    items: Array.from({ length: 51 }, (_, index) => ({
      productId: String(index + 1),
      quantity: 1
    }))
  }), /entre 1 y 50/i);
});

test('isValidProductId only accepts positive PostgreSQL bigint identifiers', () => {
  assert.equal(isValidProductId('1'), true);
  assert.equal(isValidProductId('9223372036854775807'), true);
  assert.equal(isValidProductId('0'), false);
  assert.equal(isValidProductId('-1'), false);
  assert.equal(isValidProductId('9223372036854775808'), false);
  assert.equal(isValidProductId('1; DELETE FROM products'), false);
});
