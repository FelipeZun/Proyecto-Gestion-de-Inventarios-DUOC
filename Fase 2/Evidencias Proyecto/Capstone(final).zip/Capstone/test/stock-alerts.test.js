const test = require('node:test');
const assert = require('node:assert/strict');
const {
  createStockAlertMessage,
  getStockAlertLevel,
  shouldQueueStockAlert
} = require('../stock-alerts');

test('getStockAlertLevel distinguishes adequate, low, and zero stock', () => {
  assert.equal(getStockAlertLevel(11, 10), 'normal');
  assert.equal(getStockAlertLevel(10, 10), 'low');
  assert.equal(getStockAlertLevel(1, 10), 'low');
  assert.equal(getStockAlertLevel(0, 0), 'out');
  assert.throws(() => getStockAlertLevel(-1, 10), /enteros no negativos/);
});

test('shouldQueueStockAlert sends on low/out transitions but waits for recovery before repeating', () => {
  assert.equal(shouldQueueStockAlert('normal', 'low'), true);
  assert.equal(shouldQueueStockAlert('normal', 'out'), true);
  assert.equal(shouldQueueStockAlert('low', 'out'), true);
  assert.equal(shouldQueueStockAlert('out', 'low'), false);
  assert.equal(shouldQueueStockAlert('low', 'low'), false);
  assert.equal(shouldQueueStockAlert('out', 'normal'), false);
  assert.equal(shouldQueueStockAlert('normal', 'normal'), false);
});

test('createStockAlertMessage escapes product data and describes the alert', () => {
  const message = createStockAlertMessage({
    alertLevel: 'out',
    productName: '<Proyector>',
    productCode: 'SKU-123',
    stock: 0,
    reorderLevel: 2,
    campusName: 'Plaza Oeste'
  });
  assert.equal(message.subject, 'Sin existencias: <Proyector>');
  assert.match(message.text, /Existencias actuales: 0/);
  assert.match(message.html, /&lt;Proyector&gt;/);
  assert.doesNotMatch(message.html, /<Proyector>/);
  assert.equal(createStockAlertMessage({
    alertLevel: 'low',
    productName: 'Producto\r\nBcc: atacante@example.com',
    productCode: 'SKU-124',
    stock: 1,
    reorderLevel: 2
  }).subject, 'Stock bajo: Producto Bcc: atacante@example.com');
});
