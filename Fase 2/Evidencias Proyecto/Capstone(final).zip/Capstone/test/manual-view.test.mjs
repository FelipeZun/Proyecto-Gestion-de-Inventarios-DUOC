import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const manualModule = readFileSync(new URL('../public/manual-view.js', import.meta.url), 'utf8');
const manualUrl = `data:text/javascript;base64,${Buffer.from(manualModule).toString('base64')}`;
const { renderManualMarkdown } = await import(manualUrl);

test('renderManualMarkdown formats manual blocks and escapes HTML', () => {
  const html = renderManualMarkdown([
    '# Manual',
    '',
    'Párrafo con **énfasis** y `código`.',
    '',
    '- Primer elemento',
    '- Segundo elemento',
    '',
    '1. Paso uno',
    '2. Paso dos',
    '',
    '<script>alert(1)</script>'
  ].join('\n'));

  assert.match(html, /<h2>Manual<\/h2>/);
  assert.match(html, /<strong>énfasis<\/strong>/);
  assert.match(html, /<code>código<\/code>/);
  assert.match(html, /<ul>[\s\S]*<li>Primer elemento<\/li>[\s\S]*<\/ul>/);
  assert.match(html, /<ol>[\s\S]*<li>Paso uno<\/li>[\s\S]*<\/ol>/);
  assert.match(html, /&lt;script&gt;alert\(1\)&lt;\/script&gt;/);
  assert.doesNotMatch(html, /<script>/);
});
