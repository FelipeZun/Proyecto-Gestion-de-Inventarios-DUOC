const test = require('node:test');
const assert = require('node:assert/strict');
const ExcelJS = require('exceljs');
const {
  createWorkbook,
  readImportWorkbook,
  MAX_IMPORT_ROWS
} = require('../spreadsheet-transfer');

async function workbookBuffer(type, rows, headers) {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Importación');
  worksheet.addRow(headers);
  for (const row of rows) worksheet.addRow(row);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

test('createWorkbook produces import-compatible client and product worksheets', async () => {
  const clientsBuffer = await createWorkbook('clients', [{
    name: 'Ana Pérez',
    rut: '12.345.678-5',
    email: 'ana@example.cl',
    area: 'Estudiante'
  }]);
  const clients = await readImportWorkbook(clientsBuffer, 'clients');
  assert.deepEqual(clients, [{
    rowNumber: 2,
    record: {
      name: 'Ana Pérez',
      rut: '12.345.678-5',
      email: 'ana@example.cl',
      area: 'Estudiante'
    }
  }]);

  const productsBuffer = await createWorkbook('products', [{
    name: 'Microscopio',
    campus: 'Plaza Oeste',
    category: 'Dispositivo',
    unitOfMeasure: 'Unidades',
    stock: 3,
    reorderLevel: 1,
    price: 25000,
    supplier: 'Proveedor',
    isConsumable: false,
    state: 'Disponible',
    quality: 'Buena',
    code: 'SKU-123',
    isArchived: true
  }]);
  const products = await readImportWorkbook(productsBuffer, 'products');
  assert.equal(products.length, 1);
  assert.equal(products[0].record.name, 'Microscopio');
  assert.equal(products[0].record.campus, 'Plaza Oeste');
  assert.equal(products[0].record.isConsumable, false);
  assert.equal(products[0].record.isArchived, true);
  assert.equal(products[0].record.price, 25000);
});

test('readImportWorkbook accepts accents in headers and rejects missing columns or formulas', async () => {
  const headers = ['Nombre', 'RUT', 'Correo', 'Área'];
  const clientsBuffer = await workbookBuffer('clients', [
    ['Ana Pérez', '12.345.678-5', 'ana@example.cl', 'Pañolero']
  ], headers);
  assert.equal((await readImportWorkbook(clientsBuffer, 'clients'))[0].record.area, 'Pañolero');

  const missingColumnBuffer = await workbookBuffer('clients', [], ['Nombre', 'RUT']);
  await assert.rejects(readImportWorkbook(missingColumnBuffer, 'clients'), /Faltan columnas requeridas/);

  const formulaWorkbook = new ExcelJS.Workbook();
  const worksheet = formulaWorkbook.addWorksheet('Clientes');
  worksheet.addRow(headers);
  worksheet.addRow(['Ana Pérez', '12.345.678-5', { formula: '1+1' }, 'Estudiante']);
  const formulaBuffer = Buffer.from(await formulaWorkbook.xlsx.writeBuffer());
  await assert.rejects(readImportWorkbook(formulaBuffer, 'clients'), /contiene fórmulas/);
});

test('readImportWorkbook rejects damaged workbooks, unsupported types, and excessive rows', async () => {
  await assert.rejects(readImportWorkbook(Buffer.from('not an xlsx'), 'clients'), /no se pudo leer/i);
  await assert.rejects(readImportWorkbook(Buffer.from('xlsx'), 'unknown'), /tipo de planilla/i);

  const headers = ['Nombre', 'RUT', 'Correo', 'Área'];
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet('Clientes');
  worksheet.addRow(headers);
  for (let row = 0; row <= MAX_IMPORT_ROWS; row += 1) {
    worksheet.addRow([`Cliente ${row}`, `rut${row}`, 'mail@example.cl', 'Estudiante']);
  }
  const buffer = Buffer.from(await workbook.xlsx.writeBuffer());
  await assert.rejects(readImportWorkbook(buffer, 'clients'), /máximo de 500 filas/);
});
