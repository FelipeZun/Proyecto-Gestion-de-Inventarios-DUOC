import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import test from 'node:test';

const apiModule = readFileSync(new URL('../public/api.js', import.meta.url), 'utf8');
const apiUrl = `data:text/javascript;base64,${Buffer.from(apiModule).toString('base64')}`;
const { normalizeChileanRut } = await import(apiUrl);

test('normalizeChileanRut formats valid RUTs and rejects an invalid verifier', () => {
  assert.equal(normalizeChileanRut('123456785'), '12.345.678-5');
  assert.equal(normalizeChileanRut('1000005k'), '1.000.005-K');
  assert.equal(normalizeChileanRut('12.345.678-9'), null);
  assert.equal(normalizeChileanRut('123456'), null);
});
