function getStockAlertLevel(stock, reorderLevel) {
  const quantity = Number(stock);
  const threshold = Number(reorderLevel);
  if (!Number.isSafeInteger(quantity) || quantity < 0 ||
      !Number.isSafeInteger(threshold) || threshold < 0) {
    throw new Error('Las existencias y el nivel de reposición deben ser enteros no negativos.');
  }
  if (quantity === 0) return 'out';
  return quantity <= threshold ? 'low' : 'normal';
}

function shouldQueueStockAlert(previousLevel, currentLevel) {
  return currentLevel !== 'normal' &&
    (previousLevel === 'normal' || (previousLevel === 'low' && currentLevel === 'out'));
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (character) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  })[character]);
}

function createStockAlertMessage(event) {
  const isOut = event.alertLevel === 'out';
  const status = isOut ? 'Sin existencias' : 'Stock bajo';
  const productName = String(event.productName).replace(/[\r\n]+/g, ' ');
  const subject = `${status}: ${productName}`;
  const text = [
    `Alerta de inventario StockFlow: ${status.toLocaleLowerCase('es')}.`,
    `Producto: ${event.productName}`,
    `Código interno: ${event.productCode}`,
    `Existencias actuales: ${event.stock}`,
    `Nivel de reposición: ${event.reorderLevel}`,
    `Sede: ${event.campusName || 'Sin sede'}`
  ].join('\n');
  const html = `
    <h2>Alerta de inventario: ${escapeHtml(status)}</h2>
    <p>Un producto requiere atención en StockFlow.</p>
    <ul>
      <li><strong>Producto:</strong> ${escapeHtml(event.productName)}</li>
      <li><strong>Código interno:</strong> ${escapeHtml(event.productCode)}</li>
      <li><strong>Existencias actuales:</strong> ${escapeHtml(event.stock)}</li>
      <li><strong>Nivel de reposición:</strong> ${escapeHtml(event.reorderLevel)}</li>
      <li><strong>Sede:</strong> ${escapeHtml(event.campusName || 'Sin sede')}</li>
    </ul>`;
  return { subject, text, html };
}

module.exports = {
  createStockAlertMessage,
  getStockAlertLevel,
  shouldQueueStockAlert
};
