require('dotenv').config();

const path = require('node:path');
const { readFile } = require('node:fs/promises');
const { randomBytes } = require('node:crypto');
const bcrypt = require('bcryptjs');
const connectPgSimple = require('connect-pg-simple');
const express = require('express');
const session = require('express-session');
const { Pool } = require('pg');
const nodemailer = require('nodemailer');
const {
  MAX_IMPORT_BYTES,
  SPREADSHEET_MIME_TYPE,
  createWorkbook,
  readImportWorkbook
} = require('./spreadsheet-transfer');
const {
  createStockAlertMessage,
  getStockAlertLevel
} = require('./stock-alerts');

const DEFAULT_CATEGORIES = ['Material', 'Dispositivo', 'Herramienta', 'Fungible'];
const DEFAULT_UNITS_OF_MEASURE = ['Metros', 'Unidades', 'Litros', 'Kilos', 'Gramos'];
const CLIENT_AREAS = ['Estudiante', 'Profesor', 'Administración', 'Pañolero'];
const DEFAULT_CAMPUSES = [
  'Alameda',
  'Antonio Varas',
  'Arauco',
  'Concepción',
  'Maipú',
  'Melipilla',
  'Padre Alonso de Ovalle',
  'Plaza Norte',
  'Plaza Oeste',
  'Puerto Montt',
  'Puente Alto',
  'San Andrés',
  'San Bernardo',
  'San Carlos de Apoquindo',
  'San Joaquín',
  'Valparaíso',
  'Viña del Mar',
  'Sede por asignar'
];

if (!process.env.DATABASE_URL) {
  throw new Error('Debes configurar DATABASE_URL en el entorno.');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
const app = express();
const PgSessionStore = connectPgSimple(session);
const isProduction = process.env.NODE_ENV === 'production';
const sessionSecret = process.env.SESSION_SECRET || randomBytes(32).toString('hex');
const sessionCookieOptions = {
  httpOnly: true,
  sameSite: 'lax',
  secure: isProduction,
  maxAge: 1000 * 60 * 60 * 24 * 7
};

app.disable('x-powered-by');
if (isProduction) app.set('trust proxy', 1);
app.use(express.json({ limit: '3mb' }));
app.use(
  session({
    name: 'stockflow.sid',
    store: new PgSessionStore({
      pool,
      createTableIfMissing: true
    }),
    secret: sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: sessionCookieOptions
  })
);

function requireAuth(req, res, next) {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Inicia sesión para continuar.' });
  }
  return next();
}

function requireAdmin(req, res, next) {
  if (!req.session.isAdmin) {
    return res.status(403).json({ error: 'Se requieren permisos de administrador.' });
  }
  return next();
}

function parseUserCredentials(body) {
  body = body && typeof body === 'object' ? body : {};
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body.password === 'string' ? body.password : '';

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return 'Introduce un correo electrónico válido.';
  }
  if (password.length < 10 || Buffer.byteLength(password, 'utf8') > 72) {
    return 'La contraseña debe tener entre 10 y 72 bytes.';
  }

  return { email, password };
}

function normalizeSupplierRut(value) {
  if (typeof value !== 'string') return null;
  const rut = value.replace(/[.\-\s]/g, '').toUpperCase();
  const match = rut.match(/^(\d{7,8})([\dK])$/);
  if (!match) return null;

  const body = match[1];
  const providedVerifier = match[2];
  let multiplier = 2;
  let sum = 0;
  for (let index = body.length - 1; index >= 0; index -= 1) {
    sum += Number(body[index]) * multiplier;
    multiplier = multiplier === 7 ? 2 : multiplier + 1;
  }
  const remainder = 11 - (sum % 11);
  const expectedVerifier = remainder === 11 ? '0' : remainder === 10 ? 'K' : String(remainder);
  if (providedVerifier !== expectedVerifier) return null;

  const formattedBody = body.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${formattedBody}-${expectedVerifier}`;
}

function parseInvoice(body) {
  body = body && typeof body === 'object' ? body : {};
  const supplierRut = normalizeSupplierRut(body.supplierRut);
  const invoiceNumber = typeof body.invoiceNumber === 'string' ? body.invoiceNumber.trim() : '';
  if (!supplierRut) return 'Ingresa un RUT de proveedor válido.';
  if (!invoiceNumber || invoiceNumber.length > 100) {
    return 'El número de factura debe tener entre 1 y 100 caracteres.';
  }
  return { supplierRut, invoiceNumber };
}

function parseWriteOff(body) {
  body = body && typeof body === 'object' ? body : {};
  const productId = body.productId === undefined || body.productId === null
    ? ''
    : String(body.productId);
  const date = typeof body.date === 'string' ? body.date : '';
  const location = typeof body.location === 'string' ? body.location.trim() : '';
  const quantity = Number(body.quantity);
  const reason = typeof body.reason === 'string' ? body.reason.trim() : '';
  const observation = typeof body.observation === 'string' ? body.observation.trim() : '';

  if (!isValidProductId(productId)) return 'Selecciona un producto válido por su código.';
  if (!isValidDateOnly(date)) return 'La fecha de baja no es válida.';
  if (!location || location.length > 160) return 'La ubicación debe tener entre 1 y 160 caracteres.';
  if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 2147483647) {
    return 'La cantidad de baja debe ser un entero positivo.';
  }
  if (!reason || reason.length > 200) return 'La razón debe tener entre 1 y 200 caracteres.';
  if (observation.length > 2000) return 'La observación debe tener como máximo 2000 caracteres.';
  return { productId, date, location, quantity, reason, observation };
}

function parseClient(body) {
  body = body && typeof body === 'object' ? body : {};
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const rut = normalizeSupplierRut(body.rut);
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const area = typeof body.area === 'string' ? body.area.trim() : '';

  if (!name || name.length > 160) return 'El nombre debe tener entre 1 y 160 caracteres.';
  if (!rut) return 'Ingresa un RUT válido.';
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return 'Ingresa un correo electrónico válido.';
  }
  if (!CLIENT_AREAS.includes(area)) return 'Selecciona un área válida.';
  return { name, rut, email, area };
}

function parseProduct(body) {
  body = body && typeof body === 'object' ? body : {};
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  const barcode = body.barcode === undefined || body.barcode === null
    ? ''
    : typeof body.barcode === 'string'
      ? body.barcode.trim()
      : null;
  const category = typeof body.category === 'string' ? body.category.trim() : '';
  const categoryId = body.categoryId === undefined || body.categoryId === null || body.categoryId === ''
    ? null
    : String(body.categoryId);
  const subcategoryId = body.subcategoryId === undefined || body.subcategoryId === null || body.subcategoryId === ''
    ? null
    : String(body.subcategoryId);
  const campusId = body.campusId === undefined || body.campusId === null || body.campusId === ''
    ? null
    : String(body.campusId);
  const unitOfMeasure = body.unitOfMeasure === undefined ? 'Unidades' : body.unitOfMeasure;
  const supplier = typeof body.supplier === 'string' ? body.supplier.trim() : '';
  const characteristics = body.characteristics === undefined ? '' : body.characteristics;
  const description = body.description === undefined ? '' : body.description;
  const imageData = body.imageData === undefined || body.imageData === null || body.imageData === ''
    ? null
    : body.imageData;
  const imageMimeType = body.imageMimeType === undefined || body.imageMimeType === null || body.imageMimeType === ''
    ? null
    : body.imageMimeType;
  const state = body.state === undefined ? 'Disponible' : body.state;
  const quality = body.quality === undefined ? 'Buena' : body.quality;
  const isConsumable = body.isConsumable === undefined ? false : body.isConsumable;
  const stock = Number(body.stock);
  const reorderLevel = Number(body.reorderLevel);
  const price = Number(body.price);

  if (!name || name.length > 160) return 'El nombre debe tener entre 1 y 160 caracteres.';
  if (barcode === null || barcode.length > 80) return 'El código de barras debe ser texto de hasta 80 caracteres.';
  if (!isValidProductId(campusId)) return 'Selecciona una sede válida para el producto.';
  if (!category || category.length > 80) return 'La categoría debe tener entre 1 y 80 caracteres.';
  if (categoryId !== null && !isValidProductId(categoryId)) return 'Selecciona una categoría válida.';
  if (subcategoryId !== null && !isValidProductId(subcategoryId)) return 'Selecciona una subcategoría válida.';
  if (typeof unitOfMeasure !== 'string' || !unitOfMeasure.trim() || unitOfMeasure.length > 20) {
    return 'Selecciona una unidad de medida válida.';
  }
  if (!supplier || supplier.length > 160) return 'El proveedor debe tener entre 1 y 160 caracteres.';
  if (typeof characteristics !== 'string' || characteristics.length > 2000) {
    return 'Las características deben tener como máximo 2000 caracteres.';
  }
  if (typeof description !== 'string' || description.length > 5000) {
    return 'La descripción debe tener como máximo 5000 caracteres.';
  }
  if (imageData !== null && typeof imageData !== 'string') return 'La imagen del producto no es válida.';
  if (imageMimeType !== null && !['image/jpeg', 'image/png', 'image/webp'].includes(imageMimeType)) {
    return 'La imagen debe ser JPEG, PNG o WebP.';
  }
  if ((imageData === null) !== (imageMimeType === null)) {
    return 'Los datos de la imagen están incompletos.';
  }
  if (imageData !== null) {
    if (!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(imageData)) {
      return 'El archivo de imagen está dañado o no es válido.';
    }
    const imageBuffer = Buffer.from(imageData, 'base64');
    if (imageBuffer.length === 0 || imageBuffer.length > 2 * 1024 * 1024 ||
        imageBuffer.toString('base64') !== imageData) {
      return 'La imagen debe tener un tamaño máximo de 2 MB.';
    }
    if (!matchesImageType(imageBuffer, imageMimeType)) return 'El contenido no coincide con el tipo de imagen indicado.';
  }
  if (!['Disponible', 'En reparación', 'En préstamo', 'Dado de baja'].includes(state)) {
    return 'Selecciona un estado válido para el producto.';
  }
  if (!['Excelente', 'Buena', 'Regular', 'Mala'].includes(quality)) {
    return 'Selecciona una calidad válida para el producto.';
  }
  if (typeof isConsumable !== 'boolean') return 'Indica si el producto es fungible.';
  if (!Number.isSafeInteger(stock) || stock < 0) return 'El stock debe ser un entero no negativo.';
  if (!Number.isSafeInteger(reorderLevel) || reorderLevel < 0) {
    return 'El nivel de reposición debe ser un entero no negativo.';
  }
  if (
    !Number.isFinite(price) ||
    price < 0 ||
    price > 99999999.99 ||
    Math.round(price * 100) / 100 !== price
  ) {
    return 'El precio debe ser un número no negativo con hasta dos decimales.';
  }

  return {
    name,
    barcode,
    campusId,
    category,
    categoryId,
    subcategoryId,
    unitOfMeasure: unitOfMeasure.trim(),
    supplier,
    stock,
    reorderLevel,
    price,
    state,
    quality,
    isConsumable,
    characteristics: characteristics.trim(),
    description: description.trim(),
    imageData,
    imageMimeType
  };
}

function serializeProduct(row) {
  return {
    ...row,
    imageData: row.imageData ? Buffer.from(row.imageData).toString('base64') : null
  };
}

function matchesImageType(buffer, mimeType) {
  if (mimeType === 'image/jpeg') {
    return buffer.length >= 3 && buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
  }
  if (mimeType === 'image/png') {
    return buffer.length >= 8 &&
      buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  }
  if (mimeType === 'image/webp') {
    return buffer.length >= 12 &&
      buffer.toString('ascii', 0, 4) === 'RIFF' &&
      buffer.toString('ascii', 8, 12) === 'WEBP';
  }
  return false;
}

function isValidProductId(id) {
  return typeof id === 'string' &&
    /^[1-9]\d{0,18}$/.test(id) &&
    BigInt(id) <= 9223372036854775807n;
}

function isValidDateOnly(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const parsedDate = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(parsedDate.getTime()) &&
    parsedDate.toISOString().slice(0, 10) === value;
}

function parseLoan(body) {
  body = body && typeof body === 'object' ? body : {};
  const loanDate = typeof body.loanDate === 'string' ? body.loanDate : '';
  const dueDate = typeof body.dueDate === 'string' ? body.dueDate : '';
  const startTime = typeof body.startTime === 'string' ? body.startTime : '';
  const endTime = typeof body.endTime === 'string' ? body.endTime : '';
  const journey = body.journey === undefined ? 'Sin especificar' : body.journey;
  const campusId = body.campusId === undefined || body.campusId === null || body.campusId === ''
    ? null
    : String(body.campusId);
  const careerId = body.careerId === undefined || body.careerId === null || body.careerId === ''
    ? null
    : String(body.careerId);
  const subjectId = body.subjectId === undefined || body.subjectId === null || body.subjectId === ''
    ? null
    : String(body.subjectId);
  const clientId = body.clientId === undefined || body.clientId === null || body.clientId === ''
    ? null
    : String(body.clientId);
  const rutInput = typeof body.rut === 'string' ? body.rut.trim() : '';
  const rut = normalizeSupplierRut(rutInput) || '';
  const area = typeof body.area === 'string' ? body.area.trim() : '';
  const subject = typeof body.subject === 'string' ? body.subject.trim() : '';
  const rawItems = Array.isArray(body.items)
    ? body.items
    : [{ productId: body.productId, quantity: body.quantity }];
  if (rawItems.length < 1 || rawItems.length > 50) {
    return 'Un préstamo debe incluir entre 1 y 50 productos.';
  }
  const items = [];
  const productIds = new Set();
  for (const rawItem of rawItems) {
    const item = rawItem && typeof rawItem === 'object' ? rawItem : {};
    const productId = typeof item.productId === 'string' ? item.productId : String(item.productId || '');
    const quantity = Number(item.quantity);
    if (!isValidProductId(productId)) return 'Selecciona un producto válido para cada línea.';
    if (productIds.has(productId)) return 'No repitas un producto en el mismo préstamo.';
    if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 2147483647) {
      return 'La cantidad de cada producto debe ser un entero positivo.';
    }
    productIds.add(productId);
    items.push({ productId, quantity });
  }

  if (!isValidDateOnly(loanDate)) {
    return 'La fecha del préstamo no es válida.';
  }
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(startTime)) {
    return 'Indica una hora de inicio válida.';
  }
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(endTime)) {
    return 'Indica una hora de término válida.';
  }
  if (!['Diurna', 'Vespertina', 'Sin especificar'].includes(journey)) {
    return 'Selecciona una jornada válida para el préstamo.';
  }
  if (!isValidProductId(campusId)) return 'Selecciona una sede válida para el préstamo.';
  if (careerId && !isValidProductId(careerId)) return 'Selecciona una carrera válida para el préstamo.';
  if (subjectId && !isValidProductId(subjectId)) return 'Selecciona una asignatura válida para el préstamo.';
  if (clientId && !isValidProductId(clientId)) return 'Selecciona un cliente válido para el préstamo.';
  if (subjectId && !careerId) return 'Selecciona la carrera asociada a la asignatura.';
  if (dueDate && !isValidDateOnly(dueDate)) return 'La fecha límite de devolución no es válida.';
  if (dueDate && dueDate < loanDate) {
    return 'La fecha límite no puede ser anterior a la fecha del préstamo.';
  }
  if ((!dueDate || dueDate === loanDate) && endTime <= startTime) {
    return 'La hora de término debe ser posterior a la hora de inicio cuando el préstamo vence el mismo día.';
  }
  if (rutInput.length > 20) return 'El RUT debe tener como máximo 20 caracteres.';
  if (!clientId && !rut) return 'Ingresa un RUT chileno válido, incluyendo un dígito verificador correcto.';
  if (!clientId && (!area || area.length > 120)) return 'El área debe tener entre 1 y 120 caracteres.';
  if (clientId && area.length > 120) return 'El área debe tener como máximo 120 caracteres.';
  if (subject.length > 160) return 'La asignatura debe tener como máximo 160 caracteres.';

  return {
    campusId,
    careerId,
    subjectId,
    clientId,
    loanDate,
    dueDate: dueDate || null,
    startTime,
    endTime,
    journey,
    rut,
    area,
    subject,
    items
  };
}

app.get('/api/admin/users', requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, email, role, created_at AS "createdAt"
       FROM users
       WHERE owner_user_id = $1
       ORDER BY role DESC, LOWER(email)`,
      [req.session.userId]
    );
    return res.json({ users: result.rows });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/admin/users', requireAuth, requireAdmin, async (req, res, next) => {
  const credentials = parseUserCredentials(req.body);
  if (typeof credentials === 'string') return res.status(400).json({ error: credentials });

  try {
    const passwordHash = await bcrypt.hash(credentials.password, 12);
    const result = await pool.query(
      `INSERT INTO users (email, password_hash, role, owner_user_id)
       VALUES ($1, $2, 'user', $3)
       RETURNING id, email, role, created_at AS "createdAt"`,
      [credentials.email, passwordHash, req.session.userId]
    );
    return res.status(201).json({ user: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una cuenta con ese correo.' });
    }
    return next(error);
  }
});

app.post('/api/auth/login', async (req, res, next) => {
  const body = req.body && typeof req.body === 'object' ? req.body : {};
  const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
  const password = typeof body.password === 'string' ? body.password : '';
  let result;
  try {
    result = await pool.query(
      'SELECT id, email, password_hash, role, owner_user_id AS "ownerUserId" FROM users WHERE email = $1',
      [email]
    );
  } catch (error) {
    return next(error);
  }
  const user = result.rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ error: 'Correo o contraseña incorrectos.' });
  }

  try {
    await new Promise((resolve, reject) => {
      req.session.regenerate((error) => (error ? reject(error) : resolve()));
    });
    req.session.userId = user.ownerUserId;
    req.session.accountUserId = user.id;
    req.session.isAdmin = user.role === 'admin';
    await new Promise((resolve, reject) => {
      req.session.save((error) => (error ? reject(error) : resolve()));
    });
    return res.json({ user: { id: user.id, email: user.email, isAdmin: user.role === 'admin' } });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/auth/logout', (req, res, next) => {
  req.session.destroy((error) => {
    if (error) return next(error);
    res.clearCookie('stockflow.sid', {
      httpOnly: true,
      sameSite: 'lax',
      secure: isProduction
    });
    return res.status(204).end();
  });
});

app.get('/api/auth/me', async (req, res, next) => {
  if (!req.session.userId) return res.status(401).json({ error: 'No has iniciado sesión.' });

  try {
    const accountUserId = req.session.accountUserId || req.session.userId;
    const result = await pool.query(
      `SELECT id, email, role, owner_user_id AS "ownerUserId"
       FROM users
       WHERE id = $1`,
      [accountUserId]
    );
    if (!result.rows[0]) {
      return req.session.destroy((error) => {
        if (error) return next(error);
        return res.status(401).json({ error: 'La sesión ya no es válida.' });
      });
    }
    const user = result.rows[0];
    req.session.userId = user.ownerUserId;
    req.session.accountUserId = user.id;
    req.session.isAdmin = user.role === 'admin';
    return res.json({
      user: { id: user.id, email: user.email, isAdmin: user.role === 'admin' }
    });
  } catch (error) {
    return next(error);
  }
});

app.get('/api/manual', requireAuth, async (req, res, next) => {
  try {
    const markdown = await readFile(path.join(__dirname, 'MANUAL-USUARIO.md'), 'utf8');
    return res.json({ markdown });
  } catch (error) {
    return next(error);
  }
});

app.get('/api/campuses', requireAuth, async (req, res, next) => {
  try {
    const existing = await pool.query(
      'SELECT 1 FROM campuses WHERE user_id = $1 LIMIT 1',
      [req.session.userId]
    );
    if (!existing.rowCount) {
      await pool.query(
        `INSERT INTO campuses (user_id, name)
         SELECT $1, campus.name
         FROM unnest($2::text[]) AS campus(name)
         ON CONFLICT DO NOTHING`,
        [req.session.userId, DEFAULT_CAMPUSES]
      );
    }
    const result = await pool.query(
      `SELECT c.id, c.name,
              (SELECT COUNT(*) FROM products p
               WHERE p.user_id = c.user_id AND p.campus_id = c.id) +
              (SELECT COUNT(*) FROM loans l
               WHERE l.user_id = c.user_id AND l.campus_id = c.id) AS "usageCount"
       FROM campuses c
       WHERE c.user_id = $1
       ORDER BY c.name`,
      [req.session.userId]
    );
    return res.json({ campuses: result.rows });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/campuses', requireAuth, async (req, res, next) => {
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!name || name.length > 100) {
    return res.status(400).json({ error: 'El nombre de la sede debe tener entre 1 y 100 caracteres.' });
  }

  try {
    const result = await pool.query(
      'INSERT INTO campuses (user_id, name) VALUES ($1, $2) RETURNING id, name',
      [req.session.userId, name]
    );
    return res.status(201).json({ campus: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una sede con ese nombre.' });
    }
    return next(error);
  }
});

app.patch('/api/campuses/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la sede no es válido.' });
  }
  if (!name || name.length > 100) {
    return res.status(400).json({ error: 'El nombre de la sede debe tener entre 1 y 100 caracteres.' });
  }

  try {
    const result = await pool.query(
      'UPDATE campuses SET name = $1 WHERE id = $2 AND user_id = $3 RETURNING id, name',
      [name, id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la sede.' });
    return res.json({ campus: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una sede con ese nombre.' });
    }
    return next(error);
  }
});

app.delete('/api/campuses/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la sede no es válido.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('SELECT id FROM users WHERE id = $1 FOR UPDATE', [req.session.userId]);
    const campusResult = await client.query(
      'SELECT id FROM campuses WHERE id = $1 AND user_id = $2 FOR UPDATE',
      [id, req.session.userId]
    );
    if (!campusResult.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró la sede.' });
    }
    const countResult = await client.query(
      'SELECT COUNT(*) FROM campuses WHERE user_id = $1',
      [req.session.userId]
    );
    if (Number(countResult.rows[0].count) <= 1) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Debe conservar al menos una sede.' });
    }
    const usageResult = await client.query(
      `SELECT EXISTS (SELECT 1 FROM products WHERE user_id = $1 AND campus_id = $2)
            OR EXISTS (SELECT 1 FROM loans WHERE user_id = $1 AND campus_id = $2) AS "isInUse"`,
      [req.session.userId, id]
    );
    if (usageResult.rows[0].isInUse) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'No se puede eliminar una sede asignada a productos o préstamos.' });
    }
    await client.query('DELETE FROM campuses WHERE id = $1 AND user_id = $2', [id, req.session.userId]);
    await client.query('COMMIT');
    return res.status(204).end();
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23503') {
      return res.status(409).json({ error: 'No se puede eliminar una sede asignada a productos o préstamos.' });
    }
    return next(error);
  } finally {
    client.release();
  }
});

app.get('/api/academic-catalog', requireAuth, async (req, res, next) => {
  try {
    const [careerResult, subjectResult] = await Promise.all([
      pool.query(
        `SELECT id, name
         FROM academic_programs
         WHERE user_id = $1
         ORDER BY name`,
        [req.session.userId]
      ),
      pool.query(
        `SELECT id, career_id AS "careerId", name
         FROM academic_subjects
         WHERE user_id = $1
         ORDER BY name`,
        [req.session.userId]
      )
    ]);
    const careers = careerResult.rows.map((career) => ({
      ...career,
      subjects: subjectResult.rows.filter((subject) => String(subject.careerId) === String(career.id))
    }));
    return res.json({ careers });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/academic-catalog/careers', requireAuth, async (req, res, next) => {
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!name || name.length > 120) {
    return res.status(400).json({ error: 'El nombre de la carrera debe tener entre 1 y 120 caracteres.' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO academic_programs (user_id, name)
       VALUES ($1, $2)
       RETURNING id, name`,
      [req.session.userId, name]
    );
    return res.status(201).json({ career: { ...result.rows[0], subjects: [] } });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una carrera con ese nombre.' });
    }
    return next(error);
  }
});

app.patch('/api/academic-catalog/careers/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la carrera no es válido.' });
  }
  if (!name || name.length > 120) {
    return res.status(400).json({ error: 'El nombre de la carrera debe tener entre 1 y 120 caracteres.' });
  }
  try {
    const result = await pool.query(
      `UPDATE academic_programs
       SET name = $1
       WHERE id = $2 AND user_id = $3
       RETURNING id, name`,
      [name, id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la carrera.' });
    return res.json({ career: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una carrera con ese nombre.' });
    }
    return next(error);
  }
});

app.delete('/api/academic-catalog/careers/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la carrera no es válido.' });
  }
  try {
    const result = await pool.query(
      `DELETE FROM academic_programs c
       WHERE c.id = $1 AND c.user_id = $2
         AND NOT EXISTS (SELECT 1 FROM loans l WHERE l.career_id = c.id)
         AND NOT EXISTS (
           SELECT 1 FROM loans l
           JOIN academic_subjects s ON s.id = l.subject_id
           WHERE s.career_id = c.id
         )
       RETURNING c.id`,
      [id, req.session.userId]
    );
    if (!result.rowCount) {
      const exists = await pool.query(
        'SELECT id FROM academic_programs WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      if (!exists.rowCount) return res.status(404).json({ error: 'No se encontró la carrera.' });
      return res.status(409).json({
        error: 'No se puede eliminar una carrera asociada a un préstamo. Sus asignaturas también se eliminarán.'
      });
    }
    return res.status(204).end();
  } catch (error) {
    if (error.code === '23503') {
      return res.status(409).json({ error: 'No se puede eliminar una carrera asociada a un préstamo.' });
    }
    return next(error);
  }
});

app.post('/api/academic-catalog/careers/:id/subjects', requireAuth, async (req, res, next) => {
  const { id: careerId } = req.params;
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(careerId)) {
    return res.status(400).json({ error: 'El identificador de la carrera no es válido.' });
  }
  if (!name || name.length > 120) {
    return res.status(400).json({ error: 'El nombre de la asignatura debe tener entre 1 y 120 caracteres.' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO academic_subjects (user_id, career_id, name)
       SELECT $1, id, $3
       FROM academic_programs
       WHERE id = $2 AND user_id = $1
       RETURNING id, career_id AS "careerId", name`,
      [req.session.userId, careerId, name]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la carrera seleccionada.' });
    return res.status(201).json({ subject: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una asignatura con ese nombre en esta carrera.' });
    }
    return next(error);
  }
});

app.patch('/api/academic-catalog/subjects/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la asignatura no es válido.' });
  }
  if (!name || name.length > 120) {
    return res.status(400).json({ error: 'El nombre de la asignatura debe tener entre 1 y 120 caracteres.' });
  }
  try {
    const result = await pool.query(
      `UPDATE academic_subjects
       SET name = $1
       WHERE id = $2 AND user_id = $3
       RETURNING id, career_id AS "careerId", name`,
      [name, id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la asignatura.' });
    return res.json({ subject: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una asignatura con ese nombre en esta carrera.' });
    }
    return next(error);
  }
});

app.delete('/api/academic-catalog/subjects/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la asignatura no es válido.' });
  }
  try {
    const result = await pool.query(
      `DELETE FROM academic_subjects s
       WHERE s.id = $1 AND s.user_id = $2
         AND NOT EXISTS (SELECT 1 FROM loans l WHERE l.subject_id = s.id)
       RETURNING s.id`,
      [id, req.session.userId]
    );
    if (!result.rowCount) {
      const exists = await pool.query(
        'SELECT id FROM academic_subjects WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      if (!exists.rowCount) return res.status(404).json({ error: 'No se encontró la asignatura.' });
      return res.status(409).json({ error: 'No se puede eliminar una asignatura asociada a un préstamo.' });
    }
    return res.status(204).end();
  } catch (error) {
    if (error.code === '23503') {
      return res.status(409).json({ error: 'No se puede eliminar una asignatura asociada a un préstamo.' });
    }
    return next(error);
  }
});

app.get('/api/invoices', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, supplier_rut AS "supplierRut",
              invoice_number AS "invoiceNumber",
              created_at AS "createdAt", updated_at AS "updatedAt"
       FROM invoices
       WHERE user_id = $1
       ORDER BY created_at DESC, id DESC`,
      [req.session.userId]
    );
    return res.json({ invoices: result.rows });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/invoices', requireAuth, async (req, res, next) => {
  const invoice = parseInvoice(req.body);
  if (typeof invoice === 'string') return res.status(400).json({ error: invoice });

  try {
    const result = await pool.query(
      `INSERT INTO invoices (user_id, supplier_rut, invoice_number)
       VALUES ($1, $2, $3)
       RETURNING id, supplier_rut AS "supplierRut",
                 invoice_number AS "invoiceNumber",
                 created_at AS "createdAt", updated_at AS "updatedAt"`,
      [req.session.userId, invoice.supplierRut, invoice.invoiceNumber]
    );
    return res.status(201).json({ invoice: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una factura con ese número para este proveedor.' });
    }
    return next(error);
  }
});

app.patch('/api/invoices/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la factura no es válido.' });
  }
  const invoice = parseInvoice(req.body);
  if (typeof invoice === 'string') return res.status(400).json({ error: invoice });

  try {
    const result = await pool.query(
      `UPDATE invoices
       SET supplier_rut = $1, invoice_number = $2, updated_at = NOW()
       WHERE id = $3 AND user_id = $4
       RETURNING id, supplier_rut AS "supplierRut",
                 invoice_number AS "invoiceNumber",
                 created_at AS "createdAt", updated_at AS "updatedAt"`,
      [invoice.supplierRut, invoice.invoiceNumber, id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la factura.' });
    return res.json({ invoice: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una factura con ese número para este proveedor.' });
    }
    return next(error);
  }
});

app.delete('/api/invoices/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la factura no es válido.' });
  }
  try {
    const result = await pool.query(
      'DELETE FROM invoices WHERE id = $1 AND user_id = $2 RETURNING id',
      [id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la factura.' });
    return res.status(204).end();
  } catch (error) {
    return next(error);
  }
});

app.get('/api/clients', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT id, name, rut, email, area,
              created_at AS "createdAt", updated_at AS "updatedAt"
       FROM clients
       WHERE user_id = $1
       ORDER BY name, id`,
      [req.session.userId]
    );
    return res.json({ clients: result.rows });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/clients', requireAuth, async (req, res, next) => {
  const clientData = parseClient(req.body);
  if (typeof clientData === 'string') return res.status(400).json({ error: clientData });
  try {
    const result = await pool.query(
      `INSERT INTO clients (user_id, name, rut, email, area)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, name, rut, email, area,
                 created_at AS "createdAt", updated_at AS "updatedAt"`,
      [req.session.userId, clientData.name, clientData.rut, clientData.email, clientData.area]
    );
    return res.status(201).json({ client: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe un cliente con ese RUT.' });
    }
    return next(error);
  }
});

app.put('/api/clients/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador del cliente no es válido.' });
  const clientData = parseClient(req.body);
  if (typeof clientData === 'string') return res.status(400).json({ error: clientData });
  try {
    const result = await pool.query(
      `UPDATE clients
       SET name = $1, rut = $2, email = $3, area = $4, updated_at = NOW()
       WHERE id = $5 AND user_id = $6
       RETURNING id, name, rut, email, area,
                 created_at AS "createdAt", updated_at AS "updatedAt"`,
      [clientData.name, clientData.rut, clientData.email, clientData.area, id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró el cliente.' });
    return res.json({ client: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe un cliente con ese RUT.' });
    }
    return next(error);
  }
});

app.delete('/api/clients/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador del cliente no es válido.' });
  try {
    const result = await pool.query(
      `DELETE FROM clients c
       WHERE c.id = $1 AND c.user_id = $2
         AND NOT EXISTS (SELECT 1 FROM loans l WHERE l.client_id = c.id)
       RETURNING c.id`,
      [id, req.session.userId]
    );
    if (!result.rowCount) {
      const exists = await pool.query(
        'SELECT id FROM clients WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      if (!exists.rowCount) return res.status(404).json({ error: 'No se encontró el cliente.' });
      return res.status(409).json({ error: 'No se puede eliminar un cliente vinculado a préstamos.' });
    }
    return res.status(204).end();
  } catch (error) {
    if (error.code === '23503') {
      return res.status(409).json({ error: 'No se puede eliminar un cliente vinculado a préstamos.' });
    }
    return next(error);
  }
});

app.get('/api/classifications', requireAuth, async (req, res, next) => {
  try {
    const existing = await pool.query(
      'SELECT 1 FROM product_categories WHERE user_id = $1 LIMIT 1',
      [req.session.userId]
    );
    if (!existing.rowCount) {
      await pool.query(
        `INSERT INTO product_categories (user_id, name)
         SELECT $1, category.name
         FROM unnest($2::text[]) AS category(name)
         ON CONFLICT DO NOTHING`,
        [req.session.userId, DEFAULT_CATEGORIES]
      );
    }
    const existingUnits = await pool.query(
      'SELECT 1 FROM product_units_of_measure WHERE user_id = $1 LIMIT 1',
      [req.session.userId]
    );
    if (!existingUnits.rowCount) {
      await pool.query(
        `INSERT INTO product_units_of_measure (user_id, name)
         SELECT $1, unit.name
         FROM unnest($2::text[]) AS unit(name)
         ON CONFLICT DO NOTHING`,
        [req.session.userId, DEFAULT_UNITS_OF_MEASURE]
      );
    }
    const [result, unitsResult] = await Promise.all([
      pool.query(
      `SELECT c.id AS "categoryId", c.name AS "categoryName",
              s.id AS "subcategoryId", s.name AS "subcategoryName"
       FROM product_categories c
       LEFT JOIN product_subcategories s
         ON s.category_id = c.id AND s.user_id = c.user_id
       WHERE c.user_id = $1
       ORDER BY c.name, s.name`,
      [req.session.userId]
      ),
      pool.query(
        `SELECT u.id, u.name,
                EXISTS (
                  SELECT 1 FROM products p
                  WHERE p.user_id = u.user_id AND p.unit_of_measure = u.name
                ) AS "isInUse"
         FROM product_units_of_measure u
         WHERE u.user_id = $1
         ORDER BY u.name`,
        [req.session.userId]
      )
    ]);
    const categories = [];
    for (const row of result.rows) {
      let category = categories.find((item) => String(item.id) === String(row.categoryId));
      if (!category) {
        category = { id: row.categoryId, name: row.categoryName, subcategories: [] };
        categories.push(category);
      }
      if (row.subcategoryId !== null) {
        category.subcategories.push({ id: row.subcategoryId, name: row.subcategoryName });
      }
    }
    return res.json({ categories, unitsOfMeasure: unitsResult.rows });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/classifications/categories', requireAuth, async (req, res, next) => {
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!name || name.length > 80) {
    return res.status(400).json({ error: 'El nombre de la categoría debe tener entre 1 y 80 caracteres.' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO product_categories (user_id, name)
       VALUES ($1, $2)
       RETURNING id, name`,
      [req.session.userId, name]
    );
    return res.status(201).json({ category: { ...result.rows[0], subcategories: [] } });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una categoría con ese nombre.' });
    }
    return next(error);
  }
});

app.patch('/api/classifications/categories/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador de categoría no es válido.' });
  if (!name || name.length > 80) {
    return res.status(400).json({ error: 'El nombre de la categoría debe tener entre 1 y 80 caracteres.' });
  }
  try {
    const result = await pool.query(
      `UPDATE product_categories SET name = $1
       WHERE id = $2 AND user_id = $3
       RETURNING id, name`,
      [name, id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la categoría.' });
    return res.json({ category: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una categoría con ese nombre.' });
    }
    return next(error);
  }
});

app.post('/api/classifications/subcategories', requireAuth, async (req, res, next) => {
  const categoryId = req.body && String(req.body.categoryId || '');
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(categoryId) || !name || name.length > 80) {
    return res.status(400).json({ error: 'Selecciona una categoría y una subcategoría con nombres válidos.' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO product_subcategories (user_id, category_id, name)
       SELECT $1, id, $3 FROM product_categories
       WHERE id = $2 AND user_id = $1
       RETURNING id, category_id AS "categoryId", name`,
      [req.session.userId, categoryId, name]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la categoría seleccionada.' });
    return res.status(201).json({ subcategory: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una subcategoría con ese nombre.' });
    }
    return next(error);
  }
});

app.patch('/api/classifications/subcategories/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador de subcategoría no es válido.' });
  if (!name || name.length > 80) {
    return res.status(400).json({ error: 'El nombre de la subcategoría debe tener entre 1 y 80 caracteres.' });
  }
  try {
    const result = await pool.query(
      `UPDATE product_subcategories SET name = $1
       WHERE id = $2 AND user_id = $3
       RETURNING id, category_id AS "categoryId", name`,
      [name, id, req.session.userId]
    );
    if (!result.rows[0]) return res.status(404).json({ error: 'No se encontró la subcategoría.' });
    return res.json({ subcategory: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una subcategoría con ese nombre.' });
    }
    return next(error);
  }
});

app.delete('/api/classifications/categories/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador de categoría no es válido.' });
  try {
    const result = await pool.query(
      `DELETE FROM product_categories c
       WHERE c.id = $1 AND c.user_id = $2
         AND NOT EXISTS (
           SELECT 1 FROM products p
           WHERE p.user_id = $2
             AND (p.category_id = c.id OR p.subcategory_id IN (
               SELECT s.id FROM product_subcategories s
               WHERE s.category_id = c.id AND s.user_id = $2
             ))
         )
       RETURNING c.id`,
      [id, req.session.userId]
    );
    if (!result.rowCount) {
      const exists = await pool.query(
        'SELECT id FROM product_categories WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      if (!exists.rowCount) return res.status(404).json({ error: 'No se encontró la categoría.' });
      return res.status(409).json({ error: 'No se puede eliminar una categoría que está asignada a productos.' });
    }
    return res.status(204).end();
  } catch (error) {
    return next(error);
  }
});

app.delete('/api/classifications/subcategories/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador de subcategoría no es válido.' });
  try {
    const result = await pool.query(
      `DELETE FROM product_subcategories s
       WHERE s.id = $1 AND s.user_id = $2
         AND NOT EXISTS (
           SELECT 1 FROM products p WHERE p.subcategory_id = s.id AND p.user_id = $2
         )
       RETURNING s.id`,
      [id, req.session.userId]
    );
    if (!result.rowCount) {
      const exists = await pool.query(
        'SELECT id FROM product_subcategories WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      if (!exists.rowCount) return res.status(404).json({ error: 'No se encontró la subcategoría.' });
      return res.status(409).json({ error: 'No se puede eliminar una subcategoría asignada a productos.' });
    }
    return res.status(204).end();
  } catch (error) {
    return next(error);
  }
});

app.post('/api/classifications/units', requireAuth, async (req, res, next) => {
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!name || name.length > 20) {
    return res.status(400).json({ error: 'La unidad de medida debe tener entre 1 y 20 caracteres.' });
  }
  try {
    const result = await pool.query(
      `INSERT INTO product_units_of_measure (user_id, name)
       VALUES ($1, $2)
       RETURNING id, name`,
      [req.session.userId, name]
    );
    return res.status(201).json({ unitOfMeasure: result.rows[0] });
  } catch (error) {
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una unidad de medida con ese nombre.' });
    }
    return next(error);
  }
});

app.patch('/api/classifications/units/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  const name = req.body && typeof req.body.name === 'string' ? req.body.name.trim() : '';
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador de unidad no es válido.' });
  if (!name || name.length > 20) {
    return res.status(400).json({ error: 'La unidad de medida debe tener entre 1 y 20 caracteres.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const currentResult = await client.query(
      'SELECT id, name FROM product_units_of_measure WHERE id = $1 AND user_id = $2 FOR UPDATE',
      [id, req.session.userId]
    );
    const current = currentResult.rows[0];
    if (!current) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró la unidad de medida.' });
    }
    const result = await client.query(
      `UPDATE product_units_of_measure SET name = $1
       WHERE id = $2 AND user_id = $3
       RETURNING id, name`,
      [name, id, req.session.userId]
    );
    await client.query(
      `UPDATE products SET unit_of_measure = $1
       WHERE user_id = $2 AND unit_of_measure = $3`,
      [name, req.session.userId, current.name]
    );
    await client.query('COMMIT');
    return res.json({ unitOfMeasure: result.rows[0] });
  } catch (error) {
    await client.query('ROLLBACK');
    if (error.code === '23505') {
      return res.status(409).json({ error: 'Ya existe una unidad de medida con ese nombre.' });
    }
    return next(error);
  } finally {
    client.release();
  }
});

app.delete('/api/classifications/units/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) return res.status(400).json({ error: 'El identificador de unidad no es válido.' });
  try {
    const result = await pool.query(
      `DELETE FROM product_units_of_measure u
       WHERE u.id = $1 AND u.user_id = $2
         AND (SELECT COUNT(*) FROM product_units_of_measure WHERE user_id = $2) > 1
         AND NOT EXISTS (
           SELECT 1 FROM products p
           WHERE p.user_id = $2 AND p.unit_of_measure = u.name
         )
       RETURNING u.id`,
      [id, req.session.userId]
    );
    if (!result.rowCount) {
      const exists = await pool.query(
        'SELECT id FROM product_units_of_measure WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      if (!exists.rowCount) return res.status(404).json({ error: 'No se encontró la unidad de medida.' });
      return res.status(409).json({
        error: 'No se puede eliminar la última unidad de medida ni una unidad asignada a productos.'
      });
    }
    return res.status(204).end();
  } catch (error) {
    return next(error);
  }
});

async function resolveProductClassification(userId, product) {
  if (!product.categoryId) {
    return product.subcategoryId
      ? 'Selecciona una categoría válida para la subcategoría.'
      : { category: product.category, categoryId: null, subcategoryId: null };
  }
  const result = await pool.query(
    `SELECT c.id, c.name, s.id AS "subcategoryId"
     FROM product_categories c
     LEFT JOIN product_subcategories s
       ON s.id = $3 AND s.category_id = c.id AND s.user_id = c.user_id
     WHERE c.id = $2 AND c.user_id = $1`,
    [userId, product.categoryId, product.subcategoryId]
  );
  const classification = result.rows[0];
  if (!classification || (product.subcategoryId && !classification.subcategoryId)) {
    return 'La categoría o subcategoría seleccionada no es válida.';
  }
  return {
    category: classification.name,
    categoryId: classification.id,
    subcategoryId: classification.subcategoryId
  };
}

async function validateProductUnit(userId, unitOfMeasure) {
  const result = await pool.query(
    'SELECT 1 FROM product_units_of_measure WHERE user_id = $1 AND name = $2',
    [userId, unitOfMeasure]
  );
  return result.rowCount
    ? null
    : 'La unidad de medida seleccionada no existe. Actualiza el catálogo e inténtalo nuevamente.';
}

async function validateCampus(userId, campusId) {
  const result = await pool.query(
    'SELECT 1 FROM campuses WHERE user_id = $1 AND id = $2',
    [userId, campusId]
  );
  return result.rowCount
    ? null
    : 'La sede seleccionada no existe. Actualiza el catálogo e inténtalo nuevamente.';
}

app.get('/api/products', requireAuth, async (req, res, next) => {
  const archived = req.query.archived === 'true';
  if (req.query.archived !== undefined && !['true', 'false'].includes(req.query.archived)) {
    return res.status(400).json({ error: 'El filtro de productos archivados no es válido.' });
  }

  try {
    const result = await pool.query(
      `SELECT p.id, p.name, COALESCE(c.name, p.category) AS category,
              p.category_id AS "categoryId",
              p.subcategory_id AS "subcategoryId", s.name AS "subcategory",
              p.unit_of_measure AS "unitOfMeasure",
              p.stock, p.reorder_level AS "reorderLevel",
              p.price, p.supplier, p.code, p.state, p.quality,
              p.is_consumable AS "isConsumable", p.characteristics, p.description,
              p.image_data AS "imageData", p.image_mime_type AS "imageMimeType",
              p.is_archived AS "isArchived",
              p.campus_id AS "campusId", c_site.name AS "campusName",
              p.barcode
       FROM products p
       LEFT JOIN product_categories c
         ON c.id = p.category_id AND c.user_id = p.user_id
       LEFT JOIN product_subcategories s
         ON s.id = p.subcategory_id AND s.user_id = p.user_id
       LEFT JOIN campuses c_site
         ON c_site.id = p.campus_id AND c_site.user_id = p.user_id
       WHERE p.user_id = $1 AND p.is_archived = $2
       ORDER BY p.id`,
      [req.session.userId, archived]
    );
    return res.json({ products: result.rows.map(serializeProduct) });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/products', requireAuth, async (req, res, next) => {
  const product = parseProduct(req.body);
  if (typeof product === 'string') return res.status(400).json({ error: product });
  if (!product.imageData) return res.status(400).json({ error: 'Selecciona una imagen para el producto.' });

  const code = `SKU-${randomBytes(4).toString('hex').toUpperCase()}`;
  try {
    const classification = await resolveProductClassification(req.session.userId, product);
    if (typeof classification === 'string') return res.status(400).json({ error: classification });
    const unitError = await validateProductUnit(req.session.userId, product.unitOfMeasure);
    if (unitError) return res.status(400).json({ error: unitError });
    const campusError = await validateCampus(req.session.userId, product.campusId);
    if (campusError) return res.status(400).json({ error: campusError });
    const result = await pool.query(
      `INSERT INTO products
         (user_id, name, category, category_id, subcategory_id, campus_id, unit_of_measure,
          stock, reorder_level, price, supplier, code, barcode, state, quality, is_consumable,
          characteristics, description, image_data, image_mime_type)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20)
       RETURNING id, name, category, category_id AS "categoryId",
                 subcategory_id AS "subcategoryId", campus_id AS "campusId",
                 unit_of_measure AS "unitOfMeasure",
                 stock, reorder_level AS "reorderLevel",
                 price, supplier, code, barcode, state, quality,
                 is_consumable AS "isConsumable", characteristics, description,
                 image_data AS "imageData", image_mime_type AS "imageMimeType",
                 is_archived AS "isArchived"`,
      [
        req.session.userId,
        product.name,
        classification.category,
        classification.categoryId,
        classification.subcategoryId,
        product.campusId,
        product.unitOfMeasure,
        product.stock,
        product.reorderLevel,
        product.price,
        product.supplier,
        code,
        product.barcode,
        product.state,
        product.quality,
        product.isConsumable,
        product.characteristics,
        product.description,
        Buffer.from(product.imageData, 'base64'),
        product.imageMimeType
      ]
    );
    return res.status(201).json({ product: serializeProduct(result.rows[0]) });
  } catch (error) {
    if (error.code === '23505' && error.constraint === 'products_user_barcode_idx') {
      return res.status(409).json({ error: 'Ya existe un producto con ese código de barras.' });
    }
    return next(error);
  }
});

app.put('/api/products/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador del producto no es válido.' });
  }

  const product = parseProduct(req.body);
  if (typeof product === 'string') return res.status(400).json({ error: product });

  try {
    const classification = await resolveProductClassification(req.session.userId, product);
    if (typeof classification === 'string') return res.status(400).json({ error: classification });
    const unitError = await validateProductUnit(req.session.userId, product.unitOfMeasure);
    if (unitError) return res.status(400).json({ error: unitError });
    const campusError = await validateCampus(req.session.userId, product.campusId);
    if (campusError) return res.status(400).json({ error: campusError });
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const currentProduct = await client.query(
        `SELECT campus_id AS "campusId"
         FROM products
         WHERE id = $1 AND user_id = $2 AND is_archived = FALSE
         FOR UPDATE`,
        [id, req.session.userId]
      );
      if (!currentProduct.rows[0]) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'No se encontró el producto.' });
      }
      if (String(currentProduct.rows[0].campusId) !== product.campusId) {
        const activeLoanResult = await client.query(
          `SELECT EXISTS (
             SELECT 1 FROM loan_items li
             JOIN loans l ON l.id = li.loan_id
             WHERE li.product_id = $1 AND l.is_deleted = FALSE AND li.is_consumable = FALSE
               AND li.quantity > li.returned_quantity
           ) AS "hasActiveLoan"`,
          [id]
        );
        if (activeLoanResult.rows[0].hasActiveLoan) {
          await client.query('ROLLBACK');
          return res.status(409).json({
            error: 'No se puede cambiar de sede un producto que tiene préstamos pendientes de devolución.'
          });
        }
      }
      const result = await client.query(
        `UPDATE products
         SET name = $1, category = $2, category_id = $3, subcategory_id = $4,
             campus_id = $5, unit_of_measure = $6, stock = $7, reorder_level = $8,
             price = $9, supplier = $10, barcode = $11, state = $12, quality = $13,
             is_consumable = $14, characteristics = $15, description = $16,
             image_data = COALESCE($17, image_data),
             image_mime_type = CASE WHEN $17 IS NULL THEN image_mime_type ELSE $18 END
         WHERE id = $19 AND user_id = $20 AND is_archived = FALSE
         RETURNING id, name, category, category_id AS "categoryId",
                   subcategory_id AS "subcategoryId", campus_id AS "campusId",
                   unit_of_measure AS "unitOfMeasure",
                   stock, reorder_level AS "reorderLevel",
                   price, supplier, code, barcode, state, quality,
                   is_consumable AS "isConsumable", characteristics, description,
                   image_data AS "imageData", image_mime_type AS "imageMimeType",
                   is_archived AS "isArchived"`,
        [
          product.name,
          classification.category,
          classification.categoryId,
          classification.subcategoryId,
          product.campusId,
          product.unitOfMeasure,
          product.stock,
          product.reorderLevel,
          product.price,
          product.supplier,
          product.barcode,
          product.state,
          product.quality,
          product.isConsumable,
          product.characteristics,
          product.description,
          product.imageData ? Buffer.from(product.imageData, 'base64') : null,
          product.imageMimeType,
          id,
          req.session.userId
        ]
      );
      await client.query('COMMIT');
      return res.json({ product: serializeProduct(result.rows[0]) });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  } catch (error) {
    if (error.code === '23505' && error.constraint === 'products_user_barcode_idx') {
      return res.status(409).json({ error: 'Ya existe un producto con ese código de barras.' });
    }
    return next(error);
  }
});

app.patch('/api/products/:id/archive', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  const archived = req.body && req.body.archived;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador del producto no es válido.' });
  }
  if (typeof archived !== 'boolean') {
    return res.status(400).json({ error: 'Indica si el producto debe quedar archivado.' });
  }

  try {
    const result = await pool.query(
      `UPDATE products
       SET is_archived = $1
       WHERE id = $2 AND user_id = $3 AND is_archived <> $1
       RETURNING id, is_archived AS "isArchived"`,
      [archived, id, req.session.userId]
    );
    if (!result.rows[0]) {
      const existing = await pool.query(
        'SELECT id FROM products WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      if (!existing.rows[0]) return res.status(404).json({ error: 'No se encontró el producto.' });
      return res.status(409).json({
        error: archived ? 'El producto ya está archivado.' : 'El producto ya está activo.'
      });
    }
    return res.json({ product: result.rows[0] });
  } catch (error) {
    return next(error);
  }
});

app.delete('/api/products/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador del producto no es válido.' });
  }

  try {
    const result = await pool.query(
      'UPDATE products SET is_archived = TRUE WHERE id = $1 AND user_id = $2',
      [id, req.session.userId]
    );
    if (result.rowCount === 0) return res.status(404).json({ error: 'No se encontró el producto.' });
    return res.status(204).end();
  } catch (error) {
    return next(error);
  }
});

app.get('/api/write-offs', requireAuth, async (req, res, next) => {
  const includeDeleted = req.query.includeDeleted === 'true';
  if (req.query.includeDeleted !== undefined && !['true', 'false'].includes(req.query.includeDeleted)) {
    return res.status(400).json({ error: 'El filtro del historial de bajas no es válido.' });
  }
  try {
    const result = await pool.query(
      `SELECT w.id, w.product_id AS "productId", w.codigo,
              w.write_off_date::text AS date, w.bodega, w.ubicacion AS location,
              w.cantidad AS quantity, w.razon AS reason, w.observacion AS observation,
              w.is_deleted AS "isDeleted", w.deleted_at AS "deletedAt",
              p.name AS "productName", p.unit_of_measure AS "unitOfMeasure",
              p.is_archived AS "isArchived"
       FROM inventory_write_offs w
       JOIN products p ON p.id = w.product_id AND p.user_id = w.user_id
       WHERE w.user_id = $1 AND ($2::boolean OR w.is_deleted = FALSE)
       ORDER BY w.write_off_date DESC, w.id DESC`,
      [req.session.userId, includeDeleted]
    );
    return res.json({ writeOffs: result.rows });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/write-offs', requireAuth, async (req, res, next) => {
  const writeOff = parseWriteOff(req.body);
  if (typeof writeOff === 'string') return res.status(400).json({ error: writeOff });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const productResult = await client.query(
      `SELECT p.id, p.code, p.stock, p.is_archived AS "isArchived",
              c.name AS bodega
       FROM products p
       JOIN campuses c ON c.id = p.campus_id AND c.user_id = p.user_id
       WHERE p.id = $1 AND p.user_id = $2
       FOR UPDATE OF p`,
      [writeOff.productId, req.session.userId]
    );
    const product = productResult.rows[0];
    if (!product) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró el producto seleccionado.' });
    }
    if (product.isArchived) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'No se puede registrar una baja para un producto archivado.' });
    }
    if (product.stock < writeOff.quantity) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        error: `La cantidad supera las existencias disponibles de "${product.code}". Disponibles: ${product.stock}.`
      });
    }
    const result = await client.query(
      `INSERT INTO inventory_write_offs
         (user_id, product_id, codigo, write_off_date, bodega, ubicacion,
          cantidad, razon, observacion)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING id, product_id AS "productId", codigo,
                 write_off_date::text AS date, bodega, ubicacion AS location,
                 cantidad AS quantity, razon AS reason, observacion AS observation,
                 is_deleted AS "isDeleted"`,
      [
        req.session.userId,
        product.id,
        product.code,
        writeOff.date,
        product.bodega,
        writeOff.location,
        writeOff.quantity,
        writeOff.reason,
        writeOff.observation
      ]
    );
    await client.query('UPDATE products SET stock = stock - $1 WHERE id = $2', [writeOff.quantity, product.id]);
    await client.query('COMMIT');
    return res.status(201).json({ writeOff: result.rows[0] });
  } catch (error) {
    await client.query('ROLLBACK');
    return next(error);
  } finally {
    client.release();
  }
});

app.put('/api/write-offs/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la baja no es válido.' });
  }
  const writeOff = parseWriteOff(req.body);
  if (typeof writeOff === 'string') return res.status(400).json({ error: writeOff });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const currentResult = await client.query(
      `SELECT id, product_id AS "productId", cantidad AS quantity
       FROM inventory_write_offs
       WHERE id = $1 AND user_id = $2 AND is_deleted = FALSE
       FOR UPDATE`,
      [id, req.session.userId]
    );
    const current = currentResult.rows[0];
    if (!current) {
      const exists = await client.query(
        'SELECT is_deleted AS "isDeleted" FROM inventory_write_offs WHERE id = $1 AND user_id = $2',
        [id, req.session.userId]
      );
      await client.query('ROLLBACK');
      return exists.rows[0]?.isDeleted
        ? res.status(409).json({ error: 'No se puede modificar una baja anulada.' })
        : res.status(404).json({ error: 'No se encontró la baja.' });
    }

    const productIds = [...new Set([String(current.productId), writeOff.productId])];
    const productsResult = await client.query(
      `SELECT p.id, p.code, p.stock, p.is_archived AS "isArchived",
              c.name AS bodega
       FROM products p
       JOIN campuses c ON c.id = p.campus_id AND c.user_id = p.user_id
       WHERE p.id = ANY($1::bigint[]) AND p.user_id = $2
       ORDER BY p.id
       FOR UPDATE OF p`,
      [productIds, req.session.userId]
    );
    const productsById = new Map(productsResult.rows.map((product) => [String(product.id), product]));
    const oldProduct = productsById.get(String(current.productId));
    const newProduct = productsById.get(writeOff.productId);
    if (!oldProduct || !newProduct) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró uno de los productos asociados a la baja.' });
    }
    if (newProduct.isArchived && String(newProduct.id) !== String(current.productId)) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'No se puede asignar una baja a un producto archivado.' });
    }

    if (oldProduct.id === newProduct.id) {
      const updatedStock = Number(oldProduct.stock) + Number(current.quantity) - writeOff.quantity;
      if (updatedStock < 0) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          error: `La cantidad supera las existencias disponibles de "${newProduct.code}" al revertir la baja actual.`
        });
      }
      if (updatedStock > 2147483647) {
        await client.query('ROLLBACK');
        return res.status(409).json({ error: 'La modificación superaría el máximo de existencias permitido.' });
      }
      await client.query('UPDATE products SET stock = $1 WHERE id = $2', [updatedStock, oldProduct.id]);
    } else {
      if (Number(oldProduct.stock) + Number(current.quantity) > 2147483647) {
        await client.query('ROLLBACK');
        return res.status(409).json({ error: 'No se puede revertir la baja actual: se superaría el máximo de existencias permitido.' });
      }
      if (newProduct.stock < writeOff.quantity) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          error: `La cantidad supera las existencias disponibles de "${newProduct.code}". Disponibles: ${newProduct.stock}.`
        });
      }
      await client.query(
        'UPDATE products SET stock = stock + $1 WHERE id = $2',
        [current.quantity, oldProduct.id]
      );
      await client.query(
        'UPDATE products SET stock = stock - $1 WHERE id = $2',
        [writeOff.quantity, newProduct.id]
      );
    }

    const result = await client.query(
      `UPDATE inventory_write_offs
       SET product_id = $1, codigo = $2, write_off_date = $3, bodega = $4,
           ubicacion = $5, cantidad = $6, razon = $7, observacion = $8,
           updated_at = NOW()
       WHERE id = $9 AND user_id = $10
       RETURNING id, product_id AS "productId", codigo,
                 write_off_date::text AS date, bodega, ubicacion AS location,
                 cantidad AS quantity, razon AS reason, observacion AS observation,
                 is_deleted AS "isDeleted"`,
      [
        newProduct.id,
        newProduct.code,
        writeOff.date,
        newProduct.bodega,
        writeOff.location,
        writeOff.quantity,
        writeOff.reason,
        writeOff.observation,
        id,
        req.session.userId
      ]
    );
    await client.query('COMMIT');
    return res.json({ writeOff: result.rows[0] });
  } catch (error) {
    await client.query('ROLLBACK');
    return next(error);
  } finally {
    client.release();
  }
});

app.delete('/api/write-offs/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador de la baja no es válido.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const writeOffResult = await client.query(
      `SELECT id, product_id AS "productId", cantidad AS quantity
       FROM inventory_write_offs
       WHERE id = $1 AND user_id = $2 AND is_deleted = FALSE
       FOR UPDATE`,
      [id, req.session.userId]
    );
    const writeOff = writeOffResult.rows[0];
    if (!writeOff) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró la baja activa.' });
    }
    const productResult = await client.query(
      `SELECT id, stock
       FROM products
       WHERE id = $1 AND user_id = $2
       FOR UPDATE`,
      [writeOff.productId, req.session.userId]
    );
    const product = productResult.rows[0];
    if (!product) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró el producto de la baja.' });
    }
    if (Number(product.stock) + Number(writeOff.quantity) > 2147483647) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'No se puede anular la baja: se superaría el máximo de existencias permitido.' });
    }
    await client.query(
      'UPDATE products SET stock = stock + $1 WHERE id = $2',
      [writeOff.quantity, product.id]
    );
    await client.query(
      `UPDATE inventory_write_offs
       SET is_deleted = TRUE, deleted_at = NOW(), updated_at = NOW()
       WHERE id = $1 AND user_id = $2`,
      [id, req.session.userId]
    );
    await client.query('COMMIT');
    return res.status(204).end();
  } catch (error) {
    await client.query('ROLLBACK');
    return next(error);
  } finally {
    client.release();
  }
});

app.get('/api/loans', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT l.id, li.id AS "loanItemId",
              l.loan_date::text AS "loanDate", l.due_date::text AS "dueDate",
              l.start_time::text AS "startTime", l.end_time::text AS "endTime",
              l.journey, l.created_at AS "createdAt", l.rut, l.area,
              l.client_name AS "clientName",
              COALESCE(academic_subject.name, l.subject) AS subject,
              academic_career.name AS "careerName",
              l.campus_id AS "campusId", c.name AS "campusName",
              li.product_id AS "productId", p.code AS "productCode", p.name AS "productName",
              p.unit_of_measure AS "unitOfMeasure",
              li.is_consumable AS "isConsumable",
              li.quantity, li.returned_quantity AS "returnedQuantity",
              CASE WHEN li.is_consumable THEN 0
                   ELSE li.quantity - li.returned_quantity END AS outstanding,
              (SELECT COUNT(*) FROM loan_items count_items
               WHERE count_items.loan_id = l.id) AS "itemCount"
       FROM loans l
       JOIN loan_items li ON li.loan_id = l.id
       JOIN products p ON p.id = li.product_id
       JOIN campuses c ON c.id = l.campus_id AND c.user_id = l.user_id
       LEFT JOIN academic_programs academic_career
         ON academic_career.id = l.career_id AND academic_career.user_id = l.user_id
       LEFT JOIN academic_subjects academic_subject
         ON academic_subject.id = l.subject_id AND academic_subject.user_id = l.user_id
       WHERE l.user_id = $1 AND l.is_deleted = FALSE
       ORDER BY l.loan_date DESC, l.id DESC, li.id`,
      [req.session.userId]
    );
    return res.json({ loans: result.rows });
  } catch (error) {
    return next(error);
  }
});

app.get('/api/loans/history', requireAuth, async (req, res, next) => {
  try {
    const result = await pool.query(
      `SELECT l.id, li.id AS "loanItemId",
              l.loan_date::text AS "loanDate", l.due_date::text AS "dueDate",
              l.start_time::text AS "startTime", l.end_time::text AS "endTime",
              l.created_at AS "createdAt", l.deleted_at AS "deletedAt",
              l.journey,
              l.campus_id AS "campusId", c.name AS "campusName",
              l.rut, l.area, l.client_name AS "clientName",
              COALESCE(academic_subject.name, l.subject) AS subject,
              academic_career.name AS "careerName",
              li.product_id AS "productId", p.code AS "productCode", p.name AS "productName",
              p.unit_of_measure AS "unitOfMeasure",
              li.is_consumable AS "isConsumable", l.is_deleted AS "isDeleted",
              li.quantity, li.returned_quantity AS "returnedQuantity",
              li.cancelled_quantity AS "cancelledQuantity",
              CASE WHEN l.is_deleted OR li.is_consumable THEN 0
                   ELSE li.quantity - li.returned_quantity END AS outstanding
       FROM loans l
       JOIN loan_items li ON li.loan_id = l.id
       JOIN products p ON p.id = li.product_id
       JOIN campuses c ON c.id = l.campus_id AND c.user_id = l.user_id
       LEFT JOIN academic_programs academic_career
         ON academic_career.id = l.career_id AND academic_career.user_id = l.user_id
       LEFT JOIN academic_subjects academic_subject
         ON academic_subject.id = l.subject_id AND academic_subject.user_id = l.user_id
       WHERE l.user_id = $1
       ORDER BY l.loan_date DESC, l.id DESC, li.id`,
      [req.session.userId]
    );
    return res.json({ loans: result.rows });
  } catch (error) {
    return next(error);
  }
});

app.post('/api/loans', requireAuth, async (req, res, next) => {
  const loan = parseLoan(req.body);
  if (typeof loan === 'string') return res.status(400).json({ error: loan });

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    let borrowerName = null;
    let borrowerRut = loan.rut;
    let borrowerArea = loan.area;
    if (loan.clientId) {
      const borrowerResult = await client.query(
        `SELECT id, name, rut, area
         FROM clients
         WHERE id = $1 AND user_id = $2
         FOR SHARE`,
        [loan.clientId, req.session.userId]
      );
      if (!borrowerResult.rows[0]) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'El cliente seleccionado no existe. Actualiza el catálogo e inténtalo nuevamente.' });
      }
      borrowerName = borrowerResult.rows[0].name;
      borrowerRut = borrowerResult.rows[0].rut;
      borrowerArea = borrowerResult.rows[0].area;
    }
    const campusResult = await client.query(
      'SELECT id FROM campuses WHERE id = $1 AND user_id = $2 FOR SHARE',
      [loan.campusId, req.session.userId]
    );
    if (!campusResult.rows[0]) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'La sede seleccionada no existe. Actualiza el catálogo e inténtalo nuevamente.' });
    }
    let subjectName = loan.subject;
    if (loan.careerId) {
      const careerResult = await client.query(
        `SELECT id
         FROM academic_programs
         WHERE id = $1 AND user_id = $2
         FOR SHARE`,
        [loan.careerId, req.session.userId]
      );
      if (!careerResult.rows[0]) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'La carrera seleccionada no existe. Actualiza el catálogo e inténtalo nuevamente.' });
      }
    }
    if (loan.subjectId) {
      const subjectResult = await client.query(
        `SELECT id, career_id AS "careerId", name
         FROM academic_subjects
         WHERE id = $1 AND user_id = $2
         FOR SHARE`,
        [loan.subjectId, req.session.userId]
      );
      const subject = subjectResult.rows[0];
      if (!subject) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'La asignatura seleccionada no existe. Actualiza el catálogo e inténtalo nuevamente.' });
      }
      if (String(subject.careerId) !== loan.careerId) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'La asignatura no pertenece a la carrera seleccionada.' });
      }
      subjectName = subject.name;
    }
    const productResult = await client.query(
      `SELECT id, campus_id AS "campusId", stock, state, is_consumable AS "isConsumable",
              is_archived AS "isArchived"
       FROM products
       WHERE id = ANY($1::bigint[]) AND user_id = $2
       ORDER BY id FOR UPDATE`,
      [loan.items.map((item) => item.productId), req.session.userId]
    );
    if (productResult.rows.length !== loan.items.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró uno de los productos seleccionados.' });
    }
    const productsById = new Map(productResult.rows.map((product) => [String(product.id), product]));
    const differentCampusProduct = loan.items.find((item) =>
      String(productsById.get(item.productId).campusId) !== loan.campusId
    );
    if (differentCampusProduct) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        error: 'Todos los productos del préstamo deben estar asignados a la sede seleccionada.'
      });
    }
    const items = loan.items.map((item) => ({
      ...item,
      product: productsById.get(item.productId)
    }));
    const unavailable = items.find(({ product }) => product.isArchived ||
      ['En reparación', 'Dado de baja'].includes(product.state));
    if (unavailable) {
      await client.query('ROLLBACK');
      return res.status(409).json({
        error: unavailable.product.isArchived
          ? 'No se puede prestar un producto archivado.'
          : `No se puede prestar un producto en estado "${unavailable.product.state}".`
      });
    }
    if (items.some(({ product }) => !product.isConsumable) && !loan.dueDate) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Indica la fecha límite de devolución para los productos reutilizables.' });
    }
    const insufficientStock = items.find(({ product, quantity }) => product.stock < quantity);
    if (insufficientStock) {
      await client.query('ROLLBACK');
      return res.status(400).json({
        error: `No hay stock suficiente para "${insufficientStock.product.name}". Disponible: ${insufficientStock.product.stock}.`
      });
    }

    const result = await client.query(
      `INSERT INTO loans
         (user_id, campus_id, career_id, subject_id, client_id, client_name, loan_date, due_date,
          start_time, end_time, journey, rut, area, subject, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, clock_timestamp())
       RETURNING id`,
      [
        req.session.userId,
        loan.campusId,
        loan.careerId,
        loan.subjectId,
        loan.clientId,
        borrowerName,
        loan.loanDate,
        items.some(({ product }) => !product.isConsumable) ? loan.dueDate : null,
        loan.startTime,
        loan.endTime,
        loan.journey,
        borrowerRut,
        borrowerArea,
        subjectName
      ]
    );
    const loanId = result.rows[0].id;
    for (const { product, quantity } of items) {
      await client.query(
        `UPDATE products
         SET stock = stock - $1,
             state = CASE
               WHEN $2 = FALSE AND state = 'Disponible' THEN 'En préstamo'
               ELSE state
             END
         WHERE id = $3`,
        [quantity, product.isConsumable, product.id]
      );
      await client.query(
        `INSERT INTO loan_items
           (loan_id, product_id, quantity, returned_quantity, is_consumable)
         VALUES ($1, $2, $3, $4, $5)`,
        [loanId, product.id, quantity, product.isConsumable ? quantity : 0, product.isConsumable]
      );
    }
    await client.query('COMMIT');
    return res.status(201).json({ loanId });
  } catch (error) {
    await client.query('ROLLBACK');
    return next(error);
  } finally {
    client.release();
  }
});

app.post('/api/loans/:id/items/:itemId/returns', requireAuth, async (req, res, next) => {
  const { id, itemId } = req.params;
  const quantity = Number(req.body && req.body.quantity);
  if (!isValidProductId(id) || !isValidProductId(itemId)) {
    return res.status(400).json({ error: 'El identificador del préstamo o de su producto no es válido.' });
  }
  if (!Number.isSafeInteger(quantity) || quantity < 1 || quantity > 2147483647) {
    return res.status(400).json({ error: 'La cantidad devuelta debe ser un entero positivo.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const loanResult = await client.query(
      `SELECT id
       FROM loans
       WHERE id = $1 AND user_id = $2 AND is_deleted = FALSE
       FOR UPDATE`,
      [id, req.session.userId]
    );
    const loan = loanResult.rows[0];
    if (!loan) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró el préstamo.' });
    }
    const itemResult = await client.query(
      `SELECT id, product_id, quantity, returned_quantity,
              is_consumable AS "isConsumable"
       FROM loan_items
       WHERE id = $1 AND loan_id = $2
       FOR UPDATE`,
      [itemId, id]
    );
    const item = itemResult.rows[0];
    if (!item) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró el producto en este préstamo.' });
    }
    if (item.isConsumable) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Este producto fungible fue consumido y no admite devolución.' });
    }
    const outstanding = item.quantity - item.returned_quantity;
    if (quantity > outstanding) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'La devolución supera la cantidad pendiente.' });
    }

    const productResult = await client.query(
      'SELECT stock FROM products WHERE id = $1 FOR UPDATE',
      [item.product_id]
    );
    if (!productResult.rows[0] || productResult.rows[0].stock > 2147483647 - quantity) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'No se puede registrar la devolución porque se superaría el stock máximo permitido.' });
    }
    await client.query(
      'UPDATE products SET stock = stock + $1 WHERE id = $2',
      [quantity, item.product_id]
    );
    await client.query(
      'UPDATE loan_items SET returned_quantity = returned_quantity + $1 WHERE id = $2',
      [quantity, itemId]
    );
    if (quantity === outstanding) {
      const activeLoans = await client.query(
        `SELECT EXISTS (
           SELECT 1 FROM loan_items li
           JOIN loans l ON l.id = li.loan_id
           WHERE li.product_id = $1 AND l.is_deleted = FALSE AND li.is_consumable = FALSE
             AND li.quantity > li.returned_quantity
         ) AS has_active_loans`,
        [item.product_id]
      );
      if (!activeLoans.rows[0].has_active_loans) {
        await client.query(
          `UPDATE products SET state = 'Disponible'
           WHERE id = $1 AND state = 'En préstamo'`,
          [item.product_id]
        );
      }
    }
    await client.query('COMMIT');
    return res.json({ returnedQuantity: item.returned_quantity + quantity });
  } catch (error) {
    await client.query('ROLLBACK');
    return next(error);
  } finally {
    client.release();
  }
});

app.delete('/api/loans/:id', requireAuth, async (req, res, next) => {
  const { id } = req.params;
  if (!isValidProductId(id)) {
    return res.status(400).json({ error: 'El identificador del préstamo no es válido.' });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const loanResult = await client.query(
      `SELECT id, is_deleted AS "isDeleted"
       FROM loans
       WHERE id = $1 AND user_id = $2
       FOR UPDATE`,
      [id, req.session.userId]
    );
    const loan = loanResult.rows[0];
    if (!loan) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'No se encontró el préstamo.' });
    }
    if (loan.isDeleted) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'Este préstamo ya está eliminado y conservado en el historial.' });
    }

    const itemResult = await client.query(
      `SELECT id, product_id, quantity, returned_quantity,
              is_consumable AS "isConsumable"
       FROM loan_items
       WHERE loan_id = $1
       ORDER BY product_id
       FOR UPDATE`,
      [id]
    );
    if (!itemResult.rows.length) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'No se puede eliminar el préstamo porque no tiene productos asociados.' });
    }
    const items = itemResult.rows.map((item) => ({
      ...item,
      outstanding: item.isConsumable ? 0 : item.quantity - item.returned_quantity
    }));
    const productResult = await client.query(
      `SELECT id, stock FROM products
       WHERE id = ANY($1::bigint[])
       ORDER BY id
       FOR UPDATE`,
      [items.map((item) => item.product_id)]
    );
    const productsById = new Map(productResult.rows.map((product) => [String(product.id), product]));
    if (productsById.size !== items.length) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: 'No se puede eliminar el préstamo porque falta un producto relacionado.' });
    }
    for (const item of items) {
      const product = productsById.get(String(item.product_id));
      if (item.outstanding > 0 && product.stock > 2147483647 - item.outstanding) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          error: `No se puede reponer el stock de "${product.name}" porque se superaría el máximo permitido.`
        });
      }
      await client.query(
        'UPDATE products SET stock = stock + $1 WHERE id = $2',
        [item.outstanding, item.product_id]
      );
    }
    await client.query(
      `UPDATE loan_items li
       SET cancelled_quantity = CASE WHEN li.is_consumable THEN 0
                                    ELSE li.quantity - li.returned_quantity END
       WHERE li.loan_id = $1`,
      [id]
    );
    await client.query(
      `UPDATE loans
       SET is_deleted = TRUE, deleted_at = NOW(), deleted_by = $1, updated_at = NOW()
       WHERE id = $2`,
      [req.session.userId, id]
    );
    for (const productId of new Set(items.map((item) => String(item.product_id)))) {
      const activeLoans = await client.query(
        `SELECT EXISTS (
           SELECT 1 FROM loan_items li
           JOIN loans l ON l.id = li.loan_id
           WHERE li.product_id = $1 AND l.is_deleted = FALSE
             AND li.is_consumable = FALSE AND li.quantity > li.returned_quantity
         ) AS has_active_loans`,
        [productId]
      );
      if (!activeLoans.rows[0].has_active_loans) {
        await client.query(
          `UPDATE products SET state = 'Disponible'
           WHERE id = $1 AND state = 'En préstamo'`,
          [productId]
        );
      }
    }
    await client.query('COMMIT');
    return res.json({
      restoredItems: items.map((item) => ({
        productId: item.product_id,
        quantity: item.outstanding
      }))
    });
  } catch (error) {
    await client.query('ROLLBACK');
    return next(error);
  } finally {
    client.release();
  }
});

function spreadsheetText(value) {
  if (value === undefined || value === null) return '';
  if (value instanceof Date) return value.toISOString();
  return String(value).trim();
}

function normalizeCatalogName(value) {
  return spreadsheetText(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('es');
}

function spreadsheetBoolean(value) {
  if (value === undefined || value === null || value === '') return false;
  if (typeof value === 'boolean') return value;
  const normalized = normalizeCatalogName(value);
  if (['si', 'true', '1'].includes(normalized)) return true;
  if (['no', 'false', '0'].includes(normalized)) return false;
  return null;
}

function sendSpreadsheet(buffer, filename, res) {
  res.set({
    'Content-Type': SPREADSHEET_MIME_TYPE,
    'Content-Disposition': `attachment; filename="${filename}"`,
    'Content-Length': buffer.length
  });
  return res.send(buffer);
}

function sendImportErrors(res, entity, errors) {
  const shownErrors = errors.slice(0, 20);
  return res.status(400).json({
    error: `No se importó ningún ${entity}. Corrige los errores indicados y vuelve a intentar.`,
    errors: shownErrors,
    totalErrors: errors.length
  });
}

app.get('/api/spreadsheets/templates/:type', requireAuth, async (req, res, next) => {
  if (!['clients', 'products'].includes(req.params.type)) {
    return res.status(400).json({ error: 'El tipo de planilla no es válido.' });
  }
  try {
    const workbook = await createWorkbook(req.params.type);
    return sendSpreadsheet(workbook, `plantilla-${req.params.type}-stockflow.xlsx`, res);
  } catch (error) {
    return next(error);
  }
});

app.get('/api/spreadsheets/:type', requireAuth, async (req, res, next) => {
  const { type } = req.params;
  if (!['clients', 'products'].includes(type)) {
    return res.status(400).json({ error: 'El tipo de planilla no es válido.' });
  }
  try {
    let records;
    if (type === 'clients') {
      const result = await pool.query(
        `SELECT name, rut, email, area
         FROM clients
         WHERE user_id = $1
         ORDER BY name, id`,
        [req.session.userId]
      );
      records = result.rows;
    } else {
      const result = await pool.query(
        `SELECT p.name, p.barcode, campus.name AS campus, c.name AS category,
                s.name AS subcategory, p.unit_of_measure AS "unitOfMeasure",
                p.stock, p.reorder_level AS "reorderLevel", p.price, p.supplier,
                p.is_consumable AS "isConsumable", p.state, p.quality,
                p.characteristics, p.description, p.code,
                p.is_archived AS "isArchived"
         FROM products p
         LEFT JOIN campuses campus ON campus.id = p.campus_id AND campus.user_id = p.user_id
         LEFT JOIN product_categories c ON c.id = p.category_id AND c.user_id = p.user_id
         LEFT JOIN product_subcategories s ON s.id = p.subcategory_id AND s.user_id = p.user_id
         WHERE p.user_id = $1
         ORDER BY p.id`,
        [req.session.userId]
      );
      records = result.rows;
    }
    const workbook = await createWorkbook(type, records);
    return sendSpreadsheet(workbook, `${type === 'clients' ? 'clientes' : 'productos'}-stockflow.xlsx`, res);
  } catch (error) {
    return next(error);
  }
});

app.post(
  '/api/spreadsheets/:type/import',
  requireAuth,
  express.raw({ type: SPREADSHEET_MIME_TYPE, limit: MAX_IMPORT_BYTES }),
  async (req, res, next) => {
    const { type } = req.params;
    if (!['clients', 'products'].includes(type)) {
      return res.status(400).json({ error: 'El tipo de planilla no es válido.' });
    }

    let rows;
    try {
      rows = await readImportWorkbook(req.body, type);
    } catch (error) {
      return res.status(400).json({ error: error.message });
    }

    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      if (type === 'clients') {
        const validRows = [];
        const errors = [];
        const seenRuts = new Map();
        for (const { rowNumber, record } of rows) {
          const parsed = parseClient({
            name: spreadsheetText(record.name),
            rut: spreadsheetText(record.rut),
            email: spreadsheetText(record.email),
            area: spreadsheetText(record.area)
          });
          if (typeof parsed === 'string') {
            errors.push({ row: rowNumber, message: parsed });
            continue;
          }
          if (seenRuts.has(parsed.rut)) {
            errors.push({ row: rowNumber, message: `RUT duplicado en la planilla (fila ${seenRuts.get(parsed.rut)}).` });
            continue;
          }
          seenRuts.set(parsed.rut, rowNumber);
          validRows.push({ rowNumber, client: parsed });
        }

        if (validRows.length) {
          const existing = await client.query(
            'SELECT rut FROM clients WHERE user_id = $1 AND rut = ANY($2::varchar[])',
            [req.session.userId, validRows.map(({ client: item }) => item.rut)]
          );
          const existingRuts = new Set(existing.rows.map((row) => row.rut));
          for (const item of validRows) {
            if (existingRuts.has(item.client.rut)) {
              errors.push({ row: item.rowNumber, message: `Ya existe un cliente con el RUT ${item.client.rut}.` });
            }
          }
        }

        if (errors.length) {
          await client.query('ROLLBACK');
          return sendImportErrors(res, 'cliente', errors);
        }
        for (const { client: item } of validRows) {
          await client.query(
            `INSERT INTO clients (user_id, name, rut, email, area)
             VALUES ($1, $2, $3, $4, $5)`,
            [req.session.userId, item.name, item.rut, item.email, item.area]
          );
        }
      } else {
        const campusResult = await client.query(
          'SELECT id, name FROM campuses WHERE user_id = $1',
          [req.session.userId]
        );
        const categoryResult = await client.query(
          'SELECT id, name FROM product_categories WHERE user_id = $1',
          [req.session.userId]
        );
        const subcategoryResult = await client.query(
          `SELECT s.id, s.category_id AS "categoryId", s.name, c.name AS "categoryName"
           FROM product_subcategories s
           JOIN product_categories c ON c.id = s.category_id AND c.user_id = s.user_id
           WHERE s.user_id = $1`,
          [req.session.userId]
        );
        const unitResult = await client.query(
          'SELECT name FROM product_units_of_measure WHERE user_id = $1',
          [req.session.userId]
        );
        const campusesByName = new Map(campusResult.rows.map((item) => [normalizeCatalogName(item.name), item]));
        const categoriesByName = new Map(categoryResult.rows.map((item) => [normalizeCatalogName(item.name), item]));
        const subcategoriesByName = new Map(subcategoryResult.rows.map((item) => [
          `${item.categoryId}:${normalizeCatalogName(item.name)}`,
          item
        ]));
        const unitsByName = new Map(unitResult.rows.map((item) => [normalizeCatalogName(item.name), item.name]));
        const validRows = [];
        const errors = [];

        for (const { rowNumber, record } of rows) {
          const campus = campusesByName.get(normalizeCatalogName(record.campus));
          const category = categoriesByName.get(normalizeCatalogName(record.category));
          const unitOfMeasure = unitsByName.get(normalizeCatalogName(record.unitOfMeasure));
          if (!campus) errors.push({ row: rowNumber, message: `La sede "${spreadsheetText(record.campus)}" no existe en el catálogo.` });
          if (!category) errors.push({ row: rowNumber, message: `La categoría "${spreadsheetText(record.category)}" no existe en el catálogo.` });
          if (!unitOfMeasure) errors.push({ row: rowNumber, message: `La unidad "${spreadsheetText(record.unitOfMeasure)}" no existe en el catálogo.` });
          if (!campus || !category || !unitOfMeasure) continue;

          const subcategoryName = spreadsheetText(record.subcategory);
          const subcategory = subcategoryName
            ? subcategoriesByName.get(`${category.id}:${normalizeCatalogName(subcategoryName)}`)
            : null;
          if (subcategoryName && !subcategory) {
            errors.push({ row: rowNumber, message: `La subcategoría "${subcategoryName}" no pertenece a la categoría "${category.name}".` });
            continue;
          }

          const isConsumable = spreadsheetBoolean(record.isConsumable);
          if (isConsumable === null) {
            errors.push({ row: rowNumber, message: 'El campo Fungible debe ser Sí/No o verdadero/falso.' });
            continue;
          }
          const isArchived = spreadsheetBoolean(record.isArchived);
          if (isArchived === null) {
            errors.push({ row: rowNumber, message: 'El campo Archivado debe ser Sí/No o verdadero/falso.' });
            continue;
          }
          const parsed = parseProduct({
            name: spreadsheetText(record.name),
            barcode: spreadsheetText(record.barcode),
            category: category.name,
            categoryId: String(category.id),
            subcategoryId: subcategory ? String(subcategory.id) : null,
            campusId: String(campus.id),
            unitOfMeasure,
            stock: Number(record.stock),
            reorderLevel: Number(record.reorderLevel),
            price: Number(record.price),
            supplier: spreadsheetText(record.supplier),
            isConsumable,
            state: spreadsheetText(record.state) || 'Disponible',
            quality: spreadsheetText(record.quality) || 'Buena',
            characteristics: spreadsheetText(record.characteristics),
            description: spreadsheetText(record.description)
          });
          if (typeof parsed === 'string') {
            errors.push({ row: rowNumber, message: parsed });
            continue;
          }
          validRows.push({ rowNumber, product: parsed, isArchived });
        }

        const seenBarcodes = new Map();
        for (const item of validRows) {
          if (!item.product.barcode) continue;
          const barcode = item.product.barcode.toLocaleLowerCase('es');
          if (seenBarcodes.has(barcode)) {
            errors.push({ row: item.rowNumber, message: `Código de barras duplicado en la planilla (fila ${seenBarcodes.get(barcode)}).` });
          } else {
            seenBarcodes.set(barcode, item.rowNumber);
          }
        }
        if (seenBarcodes.size) {
          const existing = await client.query(
            `SELECT LOWER(barcode) AS barcode
             FROM products
             WHERE user_id = $1 AND barcode <> '' AND LOWER(barcode) = ANY($2::text[])`,
            [req.session.userId, [...seenBarcodes.keys()]]
          );
          const existingBarcodes = new Set(existing.rows.map((row) => row.barcode));
          for (const item of validRows) {
            const barcode = item.product.barcode.toLocaleLowerCase('es');
            if (barcode && existingBarcodes.has(barcode)) {
              errors.push({ row: item.rowNumber, message: `Ya existe un producto con el código de barras ${item.product.barcode}.` });
            }
          }
        }

        if (errors.length) {
          await client.query('ROLLBACK');
          return sendImportErrors(res, 'producto', errors);
        }
        for (const { product, isArchived } of validRows) {
          const code = `SKU-${randomBytes(4).toString('hex').toUpperCase()}`;
          await client.query(
            `INSERT INTO products
               (user_id, name, category, category_id, subcategory_id, campus_id, unit_of_measure,
                stock, reorder_level, price, supplier, code, barcode, state, quality, is_consumable,
                characteristics, description, is_archived)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)`,
            [
              req.session.userId,
              product.name,
              product.category,
              product.categoryId,
              product.subcategoryId,
              product.campusId,
              product.unitOfMeasure,
              product.stock,
              product.reorderLevel,
              product.price,
              product.supplier,
              code,
              product.barcode,
              product.state,
              product.quality,
              product.isConsumable,
              product.characteristics,
              product.description,
              isArchived
            ]
          );
        }
      }

      await client.query('COMMIT');
      return res.status(201).json({
        imported: rows.length,
        message: `Se importaron ${rows.length} ${type === 'clients' ? (rows.length === 1 ? 'cliente' : 'clientes') : (rows.length === 1 ? 'producto' : 'productos')}.`
      });
    } catch (error) {
      await client.query('ROLLBACK');
      if (error.code === '23505') {
        return res.status(409).json({
          error: 'Se detectó un registro duplicado durante la importación. No se guardó ningún dato; revisa los RUT o códigos de barras.'
        });
      }
      return next(error);
    } finally {
      client.release();
    }
  }
);

app.use('/api', (req, res) => {
  res.status(404).json({ error: 'Ruta de API no encontrada.' });
});

app.use(express.static(path.join(__dirname, 'public')));

app.use((error, req, res, next) => {
  console.error('Error en la solicitud:', error.message || error.code || error.name);
  if (res.headersSent) return next(error);
  if (error.type === 'entity.too.large') {
    return res.status(413).json({ error: 'La solicitud supera el tamaño máximo permitido.' });
  }
  return res.status(500).json({ error: 'Ocurrió un error interno. Inténtalo de nuevo.' });
});

let stockAlertTransporter = null;
let processingStockAlerts = false;

function createStockAlertTransporter() {
  const host = process.env.SMTP_HOST;
  const from = process.env.SMTP_FROM;
  if (!host || !from) {
    console.warn('Alertas por correo deshabilitadas: configura SMTP_HOST y SMTP_FROM para activarlas.');
    return null;
  }
  const port = process.env.SMTP_PORT === undefined ? 587 : Number(process.env.SMTP_PORT);
  if (!Number.isInteger(port) || port < 1 || port > 65535) {
    throw new Error('SMTP_PORT debe ser un puerto válido entre 1 y 65535.');
  }
  const hasUser = Boolean(process.env.SMTP_USER);
  const hasPassword = Boolean(process.env.SMTP_PASSWORD);
  if (hasUser !== hasPassword) {
    throw new Error('Configura SMTP_USER y SMTP_PASSWORD juntos, o deja ambos vacíos.');
  }
  const secureSetting = process.env.SMTP_SECURE;
  if (secureSetting !== undefined && !['true', 'false'].includes(secureSetting.toLowerCase())) {
    throw new Error('SMTP_SECURE debe ser true o false.');
  }
  const secure = process.env.SMTP_SECURE === undefined
    ? port === 465
    : secureSetting.toLowerCase() === 'true';
  return nodemailer.createTransport({
    host,
    port,
    secure,
    ...(hasUser ? { auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD } } : {}),
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 20000
  });
}

async function claimStockAlertEvents() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(
      `UPDATE stock_alert_events
       SET status = 'failed', last_error = 'Se agotaron los intentos después de una interrupción del servidor.'
       WHERE status = 'processing' AND attempt_count >= 5
         AND locked_at < NOW() - INTERVAL '10 minutes'`
    );
    const result = await client.query(
      `WITH available AS (
         SELECT id
         FROM stock_alert_events
         WHERE (status = 'pending' AND next_attempt_at <= NOW())
            OR (status = 'processing' AND attempt_count < 5
                AND locked_at < NOW() - INTERVAL '10 minutes')
         ORDER BY id
         LIMIT 10
         FOR UPDATE SKIP LOCKED
       )
       UPDATE stock_alert_events event
       SET status = 'processing', locked_at = NOW()
       FROM available
       WHERE event.id = available.id
       RETURNING event.id, event.user_id AS "userId", event.product_name AS "productName",
                 event.product_code AS "productCode", event.stock, event.reorder_level AS "reorderLevel",
                 event.alert_level AS "alertLevel", event.campus_name AS "campusName",
                 event.attempt_count AS "attemptCount"`
    );
    await client.query('COMMIT');
    return result.rows;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function updateStockAlertEvent(id, values) {
  await pool.query(
    `UPDATE stock_alert_events
     SET status = $2, last_error = $3, sent_at = CASE WHEN $2 = 'sent' THEN NOW() ELSE sent_at END,
         next_attempt_at = COALESCE($4, next_attempt_at),
         attempt_count = COALESCE($5, attempt_count), locked_at = NULL
     WHERE id = $1`,
    [id, values.status, values.error || null, values.nextAttemptAt || null, values.attemptCount ?? null]
  );
}

async function sendStockAlertEvent(event) {
  const recipients = await pool.query(
    `SELECT DISTINCT LOWER(email) AS email
     FROM clients
     WHERE user_id = $1 AND area IN ('Pañolero', 'Administración')
     ORDER BY email`,
    [event.userId]
  );
  const emailAddresses = recipients.rows.map((row) => row.email);
  if (!emailAddresses.length) {
    await updateStockAlertEvent(event.id, {
      status: 'pending',
      error: 'No hay correos registrados en las áreas Pañolero o Administración.',
      nextAttemptAt: new Date(Date.now() + 5 * 60 * 1000)
    });
    console.warn(`Alerta de stock ${event.id} pendiente: registra un cliente de Pañolero o Administración para recibirla.`);
    return;
  }

  const actualLevel = getStockAlertLevel(event.stock, event.reorderLevel);
  if (actualLevel !== event.alertLevel) {
    throw new Error('El nivel de alerta registrado no coincide con las existencias del producto.');
  }
  const message = createStockAlertMessage(event);
  await stockAlertTransporter.sendMail({
    from: process.env.SMTP_FROM,
    bcc: emailAddresses,
    subject: message.subject,
    text: message.text,
    html: message.html
  });
  await updateStockAlertEvent(event.id, { status: 'sent' });
  console.log(`Alerta de stock ${event.id} enviada a ${emailAddresses.length} destinatario(s).`);
}

async function processStockAlertQueue() {
  if (!stockAlertTransporter || processingStockAlerts) return;
  processingStockAlerts = true;
  try {
    const events = await claimStockAlertEvents();
    for (const event of events) {
      try {
        await sendStockAlertEvent(event);
      } catch (error) {
        const attemptCount = event.attemptCount + 1;
        const retryDelaySeconds = Math.min(1800, 30 * 2 ** (attemptCount - 1));
        const permanentlyFailed = attemptCount >= 5;
        try {
          await updateStockAlertEvent(event.id, {
            status: permanentlyFailed ? 'failed' : 'pending',
            error: error.message,
            attemptCount,
            nextAttemptAt: permanentlyFailed
              ? null
              : new Date(Date.now() + retryDelaySeconds * 1000)
          });
        } catch (updateError) {
          console.error(`No se pudo actualizar la alerta de stock ${event.id}:`, updateError.message);
        }
        console.error(
          `No se pudo enviar la alerta de stock ${event.id} (intento ${attemptCount}${permanentlyFailed ? ', sin más reintentos' : ''}):`,
          error.message
        );
      }
    }
  } finally {
    processingStockAlerts = false;
  }
}

function startStockAlertDelivery() {
  try {
    stockAlertTransporter = createStockAlertTransporter();
  } catch (error) {
    console.error('Alertas por correo deshabilitadas por configuración SMTP inválida:', error.message);
    return;
  }
  if (!stockAlertTransporter) return;
  const interval = setInterval(() => {
    processStockAlertQueue().catch((error) => {
      console.error('No se pudo procesar la cola de alertas de stock:', error.message);
    });
  }, 15000);
  interval.unref();
  processStockAlertQueue().catch((error) => {
    console.error('No se pudo procesar la cola inicial de alertas de stock:', error.message);
  });
}

if (!process.env.SESSION_SECRET) {
  console.warn('SESSION_SECRET no está configurado; los usuarios deberán iniciar sesión de nuevo después de reiniciar el servidor.');
}

async function initializeDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role VARCHAR(20) NOT NULL DEFAULT 'user',
      owner_user_id BIGINT REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query("ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(20) NOT NULL DEFAULT 'user'");
  await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS owner_user_id BIGINT REFERENCES users(id) ON DELETE CASCADE');
  await pool.query('ALTER TABLE users ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()');
  await pool.query('UPDATE users SET owner_user_id = id WHERE owner_user_id IS NULL');

  const adminEmail = process.env.ADMIN_EMAIL;
  const adminPassword = process.env.ADMIN_PASSWORD;
  if (Boolean(adminEmail) !== Boolean(adminPassword)) {
    throw new Error('Configura ADMIN_EMAIL y ADMIN_PASSWORD juntos para crear la cuenta administradora inicial.');
  }
  if (adminEmail && adminPassword) {
    const credentials = parseUserCredentials({ email: adminEmail, password: adminPassword });
    if (typeof credentials === 'string') {
      throw new Error(`La cuenta administradora inicial no es válida: ${credentials}`);
    }
    const existingAdminAccount = await pool.query(
      'SELECT id FROM users WHERE email = $1',
      [credentials.email]
    );
    if (existingAdminAccount.rows[0]) {
      await pool.query(
        "UPDATE users SET role = 'admin', owner_user_id = id WHERE id = $1",
        [existingAdminAccount.rows[0].id]
      );
    } else {
      const passwordHash = await bcrypt.hash(credentials.password, 12);
      const createdAdmin = await pool.query(
        `INSERT INTO users (email, password_hash, role)
         VALUES ($1, $2, 'admin')
         RETURNING id`,
        [credentials.email, passwordHash]
      );
      await pool.query(
        'UPDATE users SET owner_user_id = id WHERE id = $1',
        [createdAdmin.rows[0].id]
      );
    }
  }

  await pool.query('ALTER TABLE users ALTER COLUMN owner_user_id SET NOT NULL');
  await pool.query('CREATE INDEX IF NOT EXISTS users_owner_idx ON users (owner_user_id)');
  const adminCount = await pool.query("SELECT 1 FROM users WHERE role = 'admin' LIMIT 1");
  if (!adminCount.rowCount) {
    throw new Error('No hay una cuenta administradora. Configura ADMIN_EMAIL y ADMIN_PASSWORD en el entorno y reinicia el servidor.');
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS campuses (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(100) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS campuses_user_name_idx
    ON campuses (user_id, LOWER(name))
  `);
  await pool.query(
    `INSERT INTO campuses (user_id, name)
     SELECT users.id, campus.name
     FROM users CROSS JOIN unnest($1::text[]) AS campus(name)
     WHERE users.owner_user_id = users.id
       AND NOT EXISTS (
       SELECT 1 FROM campuses existing WHERE existing.user_id = users.id
     )
     ON CONFLICT DO NOTHING`,
    [DEFAULT_CAMPUSES]
  );
  await pool.query(`
    CREATE TABLE IF NOT EXISTS academic_programs (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(120) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS academic_programs_user_name_idx
    ON academic_programs (user_id, LOWER(name))
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS academic_subjects (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      career_id BIGINT NOT NULL REFERENCES academic_programs(id) ON DELETE CASCADE,
      name VARCHAR(120) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS academic_subjects_career_name_idx
    ON academic_subjects (career_id, LOWER(name))
  `);
  await pool.query('CREATE INDEX IF NOT EXISTS academic_subjects_user_idx ON academic_subjects (user_id, career_id)');
  await pool.query(`
    CREATE TABLE IF NOT EXISTS invoices (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      supplier_rut VARCHAR(12) NOT NULL,
      invoice_number VARCHAR(100) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS invoices_supplier_number_idx
    ON invoices (user_id, supplier_rut, LOWER(BTRIM(invoice_number)))
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS product_units_of_measure (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(20) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS products (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      campus_id BIGINT REFERENCES campuses(id),
      name VARCHAR(160) NOT NULL,
      category VARCHAR(80) NOT NULL,
      stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
      reorder_level INTEGER NOT NULL DEFAULT 0 CHECK (reorder_level >= 0),
      price NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (price >= 0),
      supplier VARCHAR(160) NOT NULL DEFAULT '',
      code VARCHAR(20) NOT NULL,
      is_consumable BOOLEAN NOT NULL DEFAULT FALSE,
      state VARCHAR(30) NOT NULL DEFAULT 'Disponible',
      quality VARCHAR(20) NOT NULL DEFAULT 'Buena',
      characteristics TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      image_data BYTEA,
      image_mime_type VARCHAR(30),
      is_archived BOOLEAN NOT NULL DEFAULT FALSE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (user_id, code)
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS inventory_write_offs (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
      codigo VARCHAR(20) NOT NULL,
      write_off_date DATE NOT NULL,
      bodega VARCHAR(100) NOT NULL,
      ubicacion VARCHAR(160) NOT NULL,
      cantidad INTEGER NOT NULL CHECK (cantidad > 0),
      razon VARCHAR(200) NOT NULL,
      observacion TEXT NOT NULL DEFAULT '',
      is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      deleted_at TIMESTAMPTZ,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS inventory_write_offs_user_date_idx
    ON inventory_write_offs (user_id, write_off_date DESC, id DESC)
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS inventory_write_offs_product_active_idx
    ON inventory_write_offs (product_id)
    WHERE is_deleted = FALSE
  `);
  await pool.query("ALTER TABLE products ADD COLUMN IF NOT EXISTS barcode VARCHAR(80) NOT NULL DEFAULT ''");
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS products_user_barcode_idx
    ON products (user_id, LOWER(barcode))
    WHERE barcode <> ''
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS product_categories (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(80) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS product_subcategories (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      category_id BIGINT NOT NULL REFERENCES product_categories(id) ON DELETE CASCADE,
      name VARCHAR(80) NOT NULL,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS product_categories_user_name_idx
    ON product_categories (user_id, LOWER(name))
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS product_subcategories_category_name_idx
    ON product_subcategories (category_id, LOWER(name))
  `);
  await pool.query(`
    CREATE UNIQUE INDEX IF NOT EXISTS product_units_user_name_idx
    ON product_units_of_measure (user_id, LOWER(name))
  `);
  await pool.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS category_id BIGINT REFERENCES product_categories(id)');
  await pool.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS subcategory_id BIGINT REFERENCES product_subcategories(id)');
  await pool.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS campus_id BIGINT REFERENCES campuses(id)');
  await pool.query(
    `UPDATE products p
     SET campus_id = c.id
     FROM campuses c
     WHERE p.campus_id IS NULL AND p.user_id = c.user_id AND c.name = 'Sede por asignar'`
  );
  await pool.query('ALTER TABLE products ALTER COLUMN campus_id SET NOT NULL');
  await pool.query('CREATE INDEX IF NOT EXISTS products_campus_idx ON products (user_id, campus_id)');
  await pool.query("ALTER TABLE products ADD COLUMN IF NOT EXISTS unit_of_measure VARCHAR(20) NOT NULL DEFAULT 'Unidades'");
  await pool.query(
    `INSERT INTO product_units_of_measure (user_id, name)
     SELECT DISTINCT p.user_id, BTRIM(p.unit_of_measure)
     FROM products p
     WHERE BTRIM(p.unit_of_measure) <> ''
     ON CONFLICT DO NOTHING`
  );
  await pool.query(
    `INSERT INTO product_units_of_measure (user_id, name)
     SELECT users.id, unit.name
     FROM users CROSS JOIN unnest($1::text[]) AS unit(name)
     WHERE users.owner_user_id = users.id
     ON CONFLICT DO NOTHING`,
    [DEFAULT_UNITS_OF_MEASURE]
  );
  await pool.query(
    `INSERT INTO product_categories (user_id, name)
     SELECT users.id, category.name
     FROM users CROSS JOIN unnest($1::text[]) AS category(name)
     WHERE users.owner_user_id = users.id
     ON CONFLICT DO NOTHING`,
    [DEFAULT_CATEGORIES]
  );
  await pool.query(
    `INSERT INTO product_categories (user_id, name)
     SELECT DISTINCT ON (p.user_id, LOWER(BTRIM(p.category)))
            p.user_id, BTRIM(p.category)
     FROM products p
     WHERE BTRIM(p.category) <> ''
     ORDER BY p.user_id, LOWER(BTRIM(p.category)), BTRIM(p.category)
     ON CONFLICT DO NOTHING`
  );
  await pool.query(
    `UPDATE products p SET category_id = c.id
     FROM product_categories c
     WHERE p.category_id IS NULL AND p.user_id = c.user_id
       AND LOWER(BTRIM(p.category)) = LOWER(c.name)`
  );
  await pool.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS is_consumable BOOLEAN NOT NULL DEFAULT FALSE');
  await pool.query("ALTER TABLE products ADD COLUMN IF NOT EXISTS state VARCHAR(30) NOT NULL DEFAULT 'Disponible'");
  await pool.query("ALTER TABLE products ADD COLUMN IF NOT EXISTS quality VARCHAR(20) NOT NULL DEFAULT 'Buena'");
  await pool.query("ALTER TABLE products ADD COLUMN IF NOT EXISTS characteristics TEXT NOT NULL DEFAULT ''");
  await pool.query("ALTER TABLE products ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT ''");
  await pool.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS image_data BYTEA');
  await pool.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS image_mime_type VARCHAR(30)');
  await pool.query('ALTER TABLE products ADD COLUMN IF NOT EXISTS is_archived BOOLEAN NOT NULL DEFAULT FALSE');
  await pool.query(`
    CREATE TABLE IF NOT EXISTS clients (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name VARCHAR(160) NOT NULL,
      rut VARCHAR(12) NOT NULL,
      email VARCHAR(254) NOT NULL,
      area VARCHAR(30) NOT NULL CHECK (area IN ('Estudiante', 'Profesor', 'Administración')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (user_id, rut)
    )
  `);
  await pool.query('ALTER TABLE clients DROP CONSTRAINT IF EXISTS clients_area_check');
  await pool.query(`
    ALTER TABLE clients
    ADD CONSTRAINT clients_area_check
    CHECK (area IN ('Estudiante', 'Profesor', 'Administración', 'Pañolero'))
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS stock_alert_events (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      product_name VARCHAR(160) NOT NULL,
      product_code VARCHAR(20) NOT NULL,
      stock INTEGER NOT NULL CHECK (stock >= 0),
      reorder_level INTEGER NOT NULL CHECK (reorder_level >= 0),
      alert_level VARCHAR(10) NOT NULL CHECK (alert_level IN ('low', 'out')),
      campus_name VARCHAR(160) NOT NULL DEFAULT 'Sin sede',
      status VARCHAR(12) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'processing', 'sent', 'skipped', 'failed')),
      attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0),
      next_attempt_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      locked_at TIMESTAMPTZ,
      sent_at TIMESTAMPTZ,
      last_error TEXT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS stock_alert_events_pending_idx
    ON stock_alert_events (status, next_attempt_at, id)
    WHERE status IN ('pending', 'processing')
  `);
  await pool.query(`
    CREATE OR REPLACE FUNCTION queue_product_stock_alert()
    RETURNS TRIGGER AS $$
    DECLARE
      previous_level TEXT := 'normal';
      current_level TEXT;
    BEGIN
      current_level := CASE
        WHEN NEW.stock = 0 THEN 'out'
        WHEN NEW.stock <= NEW.reorder_level THEN 'low'
        ELSE 'normal'
      END;

      IF TG_OP = 'UPDATE' THEN
        previous_level := CASE
          WHEN OLD.stock = 0 THEN 'out'
          WHEN OLD.stock <= OLD.reorder_level THEN 'low'
          ELSE 'normal'
        END;
      END IF;

      IF NEW.is_archived = FALSE
         AND current_level <> 'normal'
         AND (
           previous_level = 'normal'
           OR (previous_level = 'low' AND current_level = 'out')
           OR (TG_OP = 'UPDATE' AND OLD.is_archived = TRUE)
         ) THEN
        INSERT INTO stock_alert_events
          (user_id, product_id, product_name, product_code, stock, reorder_level,
           alert_level, campus_name)
        VALUES (
          NEW.user_id,
          NEW.id,
          NEW.name,
          NEW.code,
          NEW.stock,
          NEW.reorder_level,
          current_level,
          COALESCE(
            (SELECT name FROM campuses WHERE id = NEW.campus_id AND user_id = NEW.user_id),
            'Sin sede'
          )
        );
      END IF;
      RETURN NEW;
    END;
    $$ LANGUAGE plpgsql
  `);
  await pool.query('DROP TRIGGER IF EXISTS products_stock_alert_trigger ON products');
  await pool.query(`
    CREATE TRIGGER products_stock_alert_trigger
    AFTER INSERT OR UPDATE
    ON products
    FOR EACH ROW
    EXECUTE FUNCTION queue_product_stock_alert()
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS stock_alert_migrations (
      migration_key VARCHAR(100) PRIMARY KEY,
      completed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  const alertMigrationClient = await pool.connect();
  try {
    await alertMigrationClient.query('BEGIN');
    const seedResult = await alertMigrationClient.query(
      `INSERT INTO stock_alert_migrations (migration_key)
       VALUES ('initial_low_stock_alerts')
       ON CONFLICT DO NOTHING
       RETURNING migration_key`
    );
    if (seedResult.rowCount) {
      await alertMigrationClient.query(
        `INSERT INTO stock_alert_events
           (user_id, product_id, product_name, product_code, stock, reorder_level,
            alert_level, campus_name)
         SELECT p.user_id, p.id, p.name, p.code, p.stock, p.reorder_level,
                CASE WHEN p.stock = 0 THEN 'out' ELSE 'low' END,
                COALESCE(c.name, 'Sin sede')
         FROM products p
         LEFT JOIN campuses c ON c.id = p.campus_id AND c.user_id = p.user_id
         WHERE p.is_archived = FALSE AND p.stock <= p.reorder_level`
      );
    }
    await alertMigrationClient.query('COMMIT');
  } catch (error) {
    await alertMigrationClient.query('ROLLBACK');
    throw error;
  } finally {
    alertMigrationClient.release();
  }
  await pool.query(`
    CREATE TABLE IF NOT EXISTS loans (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      campus_id BIGINT REFERENCES campuses(id),
      product_id BIGINT REFERENCES products(id) ON DELETE RESTRICT,
      loan_date DATE NOT NULL DEFAULT CURRENT_DATE,
      rut VARCHAR(20) NOT NULL,
      area VARCHAR(120) NOT NULL,
      subject VARCHAR(160) NOT NULL,
      quantity INTEGER CHECK (quantity > 0),
      due_date DATE,
      journey VARCHAR(30) NOT NULL DEFAULT 'Sin especificar',
      is_consumable BOOLEAN NOT NULL DEFAULT FALSE,
      returned_quantity INTEGER
        CHECK (returned_quantity >= 0 AND returned_quantity <= quantity),
      is_deleted BOOLEAN NOT NULL DEFAULT FALSE,
      deleted_at TIMESTAMPTZ,
      deleted_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
      cancelled_quantity INTEGER NOT NULL DEFAULT 0 CHECK (cancelled_quantity >= 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS start_time TIME');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS end_time TIME');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS career_id BIGINT REFERENCES academic_programs(id)');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS subject_id BIGINT REFERENCES academic_subjects(id)');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS client_id BIGINT REFERENCES clients(id) ON DELETE RESTRICT');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS client_name VARCHAR(160)');
  await pool.query('CREATE INDEX IF NOT EXISTS loans_career_idx ON loans (user_id, career_id)');
  await pool.query('CREATE INDEX IF NOT EXISTS loans_subject_idx ON loans (user_id, subject_id)');
  await pool.query('CREATE INDEX IF NOT EXISTS loans_client_idx ON loans (user_id, client_id)');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS due_date DATE');
  await pool.query("ALTER TABLE loans ADD COLUMN IF NOT EXISTS journey VARCHAR(30) NOT NULL DEFAULT 'Sin especificar'");
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS campus_id BIGINT REFERENCES campuses(id)');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS is_consumable BOOLEAN NOT NULL DEFAULT FALSE');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN NOT NULL DEFAULT FALSE');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMPTZ');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS deleted_by BIGINT REFERENCES users(id) ON DELETE SET NULL');
  await pool.query('ALTER TABLE loans ADD COLUMN IF NOT EXISTS cancelled_quantity INTEGER NOT NULL DEFAULT 0');
  await pool.query(
    `UPDATE loans l
     SET campus_id = c.id
     FROM campuses c
     WHERE l.campus_id IS NULL AND l.user_id = c.user_id AND c.name = 'Sede por asignar'`
  );
  await pool.query('ALTER TABLE loans ALTER COLUMN campus_id SET NOT NULL');
  await pool.query('ALTER TABLE loans ALTER COLUMN product_id DROP NOT NULL');
  await pool.query('ALTER TABLE loans ALTER COLUMN quantity DROP NOT NULL');
  await pool.query('ALTER TABLE loans ALTER COLUMN returned_quantity DROP NOT NULL');
  await pool.query(`
    CREATE TABLE IF NOT EXISTS loan_items (
      id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
      loan_id BIGINT NOT NULL REFERENCES loans(id) ON DELETE CASCADE,
      product_id BIGINT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
      quantity INTEGER NOT NULL CHECK (quantity > 0),
      returned_quantity INTEGER NOT NULL DEFAULT 0
        CHECK (returned_quantity >= 0 AND returned_quantity <= quantity),
      is_consumable BOOLEAN NOT NULL DEFAULT FALSE,
      cancelled_quantity INTEGER NOT NULL DEFAULT 0 CHECK (cancelled_quantity >= 0),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      UNIQUE (loan_id, product_id)
    )
  `);
  await pool.query(
    `INSERT INTO loan_items
       (loan_id, product_id, quantity, returned_quantity, is_consumable, cancelled_quantity)
     SELECT l.id, l.product_id, l.quantity, l.returned_quantity, l.is_consumable, l.cancelled_quantity
     FROM loans l
     WHERE l.product_id IS NOT NULL
     ON CONFLICT (loan_id, product_id) DO NOTHING`
  );
  await pool.query(
    `UPDATE loans l
     SET product_id = NULL, quantity = NULL, returned_quantity = NULL
     WHERE l.product_id IS NOT NULL
       AND EXISTS (SELECT 1 FROM loan_items li WHERE li.loan_id = l.id)`
  );
  await pool.query(`
    CREATE INDEX IF NOT EXISTS loan_items_product_idx
    ON loan_items (product_id, loan_id)
  `);
  await pool.query(`
    CREATE INDEX IF NOT EXISTS loans_user_date_idx
    ON loans (user_id, loan_date DESC, id DESC)
  `);
}

async function start() {
  await initializeDatabase();
  startStockAlertDelivery();
  const port = Number(process.env.PORT) || 3000;
  app.listen(port, () => {
    console.log(`StockFlow está disponible en http://localhost:${port}`);
  });
}

if (require.main === module) {
  start().catch((error) => {
    console.error('No se pudo iniciar StockFlow:', error.message || error.code || error.name);
    process.exitCode = 1;
  });
}

module.exports = {
  app,
  pool,
  parseProduct,
  parseClient,
  parseLoan,
  parseInvoice,
  normalizeSupplierRut,
  parseWriteOff,
  parseUserCredentials,
  requireAdmin,
  isValidProductId
};
