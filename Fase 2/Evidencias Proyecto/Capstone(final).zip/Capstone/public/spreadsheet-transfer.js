const SPREADSHEET_MIME_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

async function getResponseError(response) {
  let result;
  try {
    result = await response.json();
  } catch {
    return new Error('No se pudo completar la operación con el archivo Excel.');
  }
  const error = new Error(result.error || 'No se pudo completar la operación con el archivo Excel.');
  error.details = Array.isArray(result.errors) ? result.errors : [];
  error.totalErrors = Number(result.totalErrors) || error.details.length;
  throw error;
}

export async function importSpreadsheet(type, file) {
  const response = await fetch(`/api/spreadsheets/${encodeURIComponent(type)}/import`, {
    method: 'POST',
    headers: { 'Content-Type': SPREADSHEET_MIME_TYPE },
    body: file
  });
  if (!response.ok) throw await getResponseError(response);
  return response.json();
}

export async function downloadSpreadsheet(url, filename) {
  const response = await fetch(url);
  if (!response.ok) throw await getResponseError(response);
  const blob = await response.blob();
  const objectUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = objectUrl;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}
