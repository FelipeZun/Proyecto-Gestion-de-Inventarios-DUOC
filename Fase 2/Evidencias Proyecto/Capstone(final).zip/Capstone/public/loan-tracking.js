function getLocalDateTime(date, time) {
  const [year, month, day] = date.split('-').map(Number);
  const [hour, minute, second = 0] = time.split(':').map(Number);
  return new Date(year, month - 1, day, hour, minute, second).getTime();
}

export function getLoanDueStatus(items, now = new Date()) {
  const reusableItems = items.filter((item) => !item.isConsumable);
  const hasOutstanding = reusableItems.some((item) => Number(item.outstanding) > 0);
  if (!hasOutstanding) {
    return reusableItems.length ? 'completed' : 'consumed';
  }
  const { dueDate, endTime } = items[0];
  if (!dueDate) return 'pending';
  const deadline = getLocalDateTime(dueDate, endTime || '23:59:59');
  const remainingTime = deadline - now.getTime();
  if (remainingTime < 0) return 'overdue';
  if (remainingTime <= 7 * 86400000) return 'due-soon';
  return 'pending';
}

export function updateLoanAttention(loans, attentionElement) {
  const groups = new Map();
  for (const loan of loans) {
    if (!groups.has(String(loan.id))) groups.set(String(loan.id), []);
    groups.get(String(loan.id)).push(loan);
  }
  let eveningOverdue = 0;
  let eveningDueSoon = 0;
  for (const items of groups.values()) {
    const journey = items[0].journey || 'Sin especificar';
    const status = getLoanDueStatus(items);
    if (journey !== 'Vespertina') continue;
    if (status === 'overdue') eveningOverdue += 1;
    if (status === 'due-soon') eveningDueSoon += 1;
  }
  attentionElement.textContent = eveningOverdue || eveningDueSoon
    ? `Jornada vespertina: ${eveningOverdue} ${eveningOverdue === 1 ? 'préstamo vencido' : 'préstamos vencidos'} y ${eveningDueSoon} ${eveningDueSoon === 1 ? 'préstamo por vencer' : 'préstamos por vencer'} dentro de los próximos 7 días.`
    : 'Jornada vespertina: no hay préstamos vencidos ni con vencimiento dentro de los próximos 7 días.';
  attentionElement.classList.toggle('has-overdue', eveningOverdue > 0);
}
