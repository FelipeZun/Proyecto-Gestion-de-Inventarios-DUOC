export function createBarcodeScanner() {
  const productBarcode = document.getElementById('productBarcode');
  const startBarcodeScan = document.getElementById('startBarcodeScan');
  const stopBarcodeScanButton = document.getElementById('stopBarcodeScan');
  const barcodeVideo = document.getElementById('barcodeVideo');
  const barcodeStatus = document.getElementById('barcodeStatus');
  let stream = null;
  let scanActive = false;

  function stop(message = 'Escaneo detenido.') {
    scanActive = false;
    if (stream) {
      stream.getTracks().forEach((track) => track.stop());
      stream = null;
    }
    barcodeVideo.pause();
    barcodeVideo.srcObject = null;
    barcodeVideo.hidden = true;
    stopBarcodeScanButton.hidden = true;
    startBarcodeScan.hidden = false;
    barcodeStatus.textContent = message;
  }

  async function scan(detector) {
    while (scanActive) {
      if (barcodeVideo.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA) {
        const detected = await detector.detect(barcodeVideo);
        if (!scanActive) return;
        if (detected.length && detected[0].rawValue) {
          productBarcode.value = detected[0].rawValue.slice(0, 80);
          stop('Código detectado. Verifica el valor antes de guardar.');
          return;
        }
      }
      await new Promise((resolve) => requestAnimationFrame(resolve));
    }
  }

  async function start() {
    if (!window.isSecureContext) {
      barcodeStatus.textContent = 'Para usar la cámara, abre la aplicación mediante HTTPS o localhost.';
      return;
    }
    const Detector = globalThis.BarcodeDetector;
    if (!Detector || !navigator.mediaDevices?.getUserMedia) {
      barcodeStatus.textContent = 'Este navegador no permite escanear con cámara. Ingresa el código o usa un lector USB.';
      return;
    }

    startBarcodeScan.disabled = true;
    barcodeStatus.textContent = 'Solicitando acceso a la cámara...';
    scanActive = true;
    try {
      const supportedFormats = await Detector.getSupportedFormats();
      const formats = ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf', 'codabar']
        .filter((format) => supportedFormats.includes(format));
      if (!formats.length) {
        throw new Error('El navegador no admite formatos de códigos de barras compatibles.');
      }
      const detector = new Detector({ formats });
      const cameraStream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: { facingMode: { ideal: 'environment' } }
      });
      if (!scanActive) {
        cameraStream.getTracks().forEach((track) => track.stop());
        return;
      }
      stream = cameraStream;
      barcodeVideo.srcObject = stream;
      barcodeVideo.hidden = false;
      await barcodeVideo.play();
      startBarcodeScan.hidden = true;
      stopBarcodeScanButton.hidden = false;
      barcodeStatus.textContent = 'Apunta la cámara al código de barras.';
      await scan(detector);
    } catch (error) {
      stop(`No se pudo iniciar el escaneo: ${error.message}`);
    } finally {
      startBarcodeScan.disabled = false;
    }
  }

  startBarcodeScan.addEventListener('click', start);
  stopBarcodeScanButton.addEventListener('click', () => stop());
  return { stop };
}
