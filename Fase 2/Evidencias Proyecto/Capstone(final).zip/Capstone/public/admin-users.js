import { apiRequest, escapeHtml } from './api.js';

const usersForm = document.getElementById('usersForm');
const usersEmail = document.getElementById('usersEmail');
const usersPassword = document.getElementById('usersPassword');
const usersTableBody = document.getElementById('usersTableBody');
const usersError = document.getElementById('usersError');
const usersMessage = document.getElementById('usersMessage');
let users = [];

export function showUsersError(message) {
  usersError.textContent = message;
  usersError.hidden = !message;
}

function showUsersMessage(message) {
  usersMessage.textContent = message;
  usersMessage.hidden = !message;
}

function renderAdminUsers() {
  usersTableBody.innerHTML = users.length
    ? users.map((user) => `
        <tr>
          <td>${escapeHtml(user.email)}</td>
          <td>${user.role === 'admin' ? 'Administrador' : 'Usuario'}</td>
          <td>${escapeHtml(new Intl.DateTimeFormat('es').format(new Date(user.createdAt)))}</td>
        </tr>
      `).join('')
    : '<tr><td class="empty-state" colspan="3">No hay cuentas registradas.</td></tr>';
}

export async function loadAdminUsers() {
  const result = await apiRequest('/api/admin/users');
  users = result.users;
  renderAdminUsers();
  showUsersError('');
}

export function clearAdminUsers() {
  users = [];
  usersTableBody.replaceChildren();
  showUsersMessage('');
  showUsersError('');
}

usersForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showUsersError('');
  showUsersMessage('');
  const submitButton = usersForm.querySelector('button[type="submit"]');
  submitButton.disabled = true;
  try {
    const result = await apiRequest('/api/admin/users', {
      method: 'POST',
      body: JSON.stringify({ email: usersEmail.value, password: usersPassword.value })
    });
    usersForm.reset();
    await loadAdminUsers();
    showUsersMessage(`Se creó la cuenta ${result.user.email}. Comunica la contraseña inicial mediante un canal privado y seguro.`);
  } catch (error) {
    showUsersError(error.message);
  } finally {
    submitButton.disabled = false;
  }
});
