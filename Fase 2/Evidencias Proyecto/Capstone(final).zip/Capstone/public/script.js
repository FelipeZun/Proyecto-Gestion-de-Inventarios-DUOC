import {
  apiRequest,
  escapeHtml,
  formatCurrency,
  formatDateOnly,
  normalizeChileanRut,
  formatLoanDateTime,
  formatLoanTime,
  getLocalDateValue,
  readImageAsDataUrl
} from './api.js';
import { createBarcodeScanner } from './barcode-scanner.js';
import { clearAdminUsers, loadAdminUsers, showUsersError } from './admin-users.js';
import { getLoanDueStatus, updateLoanAttention } from './loan-tracking.js';
import { downloadSpreadsheet, importSpreadsheet } from './spreadsheet-transfer.js';
import { renderManualMarkdown } from './manual-view.js';

const authView = document.getElementById('authView');
const appShell = document.getElementById('appShell');
const authForm = document.getElementById('authForm');
const authEmail = document.getElementById('authEmail');
const authPassword = document.getElementById('authPassword');
const authError = document.getElementById('authError');
const authTitle = document.getElementById('authTitle');
const authSubmit = document.getElementById('authSubmit');
const signedInEmail = document.getElementById('signedInEmail');
const dashboardPage = document.getElementById('dashboardPage');
const inventoryPage = document.getElementById('inventoryPage');
const writeOffPage = document.getElementById('writeOffPage');
const classificationsPage = document.getElementById('classificationsPage');
const campusesPage = document.getElementById('campusesPage');
const academicCatalogPage = document.getElementById('academicCatalogPage');
const invoicesPage = document.getElementById('invoicesPage');
const clientsPage = document.getElementById('clientsPage');
const loansPage = document.getElementById('loansPage');
const loanHistoryPage = document.getElementById('loanHistoryPage');
const usersPage = document.getElementById('usersPage');
const manualPage = document.getElementById('manualPage');
const dashboardNav = document.getElementById('dashboardNav');
const inventoryNav = document.getElementById('inventoryNav');
const writeOffNav = document.getElementById('writeOffNav');
const classificationsNav = document.getElementById('classificationsNav');
const campusesNav = document.getElementById('campusesNav');
const academicCatalogNav = document.getElementById('academicCatalogNav');
const invoicesNav = document.getElementById('invoicesNav');
const clientsNav = document.getElementById('clientsNav');
const loansNav = document.getElementById('loansNav');
const loanHistoryNav = document.getElementById('loanHistoryNav');
const usersNav = document.getElementById('usersNav');
const manualNav = document.getElementById('manualNav');
const inventorySearch = document.getElementById('inventorySearch');
const pageEyebrow = document.getElementById('pageEyebrow');
const pageTitle = document.getElementById('pageTitle');
const userManualContent = document.getElementById('userManualContent');
const manualError = document.getElementById('manualError');
const inventoryTableBody = document.getElementById('inventoryTableBody');
const productCategory = document.getElementById('productCategory');
const productSubcategory = document.getElementById('productSubcategory');
const productUnitOfMeasure = document.getElementById('productUnitOfMeasure');
const classificationsList = document.getElementById('classificationsList');
const campusesList = document.getElementById('campusesList');
const academicCatalogList = document.getElementById('academicCatalogList');
const invoicesTableBody = document.getElementById('invoicesTableBody');
const clientsTableBody = document.getElementById('clientsTableBody');
const exportProductsButton = document.getElementById('exportProductsButton');
const productTemplateButton = document.getElementById('productTemplateButton');
const importProductsButton = document.getElementById('importProductsButton');
const importProductsFile = document.getElementById('importProductsFile');
const productsTransferError = document.getElementById('productsTransferError');
const productsTransferMessage = document.getElementById('productsTransferMessage');
const exportClientsButton = document.getElementById('exportClientsButton');
const clientTemplateButton = document.getElementById('clientTemplateButton');
const importClientsButton = document.getElementById('importClientsButton');
const importClientsFile = document.getElementById('importClientsFile');
const clientsTransferError = document.getElementById('clientsTransferError');
const clientsTransferMessage = document.getElementById('clientsTransferMessage');
const writeOffsTableBody = document.getElementById('writeOffsTableBody');
const classificationError = document.getElementById('classificationError');
const classificationMessage = document.getElementById('classificationMessage');
const campusForm = document.getElementById('campusForm');
const campusError = document.getElementById('campusError');
const campusMessage = document.getElementById('campusMessage');
const academicCatalogError = document.getElementById('academicCatalogError');
const academicCatalogMessage = document.getElementById('academicCatalogMessage');
const invoiceError = document.getElementById('invoiceError');
const invoiceMessage = document.getElementById('invoiceMessage');
const clientError = document.getElementById('clientError');
const clientMessage = document.getElementById('clientMessage');
const writeOffError = document.getElementById('writeOffError');
const writeOffMessage = document.getElementById('writeOffMessage');
const productCampus = document.getElementById('productCampus');
const loanCampus = document.getElementById('loanCampus');
const loanClient = document.getElementById('loanClient');
const loanCareer = document.getElementById('loanCareer');
const loanSubject = document.getElementById('loanSubject');
const categoryForm = document.getElementById('categoryForm');
const subcategoryForm = document.getElementById('subcategoryForm');
const unitForm = document.getElementById('unitForm');
const careerForm = document.getElementById('careerForm');
const subjectForm = document.getElementById('subjectForm');
const subjectCareer = document.getElementById('subjectCareer');
const invoiceForm = document.getElementById('invoiceForm');
const invoiceFormTitle = document.getElementById('invoiceFormTitle');
const invoiceSubmit = document.getElementById('invoiceSubmit');
const cancelInvoiceEdit = document.getElementById('cancelInvoiceEdit');
const clientForm = document.getElementById('clientForm');
const clientFormTitle = document.getElementById('clientFormTitle');
const clientSubmit = document.getElementById('clientSubmit');
const cancelClientEdit = document.getElementById('cancelClientEdit');
const writeOffForm = document.getElementById('writeOffForm');
const writeOffFormTitle = document.getElementById('writeOffFormTitle');
const writeOffProduct = document.getElementById('writeOffProduct');
const writeOffWarehouse = document.getElementById('writeOffWarehouse');
const writeOffDate = document.getElementById('writeOffDate');
const writeOffQuantity = document.getElementById('writeOffQuantity');
const writeOffStockHint = document.getElementById('writeOffStockHint');
const writeOffSubmit = document.getElementById('writeOffSubmit');
const cancelWriteOffEdit = document.getElementById('cancelWriteOffEdit');
const toggleDeletedWriteOffs = document.getElementById('toggleDeletedWriteOffs');
const subcategoryParent = document.getElementById('subcategoryParent');
const unitOptionsList = document.getElementById('unitOptionsList');
const toggleArchived = document.getElementById('toggleArchived');
const totalItemsValue = document.getElementById('totalItemsValue');
const lowStockValue = document.getElementById('lowStockValue');
const inventoryValue = document.getElementById('inventoryValue');
const lowStockList = document.getElementById('lowStockList');
const searchInput = document.getElementById('searchInput');
const stockForm = document.getElementById('stockForm');
const stockError = document.getElementById('stockError');
const stockMessage = document.getElementById('stockMessage');
const stockFormTitle = document.getElementById('stockFormTitle');
const stockSubmit = document.getElementById('stockSubmit');
const cancelEdit = document.getElementById('cancelEdit');
const inventoryListTab = document.getElementById('inventoryListTab');
const productCreateTab = document.getElementById('productCreateTab');
const inventoryListPanel = document.getElementById('inventoryListPanel');
const productCreatePanel = document.getElementById('productCreatePanel');
const productImage = document.getElementById('productImage');
const productImagePreview = document.getElementById('productImagePreview');
const productBarcode = document.getElementById('productBarcode');
const productIsConsumable = document.getElementById('productIsConsumable');
const productState = document.getElementById('productState');
const productQuality = document.getElementById('productQuality');
const loanForm = document.getElementById('loanForm');
const loanDate = document.getElementById('loanDate');
const loanStartTime = document.getElementById('loanStartTime');
const loanEndTime = document.getElementById('loanEndTime');
const loanDueDate = document.getElementById('loanDueDate');
const loanItemsContainer = document.getElementById('loanItems');
const addLoanItemButton = document.getElementById('addLoanItem');
const loanError = document.getElementById('loanError');
const loanMessage = document.getElementById('loanMessage');
const loanSubmit = document.getElementById('loanSubmit');
const loansTableBody = document.getElementById('loansTableBody');
const loanHistoryTableBody = document.getElementById('loanHistoryTableBody');
const loanListTab = document.getElementById('loanListTab');
const loanCreateTab = document.getElementById('loanCreateTab');
const loanListPanel = document.getElementById('loanListPanel');
const loanCreatePanel = document.getElementById('loanCreatePanel');
const loanJourney = document.getElementById('loanJourney');
const loanJourneyFilter = document.getElementById('loanJourneyFilter');
const loanStatusFilter = document.getElementById('loanStatusFilter');
const loanAttention = document.getElementById('loanAttention');
const loanRut = document.getElementById('loanRut');
const loanArea = document.getElementById('loanArea');
const inventoryCategoryFilter = document.getElementById('inventoryCategoryFilter');
const inventoryCampusFilter = document.getElementById('inventoryCampusFilter');
const inventoryStockFilter = document.getElementById('inventoryStockFilter');
const inventoryResultCount = document.getElementById('inventoryResultCount');
const invoiceSupplierFilter = document.getElementById('invoiceSupplierFilter');
const invoiceResultCount = document.getElementById('invoiceResultCount');
const clientAreaFilter = document.getElementById('clientAreaFilter');
const clientResultCount = document.getElementById('clientResultCount');
const loanResultCount = document.getElementById('loanResultCount');

let inventory = [];
let archivedInventory = [];
let loans = [];
let loanHistory = [];
let classifications = [];
let unitsOfMeasure = [];
let campuses = [];
let careers = [];
let invoices = [];
let clients = [];
let writeOffs = [];
let editingId = null;
let editingInvoiceId = null;
let editingClientId = null;
let editingWriteOffId = null;
let showingArchived = false;
let showingDeletedWriteOffs = false;
let activePage = 'dashboardPage';
let manualLoaded = false;
const searchTerms = {
  inventory: '',
  loans: '',
  invoices: '',
  clients: ''
};
const barcodeScanner = createBarcodeScanner();
const stopBarcodeScan = barcodeScanner.stop;

function getSearchContext() {
  if (activePage === 'inventoryPage' && !inventoryListPanel.hidden) {
    return {
      key: 'inventory',
      label: 'Buscar productos',
      placeholder: 'Buscar por nombre, código, categoría o proveedor'
    };
  }
  if (activePage === 'loansPage' && !loanListPanel.hidden) {
    return {
      key: 'loans',
      label: 'Buscar préstamos',
      placeholder: 'Buscar por cliente, RUT, producto o fecha'
    };
  }
  if (activePage === 'invoicesPage') {
    return {
      key: 'invoices',
      label: 'Buscar facturas',
      placeholder: 'Buscar por RUT de proveedor o número de factura'
    };
  }
  if (activePage === 'clientsPage') {
    return {
      key: 'clients',
      label: 'Buscar clientes',
      placeholder: 'Buscar por nombre, RUT o correo'
    };
  }
  return null;
}

function updateSearchBar() {
  const context = getSearchContext();
  inventorySearch.hidden = !context;
  if (!context) return;
  inventorySearch.setAttribute('aria-label', context.label);
  searchInput.placeholder = context.placeholder;
  searchInput.value = searchTerms[context.key];
}

function normalizeSearchValue(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0301\u0308]/g, '')
    .toLocaleLowerCase('es');
}

function includesSearchTerm(values, normalizedTerm) {
  return !normalizedTerm || values.some((value) => normalizeSearchValue(value).includes(normalizedTerm));
}

function showLoanError(message) {
  loanError.textContent = message;
  loanError.hidden = !message;
}

function showLoanMessage(message) {
  loanMessage.textContent = message;
  loanMessage.hidden = !message;
}

function showAuthError(message) {
  authError.textContent = message;
  authError.hidden = !message;
}

function showStockError(message) {
  stockError.textContent = message;
  stockError.hidden = !message;
}

function showStockMessage(message) {
  stockMessage.textContent = message;
  stockMessage.hidden = !message;
}

function showDashboardError(message) {
  const dashboardError = document.getElementById('dashboardError');
  dashboardError.textContent = message;
  dashboardError.hidden = !message;
}

async function loadManual() {
  if (manualLoaded) return;
  manualError.hidden = true;
  userManualContent.innerHTML = '<p class="field-hint">El manual se está cargando…</p>';
  try {
    const result = await apiRequest('/api/manual');
    userManualContent.innerHTML = renderManualMarkdown(result.markdown);
    manualLoaded = true;
  } catch (error) {
    userManualContent.innerHTML = '';
    manualError.textContent = `No se pudo cargar el manual: ${error.message}`;
    manualError.hidden = false;
  }
}

function showClassificationError(message) {
  classificationError.textContent = message;
  classificationError.hidden = !message;
}

function showClassificationMessage(message) {
  classificationMessage.textContent = message;
  classificationMessage.hidden = !message;
}

function showCampusError(message) {
  campusError.textContent = message;
  campusError.hidden = !message;
}

function showCampusMessage(message) {
  campusMessage.textContent = message;
  campusMessage.hidden = !message;
}

function showAcademicCatalogError(message) {
  academicCatalogError.textContent = message;
  academicCatalogError.hidden = !message;
}

function showAcademicCatalogMessage(message) {
  academicCatalogMessage.textContent = message;
  academicCatalogMessage.hidden = !message;
}

function showInvoiceError(message) {
  invoiceError.textContent = message;
  invoiceError.hidden = !message;
}

function showInvoiceMessage(message) {
  invoiceMessage.textContent = message;
  invoiceMessage.hidden = !message;
}

function showClientError(message) {
  clientError.textContent = message;
  clientError.hidden = !message;
}

function showClientMessage(message) {
  clientMessage.textContent = message;
  clientMessage.hidden = !message;
}

function showWriteOffError(message) {
  writeOffError.textContent = message;
  writeOffError.hidden = !message;
}

function showWriteOffMessage(message) {
  writeOffMessage.textContent = message;
  writeOffMessage.hidden = !message;
}

function resetInvoiceForm() {
  editingInvoiceId = null;
  invoiceForm.reset();
  invoiceFormTitle.textContent = 'Registrar una factura';
  invoiceSubmit.textContent = 'Registrar factura';
  cancelInvoiceEdit.hidden = true;
}

function resetClientForm() {
  editingClientId = null;
  clientForm.reset();
  clientFormTitle.textContent = 'Crear cliente';
  clientSubmit.textContent = 'Crear cliente';
  cancelClientEdit.hidden = true;
}

function editClient(client) {
  editingClientId = String(client.id);
  document.getElementById('clientName').value = client.name;
  document.getElementById('clientRut').value = client.rut;
  document.getElementById('clientEmail').value = client.email;
  document.getElementById('clientArea').value = client.area;
  clientFormTitle.textContent = 'Editar cliente';
  clientSubmit.textContent = 'Guardar cambios';
  cancelClientEdit.hidden = false;
  showClientError('');
  showClientMessage('');
}

function resetWriteOffForm() {
  editingWriteOffId = null;
  writeOffForm.reset();
  document.getElementById('writeOffId').value = 'Se asignará al guardar';
  writeOffFormTitle.textContent = 'Registrar baja';
  writeOffSubmit.textContent = 'Registrar baja';
  cancelWriteOffEdit.hidden = true;
  writeOffDate.value = getLocalDateValue();
  updateWriteOffProductOptions();
}

function editInvoice(invoice) {
  editingInvoiceId = String(invoice.id);
  document.getElementById('invoiceSupplierRut').value = invoice.supplierRut;
  document.getElementById('invoiceNumber').value = invoice.invoiceNumber;
  invoiceFormTitle.textContent = 'Editar factura';
  invoiceSubmit.textContent = 'Guardar cambios';
  cancelInvoiceEdit.hidden = false;
  showInvoiceError('');
  showInvoiceMessage('');
  invoiceForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function editWriteOff(writeOff) {
  editingWriteOffId = String(writeOff.id);
  document.getElementById('writeOffId').value = `EB-${writeOff.id}`;
  document.getElementById('writeOffLocation').value = writeOff.location;
  writeOffDate.value = writeOff.date;
  writeOffQuantity.value = writeOff.quantity;
  document.getElementById('writeOffReason').value = writeOff.reason;
  document.getElementById('writeOffObservation').value = writeOff.observation || '';
  writeOffFormTitle.textContent = `Editar baja EB-${writeOff.id}`;
  writeOffSubmit.textContent = 'Guardar cambios';
  cancelWriteOffEdit.hidden = false;
  updateWriteOffProductOptions(writeOff.productId, writeOff);
  showWriteOffError('');
  showWriteOffMessage('');
  writeOffForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function setAuthenticated(user) {
  signedInEmail.textContent = user.email;
  usersNav.hidden = !user.isAdmin;
  authView.hidden = true;
  appShell.hidden = false;
  showAuthError('');
  showDashboardError('');
}

function setLoggedOut() {
  stopBarcodeScan('La cámara se detuvo al cerrar la sesión.');
  appShell.hidden = true;
  authView.hidden = false;
  authPassword.value = '';
  usersNav.hidden = true;
  clearAdminUsers();
  showAuthError('');
  showDashboardError('');
}

function showPage(page) {
  activePage = page;
  const isDashboardPage = page === 'dashboardPage';
  const isInventoryPage = page === 'inventoryPage';
  const isWriteOffPage = page === 'writeOffPage';
  const isClassificationsPage = page === 'classificationsPage';
  const isCampusesPage = page === 'campusesPage';
  const isAcademicCatalogPage = page === 'academicCatalogPage';
  const isInvoicesPage = page === 'invoicesPage';
  const isClientsPage = page === 'clientsPage';
  const isLoansPage = page === 'loansPage';
  const isLoanHistoryPage = page === 'loanHistoryPage';
  const isUsersPage = page === 'usersPage';
  const isManualPage = page === 'manualPage';
  if (!isInventoryPage) stopBarcodeScan('La cámara se detuvo al salir del inventario.');
  dashboardPage.hidden = !isDashboardPage;
  inventoryPage.hidden = !isInventoryPage;
  writeOffPage.hidden = !isWriteOffPage;
  classificationsPage.hidden = !isClassificationsPage;
  campusesPage.hidden = !isCampusesPage;
  academicCatalogPage.hidden = !isAcademicCatalogPage;
  invoicesPage.hidden = !isInvoicesPage;
  clientsPage.hidden = !isClientsPage;
  loansPage.hidden = !isLoansPage;
  loanHistoryPage.hidden = !isLoanHistoryPage;
  usersPage.hidden = !isUsersPage;
  manualPage.hidden = !isManualPage;
  dashboardNav.classList.toggle('active', isDashboardPage);
  inventoryNav.classList.toggle('active', isInventoryPage);
  writeOffNav.classList.toggle('active', isWriteOffPage);
  classificationsNav.classList.toggle('active', isClassificationsPage);
  campusesNav.classList.toggle('active', isCampusesPage);
  academicCatalogNav.classList.toggle('active', isAcademicCatalogPage);
  invoicesNav.classList.toggle('active', isInvoicesPage);
  clientsNav.classList.toggle('active', isClientsPage);
  loansNav.classList.toggle('active', isLoansPage);
  loanHistoryNav.classList.toggle('active', isLoanHistoryPage);
  usersNav.classList.toggle('active', isUsersPage);
  manualNav.classList.toggle('active', isManualPage);
  updateSearchBar();
  pageEyebrow.textContent = isInventoryPage
    ? 'Inventario'
    : isWriteOffPage
      ? 'Dar de baja'
    : isClassificationsPage
    ? 'Categorías y unidades'
    : isCampusesPage
      ? 'Control de sedes'
    : isAcademicCatalogPage
      ? 'Carreras y asignaturas'
    : isInvoicesPage
      ? 'Facturas'
    : isClientsPage
      ? 'Clientes'
    : isLoansPage
      ? 'Préstamos'
      : isLoanHistoryPage
        ? 'Historial de préstamos'
        : isUsersPage
          ? 'Administración de usuarios'
        : isManualPage
          ? 'Ayuda'
          : 'Resumen';
  pageTitle.textContent = isInventoryPage
    ? 'Registro de inventario'
    : isWriteOffPage
      ? 'Registro de bajas de inventario'
    : isClassificationsPage
      ? 'Categorías y unidades de productos'
      : isCampusesPage
        ? 'Administrar sedes y asignaciones'
      : isAcademicCatalogPage
        ? 'Administrar carreras y asignaturas'
      : isInvoicesPage
        ? 'Administrar facturas de proveedores'
      : isClientsPage
        ? 'Administrar clientes'
      : isLoansPage
      ? 'Control de préstamos'
      : isLoanHistoryPage
        ? 'Historial completo de préstamos'
        : isUsersPage
          ? 'Crear cuentas de acceso'
        : isManualPage
          ? 'Manual de usuario de StockFlow'
          : 'Panel de gestión de inventario';
  if (isInventoryPage) refreshInventory(searchTerms.inventory);
  if (isWriteOffPage) {
    Promise.all([loadInventory(), loadWriteOffs()])
      .then(() => updateWriteOffProductOptions())
      .catch((error) => showWriteOffError(error.message));
  }
  if (isClassificationsPage) loadClassifications().catch((error) => showClassificationError(error.message));
  if (isCampusesPage) loadCampuses().catch((error) => showCampusError(error.message));
  if (isAcademicCatalogPage) loadAcademicCatalog().catch((error) => showAcademicCatalogError(error.message));
  if (isInvoicesPage) loadInvoices().catch((error) => showInvoiceError(error.message));
  if (isClientsPage) loadClients().catch((error) => showClientError(error.message));
  if (isLoansPage) {
    loadLoans().catch((error) => showLoanError(error.message));
    loadClients().catch((error) => showLoanError(error.message));
  }
  if (isLoanHistoryPage) loadLoanHistory().catch((error) => showDashboardError(error.message));
  if (isUsersPage) loadAdminUsers().catch((error) => showUsersError(error.message));
  if (isManualPage) loadManual();
}

function showProductImagePreview(source) {
  productImagePreview.src = source || '';
  productImagePreview.hidden = !source;
}

function getStatus(item) {
  return item.stock <= item.reorderLevel ? 'low' : 'good';
}

function renderSummary(items) {
  const totalItems = items.reduce((sum, item) => sum + Number(item.stock), 0);
  const lowStockCount = items.filter((item) => item.stock <= item.reorderLevel).length;
  const totalValue = items.reduce((sum, item) => sum + item.stock * Number(item.price), 0);

  totalItemsValue.textContent = String(totalItems);
  lowStockValue.textContent = String(lowStockCount);
  inventoryValue.textContent = formatCurrency(totalValue);
}

function renderLowStock(items) {
  const lowItems = items.filter((item) => item.stock <= item.reorderLevel);

  lowStockList.innerHTML = lowItems.length
    ? lowItems
        .slice(0, 4)
        .map(
          (item) => `
            <div class="watch-item">
              <div>
                <strong>${escapeHtml(item.name)}</strong>
                <small>${item.stock} ${escapeHtml(item.unitOfMeasure)} disponibles</small>
              </div>
              <span class="warning-pill">Reponer</span>
            </div>
          `
        )
        .join('')
    : '<div class="watch-item"><div><strong>Todas las existencias están en nivel adecuado</strong><small>No se requiere ninguna acción</small></div><span class="warning-pill stable-pill">Estable</span></div>';
}

function renderTable(items) {
  inventoryTableBody.innerHTML = items.length
    ? items
        .map((item) => {
          const status = getStatus(item);
          const initials = item.name
            .split(' ')
            .slice(0, 2)
            .map((word) => word[0])
            .join('')
            .toUpperCase();

          return `
            <tr>
              <td>
                <div class="product-cell">
                  ${item.imageData
                    ? `<img class="product-thumbnail" src="data:${escapeHtml(item.imageMimeType)};base64,${item.imageData}" alt="${escapeHtml(item.name)}" />`
                    : `<span class="product-icon">${escapeHtml(initials)}</span>`}
                  <div>
                    <div>${escapeHtml(item.name)}</div>
                    <small>${escapeHtml(item.code)}</small>
                    ${showingArchived ? '<span class="status-badge neutral">Archivado</span>' : ''}
                    ${item.characteristics ? `<div class="product-details"><strong>Características:</strong> ${escapeHtml(item.characteristics)}</div>` : ''}
                    ${item.description ? `<div class="product-details"><strong>Descripción:</strong> ${escapeHtml(item.description)}</div>` : ''}
                  </div>
                </div>
              </td>
              <td>${escapeHtml(item.barcode || '—')}</td>
              <td>
                <div>${escapeHtml(item.category)}</div>
                ${item.subcategory ? `<small>${escapeHtml(item.subcategory)}</small>` : ''}
              </td>
              <td>${escapeHtml(item.campusName || '—')}</td>
              <td>${item.stock}</td>
              <td>${escapeHtml(item.unitOfMeasure)}</td>
              <td>${formatCurrency(item.price)}</td>
              <td>
                <span class="status-badge ${status}">
                  ${status === 'low' ? 'Existencias bajas' : 'Nivel adecuado'}
                </span>
              </td>
              <td><span class="status-badge ${item.state === 'Disponible' ? 'good' : 'low'}">${escapeHtml(item.state)}</span></td>
              <td>${escapeHtml(item.quality)}</td>
              <td>${item.isConsumable ? 'Sí' : 'No'}</td>
              <td>${escapeHtml(item.supplier)}</td>
              <td>
                <div class="row-actions">
                  ${showingArchived
                    ? `<button type="button" class="ghost-btn" data-action="restore" data-id="${escapeHtml(item.id)}">Restaurar</button>`
                    : `<button type="button" class="ghost-btn" data-action="edit" data-id="${escapeHtml(item.id)}">Editar</button>
                       <button type="button" class="ghost-btn" data-action="archive" data-id="${escapeHtml(item.id)}">Archivar</button>`}
                </div>
              </td>
            </tr>
          `;
        })
        .join('')
    : `<tr><td class="empty-state" colspan="13">${(showingArchived ? archivedInventory : inventory).length
      ? 'No hay productos que coincidan con los criterios seleccionados.'
      : showingArchived
        ? 'No hay productos archivados.'
        : 'Aún no hay productos en el inventario. Agrega el primero mediante el formulario.'}</td></tr>`;
}

function updateInventoryFilterOptions(items) {
  const selectedCategory = inventoryCategoryFilter.value;
  const selectedCampus = inventoryCampusFilter.value;
  const categories = [...new Set(items.map((item) => item.category).filter(Boolean))]
    .sort((left, right) => left.localeCompare(right, 'es'));
  const campusesInInventory = [...new Set(items.map((item) => item.campusName).filter(Boolean))]
    .sort((left, right) => left.localeCompare(right, 'es'));
  inventoryCategoryFilter.innerHTML = '<option value="">Todas las categorías</option>' +
    categories.map((category) => `<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`).join('');
  inventoryCampusFilter.innerHTML = '<option value="">Todas las sedes</option>' +
    campusesInInventory.map((campus) => `<option value="${escapeHtml(campus)}">${escapeHtml(campus)}</option>`).join('');
  if (categories.includes(selectedCategory)) inventoryCategoryFilter.value = selectedCategory;
  if (campusesInInventory.includes(selectedCampus)) inventoryCampusFilter.value = selectedCampus;
}

function refreshInventory(term = '') {
  const normalizedTerm = normalizeSearchValue(term.trim());
  const displayedInventory = showingArchived ? archivedInventory : inventory;
  updateInventoryFilterOptions(displayedInventory);
  const filtered = displayedInventory.filter((item) => (
    includesSearchTerm([
      item.name,
      item.barcode,
      item.category,
      item.subcategory,
      item.unitOfMeasure,
      item.code,
      item.characteristics,
      item.description,
      item.campusName,
      item.supplier,
      item.state,
      item.quality
    ], normalizedTerm) &&
    (!inventoryCategoryFilter.value || item.category === inventoryCategoryFilter.value) &&
    (!inventoryCampusFilter.value || item.campusName === inventoryCampusFilter.value) &&
    (inventoryStockFilter.value === 'all' ||
      inventoryStockFilter.value === 'out' && Number(item.stock) === 0 ||
      inventoryStockFilter.value === 'low' && Number(item.stock) > 0 && Number(item.stock) <= Number(item.reorderLevel) ||
      inventoryStockFilter.value === 'adequate' && Number(item.stock) > Number(item.reorderLevel))
  ));

  inventoryResultCount.textContent = `Mostrando ${filtered.length} de ${displayedInventory.length} productos.`;
  renderSummary(inventory);
  renderTable(filtered);
  renderLowStock(inventory);
  renderLoanProductOptions();
}

async function loadInventory(archived = false) {
  const result = await apiRequest(`/api/products?archived=${archived}`);
  if (archived) archivedInventory = result.products;
  else inventory = result.products;
  refreshInventory(searchTerms.inventory);
}

function updateProductSubcategories(selectedId = productSubcategory.value) {
  const category = classifications.find((item) => String(item.id) === productCategory.value);
  const subcategories = category ? category.subcategories : [];
  productSubcategory.innerHTML = '<option value="">Sin subcategoría</option>' + subcategories
    .map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.name)}</option>`)
    .join('');
  if (subcategories.some((item) => String(item.id) === String(selectedId))) {
    productSubcategory.value = selectedId;
  }
}

function renderClassifications() {
  classificationsList.innerHTML = classifications.length
    ? classifications.map((category) => `
        <section class="classification-group">
          <div class="classification-heading">
            <form class="classification-rename-form" data-action="rename-category" data-id="${escapeHtml(category.id)}">
              <input type="text" maxlength="80" value="${escapeHtml(category.name)}" aria-label="Nombre de la categoría" required />
              <button type="submit" class="ghost-btn">Guardar</button>
            </form>
            <button type="button" class="danger-btn" data-action="delete-category" data-id="${escapeHtml(category.id)}">
              Eliminar categoría
            </button>
          </div>
          ${category.subcategories.length
            ? `<ul>${category.subcategories.map((subcategory) => `
                <li>
                <form class="classification-rename-form" data-action="rename-subcategory" data-id="${escapeHtml(subcategory.id)}">
                  <input type="text" maxlength="80" value="${escapeHtml(subcategory.name)}" aria-label="Nombre de la subcategoría" required />
                  <button type="submit" class="ghost-btn">Guardar</button>
                </form>
                <button type="button" class="ghost-btn" data-action="delete-subcategory" data-id="${escapeHtml(subcategory.id)}">
                  Eliminar
                </button>
                </li>
              `).join('')}</ul>`
            : '<p class="field-hint">Aún no hay subcategorías.</p>'}
        </section>
      `).join('')
    : '<p class="empty-state">Aún no se han creado categorías.</p>';
}

async function loadClassifications() {
  const previousCategory = productCategory.value;
  const parentCategory = subcategoryParent.value;
  const previousUnit = productUnitOfMeasure.value;
  const result = await apiRequest('/api/classifications');
  classifications = result.categories;
  unitsOfMeasure = result.unitsOfMeasure;

  productCategory.innerHTML = '<option value="">Selecciona una categoría</option>' + classifications
    .map((category) => `<option value="${escapeHtml(category.id)}">${escapeHtml(category.name)}</option>`)
    .join('');
  if (classifications.some((category) => String(category.id) === previousCategory)) {
    productCategory.value = previousCategory;
  }
  updateProductSubcategories();

  subcategoryParent.innerHTML = classifications.length
    ? classifications.map((category) =>
      `<option value="${escapeHtml(category.id)}">${escapeHtml(category.name)}</option>`
    ).join('')
    : '<option value="">Primero agrega una categoría</option>';
  if (classifications.some((category) => String(category.id) === parentCategory)) {
    subcategoryParent.value = parentCategory;
  }
  productUnitOfMeasure.innerHTML = unitsOfMeasure
    .map((unit) => `<option value="${escapeHtml(unit.name)}">${escapeHtml(unit.name)}</option>`)
    .join('');
  productUnitOfMeasure.value = unitsOfMeasure.some((unit) => unit.name === previousUnit)
    ? previousUnit
    : 'Unidades';
  unitOptionsList.innerHTML = unitsOfMeasure.length
    ? unitsOfMeasure.map((unit) => `
        <li class="unit-option">
          <form class="classification-rename-form" data-action="rename-unit" data-id="${escapeHtml(unit.id)}">
            <input type="text" maxlength="20" value="${escapeHtml(unit.name)}" aria-label="Nombre de la unidad" required />
            <button type="submit" class="ghost-btn">Guardar</button>
          </form>
          <button type="button" class="ghost-btn" data-action="delete-unit" data-id="${escapeHtml(unit.id)}" ${unit.isInUse || unitsOfMeasure.length <= 1 ? 'disabled title="Debe conservar al menos una unidad y quitar primero las asignaciones a productos"' : ''}>
            Eliminar
          </button>
        </li>
      `).join('')
    : '<li>Aún no se han agregado unidades de medida.</li>';
  renderClassifications();
}

function renderCampuses() {
  campusesList.innerHTML = campuses.length
    ? campuses.map((campus) => {
      const inUse = Number(campus.usageCount) > 0;
      const cannotDelete = inUse || campuses.length <= 1;
      return `
        <li class="campus-option">
          <form class="classification-rename-form" data-action="rename-campus" data-id="${escapeHtml(campus.id)}">
            <input type="text" maxlength="100" value="${escapeHtml(campus.name)}" aria-label="Nombre de la sede" required />
            <button type="submit" class="ghost-btn">Guardar</button>
          </form>
          <span class="campus-usage">${inUse ? 'Asignada a productos o préstamos' : 'Sin asignaciones'}</span>
          <button type="button" class="ghost-btn" data-action="delete-campus" data-id="${escapeHtml(campus.id)}"
            ${cannotDelete ? `disabled title="${inUse ? 'No se puede eliminar una sede asignada a productos o préstamos' : 'Debe conservar al menos una sede'}"` : ''}>
            Eliminar
          </button>
        </li>
      `;
    }).join('')
    : '<li class="empty-state">No hay sedes registradas.</li>';
}

async function loadCampuses() {
  const previousProductCampus = productCampus.value;
  const previousLoanCampus = loanCampus.value;
  const result = await apiRequest('/api/campuses');
  campuses = result.campuses;
  const options = campuses
    .map((campus) => `<option value="${escapeHtml(campus.id)}">${escapeHtml(campus.name)}</option>`)
    .join('');
  productCampus.innerHTML = options;
  loanCampus.innerHTML = options;
  productCampus.value = campuses.some((campus) => String(campus.id) === previousProductCampus)
    ? previousProductCampus
    : campuses.length ? String(campuses[0].id) : '';
  loanCampus.value = campuses.some((campus) => String(campus.id) === previousLoanCampus)
    ? previousLoanCampus
    : campuses.length ? String(campuses[0].id) : '';
  renderCampuses();
  renderLoanProductOptions();
}

function renderAcademicCatalog() {
  academicCatalogList.innerHTML = careers.length
    ? careers.map((career) => `
        <section class="classification-group">
          <div class="classification-heading">
            <form class="classification-rename-form" data-action="rename-career" data-id="${escapeHtml(career.id)}">
              <input type="text" maxlength="120" value="${escapeHtml(career.name)}" aria-label="Nombre de la carrera" required />
              <button type="submit" class="ghost-btn">Guardar</button>
            </form>
            <button type="button" class="danger-btn" data-action="delete-career" data-id="${escapeHtml(career.id)}">
              Eliminar carrera
            </button>
          </div>
          ${career.subjects.length
            ? `<ul>${career.subjects.map((subject) => `
                <li>
                  <form class="classification-rename-form" data-action="rename-subject" data-id="${escapeHtml(subject.id)}">
                    <input type="text" maxlength="120" value="${escapeHtml(subject.name)}" aria-label="Nombre de la asignatura" required />
                    <button type="submit" class="ghost-btn">Guardar</button>
                  </form>
                  <button type="button" class="ghost-btn" data-action="delete-subject" data-id="${escapeHtml(subject.id)}">
                    Eliminar
                  </button>
                </li>
              `).join('')}</ul>`
            : '<p class="field-hint">Aún no hay asignaturas para esta carrera.</p>'}
        </section>
      `).join('')
    : '<p class="empty-state">Aún no hay carreras. Agrega las carreras vigentes de la sede Plaza Oeste para comenzar.</p>';
}

function updateLoanSubjects(selectedId = loanSubject.value) {
  const career = careers.find((item) => String(item.id) === loanCareer.value);
  loanSubject.innerHTML = career
    ? `<option value="">${career.subjects.length ? 'Sin asignatura' : 'No hay asignaturas registradas'}</option>` +
      career.subjects.map((subject) =>
        `<option value="${escapeHtml(subject.id)}">${escapeHtml(subject.name)}</option>`
      ).join('')
    : '<option value="">Selecciona una carrera primero</option>';
  loanSubject.disabled = !career || !career.subjects.length;
  if (career?.subjects.some((subject) => String(subject.id) === String(selectedId))) {
    loanSubject.value = selectedId;
  }
}

async function loadAcademicCatalog() {
  const previousCareer = loanCareer.value;
  const previousSubjectCareer = subjectCareer.value;
  const previousLoanSubject = loanSubject.value;
  const result = await apiRequest('/api/academic-catalog');
  careers = result.careers;

  const careerOptions = '<option value="">Selecciona una carrera</option>' + careers
    .map((career) => `<option value="${escapeHtml(career.id)}">${escapeHtml(career.name)}</option>`)
    .join('');
  loanCareer.innerHTML = '<option value="">Sin carrera</option>' + careers
    .map((career) => `<option value="${escapeHtml(career.id)}">${escapeHtml(career.name)}</option>`)
    .join('');
  subjectCareer.innerHTML = careerOptions;
  if (careers.some((career) => String(career.id) === previousCareer)) {
    loanCareer.value = previousCareer;
  }
  if (careers.some((career) => String(career.id) === previousSubjectCareer)) {
    subjectCareer.value = previousSubjectCareer;
  }
  updateLoanSubjects(previousLoanSubject);
  document.getElementById('subjectSubmit').disabled = careers.length === 0;
  renderAcademicCatalog();
}

function renderInvoices() {
  const selectedSupplier = invoiceSupplierFilter.value;
  const suppliers = [...new Set(invoices.map((invoice) => invoice.supplierRut))]
    .sort((left, right) => left.localeCompare(right, 'es'));
  invoiceSupplierFilter.innerHTML = '<option value="">Todos los proveedores</option>' +
    suppliers.map((rut) => `<option value="${escapeHtml(rut)}">${escapeHtml(rut)}</option>`).join('');
  if (suppliers.includes(selectedSupplier)) invoiceSupplierFilter.value = selectedSupplier;

  const normalizedTerm = normalizeSearchValue(searchTerms.invoices);
  const filteredInvoices = invoices.filter((invoice) => (
    includesSearchTerm([invoice.supplierRut, invoice.invoiceNumber], normalizedTerm) &&
    (!invoiceSupplierFilter.value || invoice.supplierRut === invoiceSupplierFilter.value)
  ));
  invoiceResultCount.textContent = `Mostrando ${filteredInvoices.length} de ${invoices.length} facturas.`;
  invoicesTableBody.innerHTML = filteredInvoices.length
    ? filteredInvoices.map((invoice) => `
        <tr>
          <td>${escapeHtml(invoice.supplierRut)}</td>
          <td>${escapeHtml(invoice.invoiceNumber)}</td>
          <td>
            <div class="row-actions">
              <button type="button" class="ghost-btn" data-action="edit-invoice" data-id="${escapeHtml(invoice.id)}">
                Editar
              </button>
              <button type="button" class="danger-btn" data-action="delete-invoice" data-id="${escapeHtml(invoice.id)}">
                Eliminar
              </button>
            </div>
          </td>
        </tr>
      `).join('')
    : `<tr><td class="empty-state" colspan="3">${invoices.length
      ? 'No hay facturas que coincidan con los criterios seleccionados.'
      : 'Aún no hay facturas registradas.'}</td></tr>`;
}

async function loadInvoices() {
  const result = await apiRequest('/api/invoices');
  invoices = result.invoices;
  renderInvoices();
}

function renderClients() {
  const normalizedTerm = normalizeSearchValue(searchTerms.clients);
  const filteredClients = clients.filter((client) => (
    includesSearchTerm([client.name, client.rut, client.email, client.area], normalizedTerm) &&
    (!clientAreaFilter.value || client.area === clientAreaFilter.value)
  ));
  clientResultCount.textContent = `Mostrando ${filteredClients.length} de ${clients.length} clientes.`;
  clientsTableBody.innerHTML = filteredClients.length
    ? filteredClients.map((client) => `
        <tr>
          <td>${escapeHtml(client.name)}</td>
          <td>${escapeHtml(client.rut)}</td>
          <td>${escapeHtml(client.email)}</td>
          <td>${escapeHtml(client.area)}</td>
          <td>
            <div class="row-actions">
              <button type="button" class="ghost-btn" data-action="edit-client" data-id="${escapeHtml(client.id)}">
                Editar
              </button>
              <button type="button" class="danger-btn" data-action="delete-client" data-id="${escapeHtml(client.id)}">
                Eliminar
              </button>
            </div>
          </td>
        </tr>
      `).join('')
    : `<tr><td class="empty-state" colspan="5">${clients.length
      ? 'No hay clientes que coincidan con los criterios seleccionados.'
      : 'Aún no hay clientes registrados.'}</td></tr>`;
}

function updateLoanClientOptions(selectedId = loanClient.value) {
  loanClient.innerHTML = '<option value="">Sin cliente registrado</option>' + clients
    .map((client) => `<option value="${escapeHtml(client.id)}">${escapeHtml(client.name)} — ${escapeHtml(client.rut)}</option>`)
    .join('');
  if (clients.some((client) => String(client.id) === String(selectedId))) {
    loanClient.value = String(selectedId);
  }
  const selectedClient = clients.find((client) => String(client.id) === loanClient.value);
  loanRut.readOnly = Boolean(selectedClient);
  loanArea.readOnly = Boolean(selectedClient);
  if (selectedClient) {
    loanRut.value = selectedClient.rut;
    loanArea.value = selectedClient.area;
  }
  validateLoanRut();
}

function validateLoanRut() {
  const rut = loanRut.value.trim();
  const isClientSelected = Boolean(loanClient.value);
  loanRut.setCustomValidity(
    !isClientSelected && rut && !normalizeChileanRut(rut)
      ? 'Ingresa un RUT chileno válido, incluyendo un dígito verificador correcto.'
      : ''
  );
}

async function loadClients() {
  const selectedClientId = loanClient.value;
  const result = await apiRequest('/api/clients');
  clients = result.clients;
  renderClients();
  updateLoanClientOptions(selectedClientId);
}

function updateWriteOffProductOptions(selectedId = writeOffProduct.value, currentWriteOff = null) {
  const products = [...inventory];
  if (currentWriteOff && !products.some((product) => String(product.id) === String(currentWriteOff.productId))) {
    products.push({
      id: currentWriteOff.productId,
      code: currentWriteOff.codigo,
      name: currentWriteOff.productName || '',
      stock: 0,
      campusName: currentWriteOff.bodega,
      isArchived: currentWriteOff.isArchived
    });
  }

  writeOffProduct.innerHTML = '<option value="">Selecciona un código</option>' + products
    .map((product) => {
      const currentItem = currentWriteOff &&
        String(product.id) === String(currentWriteOff.productId);
      const availableStock = Number(product.stock) + (currentItem ? Number(currentWriteOff.quantity) : 0);
      const disabled = Boolean(product.isArchived) && !currentItem || availableStock < 1 && !currentItem;
      return `<option value="${escapeHtml(product.id)}" ${disabled ? 'disabled' : ''}>
        ${escapeHtml(product.code)} — ${escapeHtml(product.name)} (${availableStock} disponibles)
      </option>`;
    })
    .join('');
  if (products.some((product) => String(product.id) === String(selectedId))) {
    writeOffProduct.value = String(selectedId);
  }
  const selectedProduct = products.find((product) => String(product.id) === writeOffProduct.value);
  if (!selectedProduct) {
    writeOffWarehouse.value = '';
    writeOffStockHint.textContent = 'Disponibles: —';
    writeOffQuantity.removeAttribute('max');
    writeOffQuantity.setCustomValidity('');
    return;
  }

  const currentWriteOffForProduct = currentWriteOff &&
    String(currentWriteOff.productId) === String(selectedProduct.id)
    ? Number(currentWriteOff.quantity)
    : 0;
  const availableStock = Number(selectedProduct.stock) + currentWriteOffForProduct;
  writeOffWarehouse.value = selectedProduct.campusName || currentWriteOff?.bodega || '';
  writeOffStockHint.textContent = `Disponibles para la baja: ${availableStock}`;
  writeOffQuantity.max = String(availableStock);
  writeOffQuantity.setCustomValidity(
    Number(writeOffQuantity.value) > availableStock
      ? 'La cantidad supera las existencias disponibles.'
      : ''
  );
}

function renderWriteOffs() {
  writeOffsTableBody.innerHTML = writeOffs.length
    ? writeOffs.map((writeOff) => `
        <tr>
          <td>EB-${escapeHtml(writeOff.id)}</td>
          <td>
            <div>${escapeHtml(writeOff.codigo)}</div>
            <small>${escapeHtml(writeOff.productName || '')}</small>
          </td>
          <td>${escapeHtml(formatDateOnly(writeOff.date))}</td>
          <td>${escapeHtml(writeOff.bodega)}</td>
          <td>${escapeHtml(writeOff.location)}</td>
          <td>${writeOff.quantity} ${escapeHtml(writeOff.unitOfMeasure || 'unidades')}</td>
          <td>${escapeHtml(writeOff.reason)}</td>
          <td>${escapeHtml(writeOff.observation || '—')}</td>
          <td>${writeOff.isDeleted
            ? '<span class="status-badge neutral">Anulada</span>'
            : '<span class="status-badge low">Activa</span>'}</td>
          <td>
            ${writeOff.isDeleted
              ? '—'
              : `<div class="row-actions">
                  <button type="button" class="ghost-btn" data-action="edit-write-off" data-id="${escapeHtml(writeOff.id)}">
                    Modificar
                  </button>
                  <button type="button" class="danger-btn" data-action="delete-write-off" data-id="${escapeHtml(writeOff.id)}">
                    Eliminar
                  </button>
                </div>`}
          </td>
        </tr>
      `).join('')
    : `<tr><td class="empty-state" colspan="10">${showingDeletedWriteOffs
      ? 'No hay bajas en el historial.'
      : 'Aún no hay bajas registradas.'}</td></tr>`;
}

async function loadWriteOffs() {
  const result = await apiRequest(`/api/write-offs?includeDeleted=${showingDeletedWriteOffs}`);
  writeOffs = result.writeOffs;
  renderWriteOffs();
  const currentWriteOff = writeOffs.find((item) => String(item.id) === editingWriteOffId);
  updateWriteOffProductOptions(
    currentWriteOff?.productId || writeOffProduct.value,
    currentWriteOff || null
  );
}

async function refreshCampusAssignments() {
  await loadCampuses();
  await loadInventory(false);
  await loadInventory(true);
  await loadLoans();
  await loadLoanHistory();
}

function selectLoanCampusWithInventory() {
  const selectedCampusHasProducts = inventory.some((item) => String(item.campusId) === loanCampus.value);
  if (!selectedCampusHasProducts) {
    const campusWithProducts = campuses.find((campus) =>
      inventory.some((item) => String(item.campusId) === String(campus.id))
    );
    if (campusWithProducts) loanCampus.value = String(campusWithProducts.id);
  }
  renderLoanProductOptions();
}

function renderLoanProductOptions() {
  const rows = [...loanItemsContainer.querySelectorAll('.loan-item-row')];
  const availableInventory = inventory.filter((item) => String(item.campusId) === loanCampus.value);
  for (const row of rows) {
    const select = row.querySelector('.loan-product-select');
    const currentId = select.value;
    const selectedByOtherRows = rows
      .filter((otherRow) => otherRow !== row)
      .map((otherRow) => otherRow.querySelector('.loan-product-select').value);
    select.innerHTML = '<option value="">Selecciona un producto</option>' + availableInventory
      .map((item) => {
        const unavailable = item.stock < 1 || ['En reparación', 'Dado de baja'].includes(item.state);
        const duplicate = selectedByOtherRows.includes(String(item.id));
        const disabled = unavailable || duplicate;
        return `
          <option value="${escapeHtml(item.id)}" ${disabled ? 'disabled' : ''}>
            ${escapeHtml(item.code)} — ${escapeHtml(item.name)} (${item.stock} ${escapeHtml(item.unitOfMeasure)} disponibles${item.isConsumable ? ', fungible' : ''})
          </option>
        `;
      })
      .join('');
    select.value = currentId;
    const quantity = row.querySelector('.loan-item-quantity');
    const hint = row.querySelector('.loan-item-stock-hint');
    const product = availableInventory.find((item) => String(item.id) === currentId);
    if (product) {
      quantity.max = String(product.stock);
      hint.textContent = `Disponibles: ${product.stock} ${product.unitOfMeasure}${product.isConsumable ? ' — fungible' : ''}`;
      const totalForProduct = rows
        .filter((itemRow) => itemRow.querySelector('.loan-product-select').value === currentId)
        .reduce((sum, itemRow) => sum + Number(itemRow.querySelector('.loan-item-quantity').value || 0), 0);
      quantity.setCustomValidity(totalForProduct > product.stock ? 'La cantidad total supera las existencias disponibles.' : '');
    } else {
      quantity.removeAttribute('max');
      hint.textContent = 'Existencias disponibles: —';
      quantity.setCustomValidity('');
    }
    row.querySelector('.remove-loan-item').disabled = rows.length <= 1;
  }
  addLoanItemButton.disabled = rows.length >= 50;
  const hasReusableProduct = rows.some((row) => {
    const product = inventory.find((item) => String(item.id) === row.querySelector('.loan-product-select').value);
    return product && !product.isConsumable;
  });
  loanDueDate.required = hasReusableProduct;
  if (!hasReusableProduct) loanDueDate.value = '';
  updateDueDateMinimum();
}

function addLoanItemRow(productId = '', quantity = 1) {
  const row = document.createElement('div');
  row.className = 'loan-item-row';
  row.innerHTML = `
    <label>
      <span>Producto</span>
      <select class="loan-product-select" required></select>
    </label>
    <label>
      <span>Cantidad</span>
      <input class="loan-item-quantity" type="number" min="1" max="2147483647" step="1" value="${escapeHtml(quantity)}" required />
      <small class="loan-item-stock-hint field-hint">Existencias disponibles: —</small>
    </label>
    <button type="button" class="ghost-btn remove-loan-item" aria-label="Quitar producto del préstamo">Quitar</button>
  `;
  loanItemsContainer.append(row);
  renderLoanProductOptions();
  row.querySelector('.loan-product-select').value = productId;
  renderLoanProductOptions();
}

function resetLoanItems() {
  loanItemsContainer.replaceChildren();
  addLoanItemRow();
}

function updateDueDateMinimum() {
  loanDueDate.min = loanDate.value;
  if (loanDueDate.value && loanDueDate.value < loanDate.value) {
    loanDueDate.value = '';
  }
  validateLoanTimeRange();
}

function validateLoanTimeRange() {
  loanEndTime.setCustomValidity(
    (!loanDueDate.value || loanDueDate.value === loanDate.value) &&
      loanStartTime.value &&
      loanEndTime.value &&
      loanEndTime.value <= loanStartTime.value
      ? 'La hora de término debe ser posterior a la hora de inicio cuando vence el mismo día.'
      : ''
  );
}

function setDefaultLoanTimes() {
  const now = new Date();
  const formatTime = (date) => `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
  loanStartTime.value = formatTime(now);
  loanEndTime.value = '23:59';
  validateLoanTimeRange();
}

function showLoanView(view) {
  const showingList = view === 'list';
  loanListPanel.hidden = !showingList;
  loanCreatePanel.hidden = showingList;
  loanListTab.classList.toggle('active', showingList);
  loanCreateTab.classList.toggle('active', !showingList);
  loanListTab.setAttribute('aria-pressed', String(showingList));
  loanCreateTab.setAttribute('aria-pressed', String(!showingList));
  updateSearchBar();
}

function showInventoryView(view) {
  const showingList = view === 'list' || showingArchived;
  if (showingList) stopBarcodeScan('La cámara se detuvo al salir del formulario.');
  inventoryListPanel.hidden = !showingList;
  productCreatePanel.hidden = showingList;
  inventoryListTab.classList.toggle('active', showingList);
  productCreateTab.classList.toggle('active', !showingList);
  inventoryListTab.setAttribute('aria-pressed', String(showingList));
  productCreateTab.setAttribute('aria-pressed', String(!showingList));
  productCreateTab.hidden = showingArchived;
  updateSearchBar();
}

function renderLoans() {
  const grouped = new Map();
  for (const item of loans) {
    const key = String(item.id);
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(item);
  }
  const normalizedTerm = normalizeSearchValue(searchTerms.loans);
  const filteredGroups = [...grouped.values()].filter((items) => {
    const journey = items[0].journey || 'Sin especificar';
    const journeyMatches = loanJourneyFilter.value === 'all' || journey === loanJourneyFilter.value;
    const status = getLoanDueStatus(items);
    const statusMatches = loanStatusFilter.value === 'all' ||
      loanStatusFilter.value === 'pending' && ['pending', 'overdue', 'due-soon'].includes(status) ||
      status === loanStatusFilter.value;
    const searchMatches = !normalizedTerm || items.some((loan) => includesSearchTerm([
      loan.id,
      loan.loanDate,
      loan.dueDate,
      loan.startTime,
      loan.endTime,
      loan.journey,
      loan.clientName,
      loan.rut,
      loan.area,
      loan.careerName,
      loan.subject,
      loan.campusName,
      loan.productCode,
      loan.productName,
      loan.unitOfMeasure
    ], normalizedTerm));
    return journeyMatches && statusMatches && searchMatches;
  });
  loanResultCount.textContent = `Mostrando ${filteredGroups.length} de ${grouped.size} préstamos.`;
  updateLoanAttention(loans, loanAttention);
  loansTableBody.innerHTML = filteredGroups.length
    ? filteredGroups.map((items) => items.map((loan, index) => {
      const outstanding = Number(loan.outstanding);
      const dueStatus = getLoanDueStatus(items);
      const dueStatusLabel = dueStatus === 'overdue'
        ? '<span class="status-badge overdue">Vencido</span>'
        : dueStatus === 'due-soon'
          ? `<span class="status-badge due-soon">${loan.dueDate === getLocalDateValue()
            ? `Vence hoy a las ${escapeHtml(loan.endTime ? loan.endTime.slice(0, 5) : '23:59')}`
            : `Vence el ${escapeHtml(formatDateOnly(loan.dueDate))} a las ${escapeHtml(loan.endTime ? loan.endTime.slice(0, 5) : '23:59')}`}</span>`
          : dueStatus === 'pending'
            ? `<span class="status-badge good">${loan.dueDate ? 'Vigente' : 'Sin fecha límite'}</span>`
            : '';
      const returnAction = loan.isConsumable
        ? '<span class="status-badge neutral">Consumido</span>'
        : outstanding > 0
          ? `<form class="return-form" data-loan-id="${escapeHtml(loan.id)}" data-item-id="${escapeHtml(loan.loanItemId)}">
               <input type="number" name="quantity" min="1" max="${outstanding}" value="${outstanding}" aria-label="Cantidad a devolver" required />
               <button type="submit">Devolver</button>
             </form>`
          : '<span class="status-badge good">Completado</span>';
      const commonCells = index === 0 ? `
        <td rowspan="${items.length}">${escapeHtml(loan.campusName || '—')}</td>
        <td rowspan="${items.length}">${escapeHtml(loan.journey || 'Sin especificar')}</td>
        <td rowspan="${items.length}">
          <div>Inicio: ${escapeHtml(formatDateOnly(loan.loanDate))} ${escapeHtml(loan.startTime ? loan.startTime.slice(0, 5) : '—')}</div>
          <small>Registrado ${escapeHtml(formatLoanTime(loan.createdAt))}</small>
          <small class="loan-reference">Préstamo n.º ${escapeHtml(loan.id)}</small>
        </td>
        <td rowspan="${items.length}">
          <div>${loan.dueDate ? escapeHtml(formatDateOnly(loan.dueDate)) : '—'}</div>
          <div>Término: ${escapeHtml(loan.endTime ? loan.endTime.slice(0, 5) : loan.dueDate ? '23:59' : '—')}</div>
          ${dueStatusLabel}
        </td>
        <td rowspan="${items.length}">${escapeHtml(loan.clientName || '—')}</td>
        <td rowspan="${items.length}">${escapeHtml(loan.rut)}</td>
        <td rowspan="${items.length}">${escapeHtml(loan.area)}</td>
        <td rowspan="${items.length}">${escapeHtml(loan.careerName || '—')}</td>
        <td rowspan="${items.length}">${escapeHtml(loan.subject || '—')}</td>
      ` : '';
      return `
        <tr>
          ${commonCells}
          <td>
            <div>${escapeHtml(loan.productCode)}</div>
            <small>${escapeHtml(loan.productName)}</small>
          </td>
          <td>${loan.quantity} ${escapeHtml(loan.unitOfMeasure)}</td>
          <td>${loan.isConsumable ? '—' : `${loan.returnedQuantity} ${escapeHtml(loan.unitOfMeasure)}`}</td>
          <td>${outstanding} ${escapeHtml(loan.unitOfMeasure)}</td>
          <td>${returnAction}</td>
          ${index === 0 ? `
            <td rowspan="${items.length}">
              <button type="button" class="danger-btn" data-action="delete-loan" data-id="${escapeHtml(loan.id)}">
                Eliminar préstamo
              </button>
            </td>
          ` : ''}
        </tr>
      `;
    }).join('')).join('')
    : '<tr><td class="empty-state" colspan="15">No hay préstamos que coincidan con los filtros seleccionados.</td></tr>';
}

async function loadLoans() {
  const result = await apiRequest('/api/loans');
  loans = result.loans;
  renderLoans();
  showLoanError('');
}

function renderLoanHistory() {
  loanHistoryTableBody.innerHTML = loanHistory.length
    ? loanHistory.map((loan) => {
      const status = loan.isDeleted
        ? '<span class="status-badge neutral">Eliminado</span>'
        : loan.isConsumable
          ? '<span class="status-badge neutral">Consumido</span>'
          : Number(loan.outstanding) > 0
            ? getLoanDueStatus([loan]) === 'overdue'
              ? '<span class="status-badge overdue">Vencido</span>'
              : getLoanDueStatus([loan]) === 'due-soon'
                ? '<span class="status-badge due-soon">Próximo a vencer</span>'
                : '<span class="status-badge good">Vigente</span>'
            : '<span class="status-badge good">Completado</span>';
      return `
        <tr>
          <td>${escapeHtml(loan.campusName || '—')}</td>
          <td>${escapeHtml(loan.journey || 'Sin especificar')}</td>
          <td>
            <div>${escapeHtml(formatDateOnly(loan.loanDate))}</div>
            <small>Inicio ${escapeHtml(loan.startTime ? loan.startTime.slice(0, 5) : '—')}</small>
            <small>Registro ${escapeHtml(formatLoanTime(loan.createdAt))}</small>
          </td>
          <td>
            <div>${loan.dueDate ? escapeHtml(formatDateOnly(loan.dueDate)) : '—'}</div>
            <small>Término ${escapeHtml(loan.endTime ? loan.endTime.slice(0, 5) : loan.dueDate ? '23:59' : '—')}</small>
          </td>
          <td>${escapeHtml(loan.clientName || '—')}</td>
          <td>${escapeHtml(loan.rut)}</td>
          <td>${escapeHtml(loan.area)}</td>
          <td>${escapeHtml(loan.careerName || '—')}</td>
          <td>${escapeHtml(loan.subject || '—')}</td>
          <td>
            <div>${escapeHtml(loan.productCode)}</div>
            <small>${escapeHtml(loan.productName)}</small>
          </td>
          <td>${loan.quantity} ${escapeHtml(loan.unitOfMeasure)}</td>
          <td>${loan.isConsumable ? '—' : `${loan.returnedQuantity} ${escapeHtml(loan.unitOfMeasure)}`}</td>
          <td>${loan.cancelledQuantity} ${escapeHtml(loan.unitOfMeasure)}</td>
          <td>${status}</td>
          <td>${loan.deletedAt ? escapeHtml(formatLoanDateTime(loan.deletedAt)) : '—'}</td>
        </tr>
      `;
    }).join('')
    : '<tr><td class="empty-state" colspan="15">No hay historial de préstamos disponible.</td></tr>';
}

async function loadLoanHistory() {
  const result = await apiRequest('/api/loans/history');
  loanHistory = result.loans;
  renderLoanHistory();
  showDashboardError('');
}

authForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showAuthError('');
  authSubmit.disabled = true;

  let isAuthenticated = false;
  try {
    const result = await apiRequest('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        email: authEmail.value,
        password: authPassword.value
      })
    });
    setAuthenticated(result.user);
    isAuthenticated = true;
    await loadCampuses();
    await loadClassifications();
    await loadAcademicCatalog();
    await loadInventory();
    await loadClients();
    selectLoanCampusWithInventory();
    await loadLoans();
  } catch (error) {
    if (isAuthenticated) showDashboardError(error.message);
    else showAuthError(error.message);
  } finally {
    authSubmit.disabled = false;
  }
});

document.getElementById('logoutButton').addEventListener('click', async () => {
  try {
    await apiRequest('/api/auth/logout', { method: 'POST' });
    inventory = [];
    archivedInventory = [];
    loans = [];
    campuses = [];
    invoices = [];
    clients = [];
    writeOffs = [];
    activePage = 'dashboardPage';
    Object.keys(searchTerms).forEach((key) => { searchTerms[key] = ''; });
    inventoryCategoryFilter.value = '';
    inventoryCampusFilter.value = '';
    inventoryStockFilter.value = 'all';
    invoiceSupplierFilter.value = '';
    clientAreaFilter.value = '';
    clearAdminUsers();
    loanJourneyFilter.value = 'all';
    loanStatusFilter.value = 'all';
    showingArchived = false;
    showingDeletedWriteOffs = false;
    toggleArchived.textContent = 'Ver archivados';
    toggleDeletedWriteOffs.textContent = 'Ver bajas anuladas';
    showInventoryView('list');
    renderLoans();
    renderClients();
    updateLoanClientOptions('');
    renderWriteOffs();
    resetLoanItems();
    resetStockForm();
    resetWriteOffForm();
    setLoggedOut();
    updateSearchBar();
  } catch (error) {
    window.alert(error.message);
  }
});

searchInput.addEventListener('input', (event) => {
  const context = getSearchContext();
  if (!context) return;
  searchTerms[context.key] = event.target.value;
  if (context.key === 'inventory') refreshInventory(searchTerms.inventory);
  if (context.key === 'loans') renderLoans();
  if (context.key === 'invoices') renderInvoices();
  if (context.key === 'clients') renderClients();
});

inventoryCategoryFilter.addEventListener('change', () => refreshInventory(searchTerms.inventory));
inventoryCampusFilter.addEventListener('change', () => refreshInventory(searchTerms.inventory));
inventoryStockFilter.addEventListener('change', () => refreshInventory(searchTerms.inventory));
invoiceSupplierFilter.addEventListener('change', renderInvoices);
clientAreaFilter.addEventListener('change', renderClients);

function showSpreadsheetError(element, error) {
  const details = Array.isArray(error.details)
    ? error.details.map((item) => `Fila ${item.row}: ${item.message}`).join(' ')
    : '';
  const remaining = error.totalErrors > error.details.length
    ? `Se encontraron ${error.totalErrors} errores en total; se muestran los primeros ${error.details.length}.`
    : '';
  element.textContent = [error.message, details, remaining].filter(Boolean).join(' ');
  element.hidden = false;
}

async function downloadEntitySpreadsheet(type, template, button, errorElement, messageElement) {
  button.disabled = true;
  errorElement.hidden = true;
  messageElement.hidden = true;
  try {
    const url = template
      ? `/api/spreadsheets/templates/${type}`
      : `/api/spreadsheets/${type}`;
    const filename = `${template ? 'plantilla-' : ''}${type === 'clients' ? 'clientes' : 'productos'}-stockflow.xlsx`;
    await downloadSpreadsheet(url, filename);
    messageElement.textContent = template ? 'Se descargó la plantilla Excel.' : 'Se descargó el archivo Excel.';
    messageElement.hidden = false;
  } catch (error) {
    showSpreadsheetError(errorElement, error);
  } finally {
    button.disabled = false;
  }
}

async function importEntitySpreadsheet(type, fileInput, button, errorElement, messageElement) {
  const file = fileInput.files[0];
  if (!file) return;
  button.disabled = true;
  errorElement.hidden = true;
  messageElement.hidden = true;
  try {
    const result = await importSpreadsheet(type, file);
    messageElement.textContent = result.message;
    messageElement.hidden = false;
    try {
      if (type === 'clients') await loadClients();
      else {
        await loadInventory(false);
        await loadInventory(true);
      }
    } catch (error) {
      showSpreadsheetError(errorElement, new Error(`${result.message} No se pudo actualizar la lista: ${error.message}`));
    }
  } catch (error) {
    showSpreadsheetError(errorElement, error);
  } finally {
    fileInput.value = '';
    button.disabled = false;
  }
}

exportProductsButton.addEventListener('click', () => downloadEntitySpreadsheet(
  'products', false, exportProductsButton, productsTransferError, productsTransferMessage
));
productTemplateButton.addEventListener('click', () => downloadEntitySpreadsheet(
  'products', true, productTemplateButton, productsTransferError, productsTransferMessage
));
importProductsButton.addEventListener('click', () => importProductsFile.click());
importProductsFile.addEventListener('change', () => importEntitySpreadsheet(
  'products', importProductsFile, importProductsButton, productsTransferError, productsTransferMessage
));
exportClientsButton.addEventListener('click', () => downloadEntitySpreadsheet(
  'clients', false, exportClientsButton, clientsTransferError, clientsTransferMessage
));
clientTemplateButton.addEventListener('click', () => downloadEntitySpreadsheet(
  'clients', true, clientTemplateButton, clientsTransferError, clientsTransferMessage
));
importClientsButton.addEventListener('click', () => importClientsFile.click());
importClientsFile.addEventListener('change', () => importEntitySpreadsheet(
  'clients', importClientsFile, importClientsButton, clientsTransferError, clientsTransferMessage
));

toggleArchived.addEventListener('click', async () => {
  showingArchived = !showingArchived;
  toggleArchived.textContent = showingArchived ? 'Ver productos activos' : 'Ver archivados';
  showInventoryView('list');
  searchTerms.inventory = '';
  updateSearchBar();
  try {
    await loadInventory(showingArchived);
  } catch (error) {
    showDashboardError(error.message);
  }
});

dashboardNav.addEventListener('click', () => showPage('dashboardPage'));
inventoryNav.addEventListener('click', () => showPage('inventoryPage'));
writeOffNav.addEventListener('click', () => showPage('writeOffPage'));
inventoryListTab.addEventListener('click', () => showInventoryView('list'));
productCreateTab.addEventListener('click', () => showInventoryView('create'));
classificationsNav.addEventListener('click', () => showPage('classificationsPage'));
campusesNav.addEventListener('click', () => showPage('campusesPage'));
academicCatalogNav.addEventListener('click', () => showPage('academicCatalogPage'));
invoicesNav.addEventListener('click', () => showPage('invoicesPage'));
clientsNav.addEventListener('click', () => showPage('clientsPage'));
loansNav.addEventListener('click', () => showPage('loansPage'));
loanHistoryNav.addEventListener('click', () => showPage('loanHistoryPage'));
usersNav.addEventListener('click', () => showPage('usersPage'));
manualNav.addEventListener('click', () => showPage('manualPage'));
loanListTab.addEventListener('click', () => showLoanView('list'));
loanCreateTab.addEventListener('click', () => showLoanView('create'));

productCategory.addEventListener('change', () => updateProductSubcategories(''));
loanCampus.addEventListener('change', () => renderLoanProductOptions());
loanClient.addEventListener('change', () => updateLoanClientOptions(loanClient.value));
loanCareer.addEventListener('change', () => updateLoanSubjects(''));
writeOffProduct.addEventListener('change', () => {
  const currentWriteOff = writeOffs.find((item) => String(item.id) === editingWriteOffId);
  updateWriteOffProductOptions(writeOffProduct.value, currentWriteOff || null);
});
writeOffQuantity.addEventListener('input', () => {
  const currentWriteOff = writeOffs.find((item) => String(item.id) === editingWriteOffId);
  const product = inventory.find((item) => String(item.id) === writeOffProduct.value);
  const availableStock = Number(product?.stock || 0) +
    (currentWriteOff && String(currentWriteOff.productId) === writeOffProduct.value
      ? Number(currentWriteOff.quantity)
      : 0);
  writeOffQuantity.setCustomValidity(
    Number(writeOffQuantity.value) > availableStock
      ? 'La cantidad supera las existencias disponibles.'
      : ''
  );
});
toggleDeletedWriteOffs.addEventListener('click', async () => {
  showingDeletedWriteOffs = !showingDeletedWriteOffs;
  toggleDeletedWriteOffs.textContent = showingDeletedWriteOffs ? 'Ver bajas activas' : 'Ver bajas anuladas';
  showWriteOffError('');
  try {
    await loadWriteOffs();
  } catch (error) {
    showWriteOffError(error.message);
  }
});

writeOffForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showWriteOffError('');
  showWriteOffMessage('');
  writeOffSubmit.disabled = true;
  const wasEditing = Boolean(editingWriteOffId);
  try {
    await apiRequest(
      wasEditing ? `/api/write-offs/${encodeURIComponent(editingWriteOffId)}` : '/api/write-offs',
      {
        method: wasEditing ? 'PUT' : 'POST',
        body: JSON.stringify({
          productId: writeOffProduct.value,
          date: writeOffDate.value,
          location: document.getElementById('writeOffLocation').value,
          quantity: Number(writeOffQuantity.value),
          reason: document.getElementById('writeOffReason').value,
          observation: document.getElementById('writeOffObservation').value
        })
      }
    );
    resetWriteOffForm();
    await loadInventory();
    await loadWriteOffs();
    showWriteOffMessage(wasEditing ? 'Se modificó la baja y se actualizaron las existencias.' : 'Se registró la baja y se actualizaron las existencias.');
  } catch (error) {
    showWriteOffError(error.message);
  } finally {
    writeOffSubmit.disabled = false;
  }
});

cancelWriteOffEdit.addEventListener('click', () => {
  resetWriteOffForm();
  showWriteOffError('');
  showWriteOffMessage('');
});

writeOffsTableBody.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action]')
    : null;
  if (!button) return;
  const writeOff = writeOffs.find((item) => String(item.id) === button.dataset.id);
  if (!writeOff || writeOff.isDeleted) {
    showWriteOffError('No se encontró la baja activa. Actualiza la lista e inténtalo de nuevo.');
    return;
  }
  if (button.dataset.action === 'edit-write-off') {
    editWriteOff(writeOff);
    return;
  }
  if (button.dataset.action !== 'delete-write-off') return;
  if (!window.confirm(`¿Eliminar la baja EB-${writeOff.id}? Las ${writeOff.quantity} existencias se devolverán al inventario y el registro quedará en el historial.`)) {
    return;
  }

  button.disabled = true;
  showWriteOffError('');
  showWriteOffMessage('');
  try {
    await apiRequest(`/api/write-offs/${encodeURIComponent(writeOff.id)}`, { method: 'DELETE' });
    if (editingWriteOffId === String(writeOff.id)) resetWriteOffForm();
    await loadInventory();
    await loadWriteOffs();
    showWriteOffMessage('Se anuló la baja y se restituyeron las existencias.');
  } catch (error) {
    showWriteOffError(error.message);
  } finally {
    button.disabled = false;
  }
});

clientForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showClientError('');
  showClientMessage('');
  clientSubmit.disabled = true;
  const wasEditing = Boolean(editingClientId);
  try {
    await apiRequest(
      wasEditing ? `/api/clients/${encodeURIComponent(editingClientId)}` : '/api/clients',
      {
        method: wasEditing ? 'PUT' : 'POST',
        body: JSON.stringify({
          name: document.getElementById('clientName').value,
          rut: document.getElementById('clientRut').value,
          email: document.getElementById('clientEmail').value,
          area: document.getElementById('clientArea').value
        })
      }
    );
    resetClientForm();
    await loadClients();
    showClientMessage(wasEditing ? 'Se actualizaron los datos del cliente.' : 'Se creó el cliente.');
  } catch (error) {
    showClientError(error.message);
  } finally {
    clientSubmit.disabled = false;
  }
});

cancelClientEdit.addEventListener('click', () => {
  resetClientForm();
  showClientError('');
  showClientMessage('');
});

clientsTableBody.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action]')
    : null;
  if (!button) return;
  const customer = clients.find((item) => String(item.id) === button.dataset.id);
  if (!customer) {
    showClientError('No se encontró el cliente seleccionado. Actualiza la lista e inténtalo de nuevo.');
    return;
  }
  if (button.dataset.action === 'edit-client') {
    editClient(customer);
    return;
  }
  if (button.dataset.action !== 'delete-client') return;
  if (!window.confirm(`¿Eliminar al cliente "${customer.name}"?`)) return;
  button.disabled = true;
  showClientError('');
  showClientMessage('');
  try {
    await apiRequest(`/api/clients/${encodeURIComponent(customer.id)}`, { method: 'DELETE' });
    if (editingClientId === String(customer.id)) resetClientForm();
    await loadClients();
    showClientMessage('Se eliminó el cliente.');
  } catch (error) {
    showClientError(error.message);
  } finally {
    button.disabled = false;
  }
});

invoiceForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showInvoiceError('');
  showInvoiceMessage('');
  invoiceSubmit.disabled = true;
  try {
    const wasEditing = Boolean(editingInvoiceId);
    await apiRequest(
      wasEditing ? `/api/invoices/${encodeURIComponent(editingInvoiceId)}` : '/api/invoices',
      {
        method: wasEditing ? 'PATCH' : 'POST',
        body: JSON.stringify({
          supplierRut: document.getElementById('invoiceSupplierRut').value,
          invoiceNumber: document.getElementById('invoiceNumber').value
        })
      }
    );
    resetInvoiceForm();
    await loadInvoices();
    showInvoiceMessage(wasEditing ? 'Se actualizaron los datos de la factura.' : 'Se registró la factura.');
  } catch (error) {
    showInvoiceError(error.message);
  } finally {
    invoiceSubmit.disabled = false;
  }
});

cancelInvoiceEdit.addEventListener('click', () => {
  resetInvoiceForm();
  showInvoiceError('');
  showInvoiceMessage('');
});

invoicesTableBody.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action]')
    : null;
  if (!button) return;
  const invoice = invoices.find((item) => String(item.id) === button.dataset.id);
  if (!invoice) {
    showInvoiceError('No se encontró la factura seleccionada. Actualiza la lista e inténtalo de nuevo.');
    return;
  }
  if (button.dataset.action === 'edit-invoice') {
    editInvoice(invoice);
    return;
  }
  if (button.dataset.action !== 'delete-invoice') return;
  if (!window.confirm(`¿Eliminar la factura n.º ${invoice.invoiceNumber} del proveedor ${invoice.supplierRut}?`)) return;

  button.disabled = true;
  showInvoiceError('');
  showInvoiceMessage('');
  try {
    await apiRequest(`/api/invoices/${encodeURIComponent(invoice.id)}`, { method: 'DELETE' });
    if (editingInvoiceId === String(invoice.id)) resetInvoiceForm();
    await loadInvoices();
    showInvoiceMessage('Se eliminó la factura.');
  } catch (error) {
    showInvoiceError(error.message);
  } finally {
    button.disabled = false;
  }
});

campusForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showCampusError('');
  showCampusMessage('');
  try {
    await apiRequest('/api/campuses', {
      method: 'POST',
      body: JSON.stringify({ name: document.getElementById('campusName').value })
    });
    campusForm.reset();
    await refreshCampusAssignments();
    showCampusMessage('Se agregó la sede.');
  } catch (error) {
    showCampusError(error.message);
  }
});

campusesList.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action="delete-campus"]')
    : null;
  if (!button) return;
  if (!window.confirm('¿Eliminar esta sede?')) return;
  button.disabled = true;
  showCampusError('');
  showCampusMessage('');
  try {
    await apiRequest(`/api/campuses/${encodeURIComponent(button.dataset.id)}`, { method: 'DELETE' });
    await refreshCampusAssignments();
    showCampusMessage('Se eliminó la sede.');
  } catch (error) {
    showCampusError(error.message);
  } finally {
    button.disabled = false;
  }
});

campusesList.addEventListener('submit', async (event) => {
  const form = event.target instanceof Element
    ? event.target.closest('form[data-action="rename-campus"]')
    : null;
  if (!form) return;
  event.preventDefault();
  const name = form.querySelector('input').value;
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  showCampusError('');
  showCampusMessage('');
  try {
    await apiRequest(`/api/campuses/${encodeURIComponent(form.dataset.id)}`, {
      method: 'PATCH',
      body: JSON.stringify({ name })
    });
    await refreshCampusAssignments();
    showCampusMessage('Se actualizó el nombre de la sede.');
  } catch (error) {
    showCampusError(error.message);
  } finally {
    button.disabled = false;
  }
});

careerForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showAcademicCatalogError('');
  showAcademicCatalogMessage('');
  try {
    await apiRequest('/api/academic-catalog/careers', {
      method: 'POST',
      body: JSON.stringify({ name: document.getElementById('careerName').value })
    });
    careerForm.reset();
    await loadAcademicCatalog();
    showAcademicCatalogMessage('Se agregó la carrera.');
  } catch (error) {
    showAcademicCatalogError(error.message);
  }
});

subjectForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showAcademicCatalogError('');
  showAcademicCatalogMessage('');
  try {
    await apiRequest(
      `/api/academic-catalog/careers/${encodeURIComponent(subjectCareer.value)}/subjects`,
      { method: 'POST', body: JSON.stringify({ name: document.getElementById('subjectName').value }) }
    );
    document.getElementById('subjectName').value = '';
    await loadAcademicCatalog();
    showAcademicCatalogMessage('Se agregó la asignatura.');
  } catch (error) {
    showAcademicCatalogError(error.message);
  }
});

academicCatalogList.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action="delete-career"], button[data-action="delete-subject"]')
    : null;
  if (!button) return;
  const isCareer = button.dataset.action === 'delete-career';
  const confirmation = isCareer
    ? '¿Eliminar esta carrera y todas sus asignaturas?'
    : '¿Eliminar esta asignatura?';
  if (!window.confirm(confirmation)) return;
  button.disabled = true;
  showAcademicCatalogError('');
  showAcademicCatalogMessage('');
  try {
    const endpoint = isCareer
      ? `/api/academic-catalog/careers/${encodeURIComponent(button.dataset.id)}`
      : `/api/academic-catalog/subjects/${encodeURIComponent(button.dataset.id)}`;
    await apiRequest(endpoint, { method: 'DELETE' });
    await loadAcademicCatalog();
    showAcademicCatalogMessage(isCareer ? 'Se eliminó la carrera y sus asignaturas.' : 'Se eliminó la asignatura.');
  } catch (error) {
    showAcademicCatalogError(error.message);
  } finally {
    button.disabled = false;
  }
});

academicCatalogList.addEventListener('submit', async (event) => {
  const form = event.target instanceof Element
    ? event.target.closest('form[data-action="rename-career"], form[data-action="rename-subject"]')
    : null;
  if (!form) return;
  event.preventDefault();
  const isCareer = form.dataset.action === 'rename-career';
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  showAcademicCatalogError('');
  showAcademicCatalogMessage('');
  try {
    const endpoint = isCareer
      ? `/api/academic-catalog/careers/${encodeURIComponent(form.dataset.id)}`
      : `/api/academic-catalog/subjects/${encodeURIComponent(form.dataset.id)}`;
    await apiRequest(endpoint, {
      method: 'PATCH',
      body: JSON.stringify({ name: form.querySelector('input').value })
    });
    await loadAcademicCatalog();
    showAcademicCatalogMessage(isCareer ? 'Se actualizó la carrera.' : 'Se actualizó la asignatura.');
  } catch (error) {
    showAcademicCatalogError(error.message);
  } finally {
    button.disabled = false;
  }
});

categoryForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showClassificationError('');
  showClassificationMessage('');
  try {
    await apiRequest('/api/classifications/categories', {
      method: 'POST',
      body: JSON.stringify({ name: document.getElementById('categoryName').value })
    });
    categoryForm.reset();
    await loadClassifications();
    showClassificationMessage('Se agregó la categoría.');
  } catch (error) {
    showClassificationError(error.message);
  }
});

subcategoryForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showClassificationError('');
  showClassificationMessage('');
  try {
    await apiRequest('/api/classifications/subcategories', {
      method: 'POST',
      body: JSON.stringify({
        categoryId: subcategoryParent.value,
        name: document.getElementById('subcategoryName').value
      })
    });
    subcategoryForm.reset();
    await loadClassifications();
    showClassificationMessage('Se agregó la subcategoría.');
  } catch (error) {
    showClassificationError(error.message);
  }
});

unitForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showClassificationError('');
  showClassificationMessage('');
  try {
    await apiRequest('/api/classifications/units', {
      method: 'POST',
      body: JSON.stringify({ name: document.getElementById('unitName').value })
    });
    unitForm.reset();
    await loadClassifications();
    showClassificationMessage('Se agregó la unidad de medida.');
  } catch (error) {
    showClassificationError(error.message);
  }
});

unitOptionsList.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action="delete-unit"]')
    : null;
  if (!button) return;
  if (!window.confirm('¿Eliminar esta unidad de medida?')) return;
  button.disabled = true;
  showClassificationError('');
  showClassificationMessage('');
  try {
    await apiRequest(`/api/classifications/units/${encodeURIComponent(button.dataset.id)}`, {
      method: 'DELETE'
    });
    await loadClassifications();
    showClassificationMessage('Se eliminó la unidad de medida.');
  } catch (error) {
    showClassificationError(error.message);
  } finally {
    button.disabled = false;
  }
});

classificationsList.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action^="delete-"]')
    : null;
  if (!button) return;
  const isCategory = button.dataset.action === 'delete-category';
  const label = isCategory ? 'categoría' : 'subcategoría';
  if (!window.confirm(`¿Eliminar esta ${label}?`)) return;
  button.disabled = true;
  showClassificationError('');
  showClassificationMessage('');
  try {
    await apiRequest(
      `/api/classifications/${isCategory ? 'categories' : 'subcategories'}/${encodeURIComponent(button.dataset.id)}`,
      { method: 'DELETE' }
    );
    await loadClassifications();
    showClassificationMessage(`Se eliminó la ${label}.`);
  } catch (error) {
    showClassificationError(error.message);
  } finally {
    button.disabled = false;
  }
});

unitOptionsList.addEventListener('submit', async (event) => {
  const form = event.target instanceof Element
    ? event.target.closest('form[data-action="rename-unit"]')
    : null;
  if (!form) return;
  event.preventDefault();
  const name = form.querySelector('input').value;
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  showClassificationError('');
  showClassificationMessage('');
  try {
    await apiRequest(`/api/classifications/units/${encodeURIComponent(form.dataset.id)}`, {
      method: 'PATCH',
      body: JSON.stringify({ name })
    });
    await loadClassifications();
    await loadInventory(false);
    await loadInventory(true);
    showClassificationMessage('Se actualizó la unidad de medida, incluidos los productos asignados.');
  } catch (error) {
    showClassificationError(error.message);
  } finally {
    button.disabled = false;
  }
});

classificationsList.addEventListener('submit', async (event) => {
  const form = event.target instanceof Element
    ? event.target.closest('form[data-action^="rename-"]')
    : null;
  if (!form) return;
  event.preventDefault();
  const isCategory = form.dataset.action === 'rename-category';
  const endpoint = isCategory ? 'categories' : 'subcategories';
  const name = form.querySelector('input').value;
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  showClassificationError('');
  showClassificationMessage('');
  try {
    await apiRequest(`/api/classifications/${endpoint}/${encodeURIComponent(form.dataset.id)}`, {
      method: 'PATCH',
      body: JSON.stringify({ name })
    });
    await loadClassifications();
    await loadInventory(false);
    await loadInventory(true);
    showClassificationMessage(`Se actualizó la ${isCategory ? 'categoría' : 'subcategoría'}.`);
  } catch (error) {
    showClassificationError(error.message);
  } finally {
    button.disabled = false;
  }
});

function resetStockForm() {
  stopBarcodeScan('También puedes usar un lector USB.');
  editingId = null;
  stockForm.reset();
  document.getElementById('productStock').value = 0;
  document.getElementById('productReorder').value = 10;
  document.getElementById('productPrice').value = 0;
  document.getElementById('productCharacteristics').value = '';
  document.getElementById('productDescription').value = '';
  productImage.value = '';
  productImage.required = true;
  showProductImagePreview('');
  productIsConsumable.checked = false;
  productUnitOfMeasure.value = 'Unidades';
  productCampus.value = campuses.length ? String(campuses[0].id) : '';
  productState.value = 'Disponible';
  productQuality.value = 'Buena';
  stockFormTitle.textContent = 'Agregar producto';
  stockSubmit.textContent = 'Guardar producto';
  cancelEdit.hidden = true;
  showStockError('');
  showStockMessage('');
}

function editProduct(product) {
  stopBarcodeScan('También puedes usar un lector USB.');
  editingId = String(product.id);
  document.getElementById('productName').value = product.name;
  productBarcode.value = product.barcode || '';
  productCategory.value = product.categoryId || '';
  updateProductSubcategories(product.subcategoryId || '');
  productUnitOfMeasure.value = product.unitOfMeasure || 'Unidades';
  productCampus.value = String(product.campusId);
  document.getElementById('productStock').value = product.stock;
  document.getElementById('productReorder').value = product.reorderLevel;
  document.getElementById('productPrice').value = product.price;
  document.getElementById('productSupplier').value = product.supplier;
  document.getElementById('productCharacteristics').value = product.characteristics || '';
  document.getElementById('productDescription').value = product.description || '';
  productImage.value = '';
  productImage.required = false;
  showProductImagePreview(product.imageData
    ? `data:${product.imageMimeType};base64,${product.imageData}`
    : '');
  productIsConsumable.checked = product.isConsumable;
  productState.value = product.state;
  productQuality.value = product.quality;
  stockFormTitle.textContent = 'Editar producto';
  stockSubmit.textContent = 'Guardar cambios';
  cancelEdit.hidden = false;
  showStockError('');
  showStockMessage('');
  showInventoryView('create');
  stockForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

inventoryTableBody.addEventListener('click', async (event) => {
  const button = event.target instanceof Element ? event.target.closest('button[data-action]') : null;
  if (!button) return;

  const productList = showingArchived ? archivedInventory : inventory;
  const product = productList.find((item) => String(item.id) === button.dataset.id);
  if (!product) {
    showStockError('No se encontró el producto seleccionado. Actualiza la lista e inténtalo de nuevo.');
    return;
  }

  if (button.dataset.action === 'edit' && !showingArchived) {
    editProduct(product);
    return;
  }

  const shouldArchive = button.dataset.action === 'archive' && !showingArchived;
  const shouldRestore = button.dataset.action === 'restore' && showingArchived;
  if (!shouldArchive && !shouldRestore) return;
  if (shouldArchive && !window.confirm(`¿Archivar "${product.name}"? Dejará de aparecer en el inventario activo, pero podrás restaurarlo más adelante.`)) return;

  button.disabled = true;
  showStockError('');
  showStockMessage('');
  try {
    await apiRequest(`/api/products/${encodeURIComponent(product.id)}/archive`, {
      method: 'PATCH',
      body: JSON.stringify({ archived: shouldArchive })
    });
    if (editingId === String(product.id)) resetStockForm();
    await loadInventory(showingArchived);
    if (showingArchived) await loadInventory(false);
    showStockMessage(shouldArchive
      ? `"${product.name}" se archivó y podrás restaurarlo más adelante.`
      : `"${product.name}" se restauró al inventario activo.`);
  } catch (error) {
    showStockError(error.message);
  } finally {
    button.disabled = false;
  }
});

cancelEdit.addEventListener('click', () => {
  resetStockForm();
  showInventoryView('list');
});

productImage.addEventListener('change', async () => {
  const file = productImage.files[0];
  if (!file) return;
  if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
    productImage.value = '';
    showProductImagePreview('');
    showStockError('La imagen debe estar en formato JPEG, PNG o WebP.');
    return;
  }
  if (file.size === 0 || file.size > 2 * 1024 * 1024) {
    productImage.value = '';
    showProductImagePreview('');
    showStockError('La imagen debe tener un tamaño máximo de 2 MB.');
    return;
  }
  showStockError('');
  try {
    showProductImagePreview(await readImageAsDataUrl(file));
  } catch (error) {
    showStockError(error.message);
  }
});

stockForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showStockError('');
  showStockMessage('');

  const product = {
    name: document.getElementById('productName').value.trim(),
    barcode: productBarcode.value.trim(),
    category: productCategory.selectedOptions[0] ? productCategory.selectedOptions[0].textContent : '',
    categoryId: productCategory.value,
    subcategoryId: productSubcategory.value,
    campusId: productCampus.value,
    unitOfMeasure: productUnitOfMeasure.value,
    stock: Number(document.getElementById('productStock').value),
    reorderLevel: Number(document.getElementById('productReorder').value),
    price: Number(document.getElementById('productPrice').value),
    supplier: document.getElementById('productSupplier').value.trim(),
    isConsumable: productIsConsumable.checked,
    state: productState.value,
    quality: productQuality.value,
    characteristics: document.getElementById('productCharacteristics').value,
    description: document.getElementById('productDescription').value
  };
  stockSubmit.disabled = true;

  try {
    const imageFile = productImage.files[0];
    if (imageFile) {
      const dataUrl = await readImageAsDataUrl(imageFile);
      const separatorIndex = dataUrl.indexOf(',');
      product.imageData = dataUrl.slice(separatorIndex + 1);
      product.imageMimeType = imageFile.type;
    }
    const wasEditing = Boolean(editingId);
    const result = await apiRequest(
      editingId ? `/api/products/${encodeURIComponent(editingId)}` : '/api/products',
      {
        method: editingId ? 'PUT' : 'POST',
        body: JSON.stringify(product)
      }
    );
    const selectedCategory = classifications.find((item) => String(item.id) === product.categoryId);
    result.product.subcategory = selectedCategory?.subcategories
      .find((item) => String(item.id) === product.subcategoryId)?.name || null;
    result.product.campusName = campuses.find((campus) => String(campus.id) === product.campusId)?.name || '';
    if (editingId) {
      inventory = inventory.map((item) => (
        String(item.id) === editingId ? result.product : item
      ));
    } else {
      inventory.push(result.product);
    }
    resetStockForm();
    refreshInventory(searchTerms.inventory);
    showStockMessage(wasEditing ? 'Se guardaron los cambios del producto.' : 'Se agregó el producto al inventario.');
  } catch (error) {
    showStockError(error.message);
  } finally {
    stockSubmit.disabled = false;
  }
});

loanItemsContainer.addEventListener('change', (event) => {
  if (!(event.target instanceof Element) || !event.target.matches('.loan-product-select')) return;
  const selectedProductId = event.target.value;
  const alreadySelected = [...loanItemsContainer.querySelectorAll('.loan-product-select')]
    .some((select) => select !== event.target && select.value === selectedProductId);
  if (selectedProductId && alreadySelected) {
    event.target.value = '';
    showLoanError('Cada producto solo se puede agregar una vez al mismo préstamo.');
  } else {
    showLoanError('');
  }
  renderLoanProductOptions();
});

loanItemsContainer.addEventListener('input', (event) => {
  if (event.target instanceof Element && event.target.matches('.loan-item-quantity')) {
    const productId = event.target.closest('.loan-item-row').querySelector('.loan-product-select').value;
    const product = inventory.find((item) => String(item.id) === productId);
    if (product) {
      const totalForProduct = [...loanItemsContainer.querySelectorAll('.loan-item-row')]
        .filter((itemRow) => itemRow.querySelector('.loan-product-select').value === productId)
        .reduce((sum, itemRow) => sum + Number(itemRow.querySelector('.loan-item-quantity').value || 0), 0);
      event.target.setCustomValidity(totalForProduct > product.stock ? 'La cantidad total supera las existencias disponibles.' : '');
    } else {
      event.target.setCustomValidity('');
    }
  }
});

loanItemsContainer.addEventListener('click', (event) => {
  const button = event.target instanceof Element ? event.target.closest('.remove-loan-item') : null;
  if (!button || loanItemsContainer.querySelectorAll('.loan-item-row').length <= 1) return;
  button.closest('.loan-item-row').remove();
  renderLoanProductOptions();
});

addLoanItemButton.addEventListener('click', () => {
  addLoanItemRow();
  showLoanError('');
});

loanForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  showLoanError('');
  showLoanMessage('');

  const loanItems = [...loanItemsContainer.querySelectorAll('.loan-item-row')].map((row) => ({
    productId: row.querySelector('.loan-product-select').value,
    quantity: Number(row.querySelector('.loan-item-quantity').value)
  }));
  const loan = {
    campusId: loanCampus.value,
    journey: loanJourney.value,
    loanDate: loanDate.value,
    startTime: loanStartTime.value,
    endTime: loanEndTime.value,
    dueDate: loanDueDate.value,
    rut: loanRut.value.trim(),
    area: document.getElementById('loanArea').value.trim(),
    clientId: loanClient.value || null,
    careerId: loanCareer.value,
    subjectId: loanSubject.value,
    subject: loanSubject.value ? loanSubject.selectedOptions[0]?.textContent || '' : '',
    items: loanItems
  };
  loanSubmit.disabled = true;
  try {
    await apiRequest('/api/loans', {
      method: 'POST',
      body: JSON.stringify(loan)
    });
    await loadInventory();
    await loadLoans();
    loanForm.reset();
    updateLoanClientOptions('');
    updateLoanSubjects('');
    loanDate.value = getLocalDateValue();
    setDefaultLoanTimes();
    updateDueDateMinimum();
    resetLoanItems();
    showLoanMessage(`Se registró el préstamo con ${loanItems.length} ${loanItems.length === 1 ? 'producto' : 'productos'} y se actualizaron las existencias.`);
  } catch (error) {
    showLoanError(error.message);
  } finally {
    loanSubmit.disabled = false;
  }
});

loansTableBody.addEventListener('submit', async (event) => {
  const form = event.target instanceof Element ? event.target.closest('form.return-form') : null;
  if (!form) return;
  event.preventDefault();
  showLoanError('');
  showLoanMessage('');

  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  try {
    await apiRequest(`/api/loans/${encodeURIComponent(form.dataset.loanId)}/items/${encodeURIComponent(form.dataset.itemId)}/returns`, {
      method: 'POST',
      body: JSON.stringify({ quantity: Number(form.elements.quantity.value) })
    });
    await loadInventory();
    await loadLoans();
    showLoanMessage('Se registró la devolución y se actualizaron las existencias.');
  } catch (error) {
    showLoanError(error.message);
  } finally {
    button.disabled = false;
  }
});

loansTableBody.addEventListener('click', async (event) => {
  const button = event.target instanceof Element
    ? event.target.closest('button[data-action="delete-loan"]')
    : null;
  if (!button) return;

  const loanItems = loans.filter((item) => String(item.id) === button.dataset.id);
  if (!loanItems.length) {
    showLoanError('No se encontró el préstamo seleccionado. Actualiza la lista e inténtalo de nuevo.');
    return;
  }

  const stockNotice = loanItems
    .filter((item) => !item.isConsumable && Number(item.outstanding) > 0)
    .map((item) => `${item.outstanding} ${item.unitOfMeasure} de "${item.productName}"`)
    .join(', ');
  const restockNotice = stockNotice ? ` Se repondrán: ${stockNotice}.` : '';
  if (!window.confirm(`¿Eliminar el préstamo n.º ${button.dataset.id} de ${loanItems[0].rut} con ${loanItems.length} ${loanItems.length === 1 ? 'producto' : 'productos'}? El registro se conservará en el historial.${restockNotice}`)) {
    return;
  }

  button.disabled = true;
  showLoanError('');
  showLoanMessage('');
  try {
    await apiRequest(`/api/loans/${encodeURIComponent(button.dataset.id)}`, { method: 'DELETE' });
    await loadInventory();
    await loadLoans();
    showLoanMessage(`El préstamo n.º ${button.dataset.id}, con ${loanItems.length} ${loanItems.length === 1 ? 'producto' : 'productos'}, se trasladó al historial.${restockNotice}`);
  } catch (error) {
    showLoanError(error.message);
  } finally {
    button.disabled = false;
  }
});

document.getElementById('authPassword').addEventListener('input', () => showAuthError(''));
loanDate.addEventListener('change', updateDueDateMinimum);
loanRut.addEventListener('input', validateLoanRut);
loanRut.addEventListener('blur', () => {
  const normalizedRut = normalizeChileanRut(loanRut.value);
  if (normalizedRut) loanRut.value = normalizedRut;
  validateLoanRut();
});
loanStartTime.addEventListener('input', validateLoanTimeRange);
loanEndTime.addEventListener('input', validateLoanTimeRange);
loanDueDate.addEventListener('change', validateLoanTimeRange);
loanJourneyFilter.addEventListener('change', renderLoans);
loanStatusFilter.addEventListener('change', renderLoans);
window.setInterval(() => {
  if (activePage === 'loansPage' && !loanListPanel.hidden) renderLoans();
  if (activePage === 'loanHistoryPage') renderLoanHistory();
}, 60_000);

async function initialize() {
  resetLoanItems();
  resetWriteOffForm();
  loanDate.value = getLocalDateValue();
  setDefaultLoanTimes();
  updateDueDateMinimum();
  let result;
  try {
    result = await apiRequest('/api/auth/me');
  } catch (error) {
    setLoggedOut();
    if (error.status !== 401) showAuthError(error.message);
    return;
  }

  setAuthenticated(result.user);
  try {
    await loadCampuses();
    await loadClassifications();
    await loadAcademicCatalog();
    await loadInventory();
    await loadClients();
    selectLoanCampusWithInventory();
    await loadLoans();
  } catch (error) {
    showDashboardError(error.message);
  }
}

initialize();
