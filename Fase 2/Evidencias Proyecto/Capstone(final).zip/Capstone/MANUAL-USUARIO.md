# Manual de usuario de StockFlow

StockFlow permite organizar productos por sede, controlar existencias y registrar préstamos con sus devoluciones. Esta guía describe las vistas disponibles, los campos y las operaciones recomendadas para mantener los datos ordenados.

## 1. Ingreso y cuentas

Al abrir la aplicación, ingresa el correo electrónico y la contraseña que te entregó el administrador. El registro público está deshabilitado: no se pueden crear cuentas desde la pantalla de inicio de sesión.

La primera cuenta administradora se configura al instalar el sistema mediante las variables de entorno `ADMIN_EMAIL` y `ADMIN_PASSWORD`. Si la base de datos ya contiene una cuenta con ese correo, se le asigna el rol de administrador y conserva su contraseña y datos actuales. Si no existe, el sistema crea la cuenta al iniciar. Después de crear la cuenta inicial, estas variables se pueden retirar del entorno; no cambian la contraseña de una cuenta ya creada.

Las cuentas nuevas que crea el administrador comparten los productos, sedes, categorías, unidades, carreras, asignaturas, facturas, clientes, bajas de inventario y préstamos de la organización. La dirección de correo de la sesión aparece en la barra superior. Selecciona **Cerrar sesión** para salir.

## 2. Navegación general

La barra lateral permite acceder a:

- **Panel:** indicadores generales y productos que requieren atención.
- **Inventario:** consulta, búsqueda, registro, edición y archivo de productos.
- **Dar de baja:** registro de retiros de existencias por producto, con historial de bajas anuladas.
- **Categorías y unidades:** administración de categorías, subcategorías y unidades de medida.
- **Control de sedes:** administración de las sedes utilizadas por productos y préstamos.
- **Carreras y asignaturas:** administración del catálogo académico asociado a los préstamos.
- **Facturas:** registro y administración de facturas por RUT de proveedor y número.
- **Clientes:** registro de personas que pueden solicitar préstamos.
- **Préstamos:** registro de préstamos, seguimiento y devoluciones.
- **Historial de préstamos:** consulta de préstamos activos y eliminados.
- **Manual de usuario:** consulta esta guía desde la aplicación.
- **Usuarios:** visible solo para administradores; permite crear cuentas de acceso y consultar las cuentas de la organización.

Las opciones **Proveedores**, **Pedidos** e **Informes** aparecen deshabilitadas; todavía no son vistas operativas.

## 3. Usuarios (solo administradores)

La vista **Usuarios** permite crear cuentas para las personas autorizadas a usar StockFlow. No permite crear otros administradores: las cuentas creadas desde esta vista tienen rol de usuario y comparten los datos de la organización.

### Crear una cuenta

1. Ingresa el correo electrónico de la persona.
2. Define una contraseña inicial de al menos 10 caracteres.
3. Selecciona **Crear usuario**.
4. Comunica el correo y la contraseña por un canal privado y seguro.

La lista muestra el correo electrónico, rol y fecha de creación de las cuentas. Si el correo ya existe, el sistema informará que no se puede duplicar.

La contraseña se almacena como hash y no se vuelve a mostrar en la aplicación. Por eso, verifica cuidadosamente la contraseña inicial antes de crear la cuenta y no la envíes por canales públicos.

## 4. Panel

El panel reúne un resumen del inventario y una lista de productos que requieren atención.

### Indicadores

- **Unidades totales:** suma de las existencias de los productos activos.
- **Existencias bajas:** cantidad de productos cuyas existencias son iguales o inferiores a su nivel de reposición.
- **Valor del inventario:** suma del precio de cada producto multiplicado por sus existencias. Los valores se muestran en pesos chilenos (CLP), sin decimales.
- **Ventas mensuales:** el valor y su porcentaje de variación son datos de demostración; no se calculan a partir de ventas reales.

### Requiere atención

Muestra hasta cuatro productos que están en o por debajo de su nivel de reposición. La etiqueta **Reponer** es una alerta para revisar; no crea una orden de compra.

### Registro de movimientos y estado del almacén

Los movimientos de ejemplo y el indicador visual de **92%** son contenido ilustrativo, no un registro real de actividad ni una medición calculada del inventario.

**Uso recomendado:** revisa las existencias bajas y abre **Inventario** para confirmar el stock, el nivel de reposición y la sede del producto.

## 5. Inventario

La vista contiene dos pestañas:

- **Productos registrados:** tabla de productos activos.
- **Registrar un producto:** formulario para crear un producto o editar uno existente.

La barra de búsqueda superior filtra en tiempo real por nombre, código de barras, categoría, subcategoría, unidad, código interno, características, descripción, sede, proveedor, estado y calidad. También puedes combinar la búsqueda con filtros de categoría, sede y nivel de existencias. La búsqueda no distingue mayúsculas ni acentos gráficos. El contador indica cuántos productos coinciden; estos filtros solo afectan la lista, no modifican ni eliminan registros.

Sobre la tabla puedes **Exportar a Excel**, descargar una **plantilla** o **Importar Excel**. La exportación incluye todos los productos de la organización, también los archivados, y no depende de la búsqueda ni de los filtros. La planilla acepta archivos `.xlsx` de hasta 5 MB y 500 filas de datos. Cada fila debe usar una sede, categoría, subcategoría (si corresponde) y unidad existentes en sus catálogos. El código de barras es opcional, pero no puede repetirse. Los productos importados no necesitan imagen; puedes agregarla después editando el producto.

La importación crea productos nuevos; no actualiza los existentes. El código interno se genera automáticamente y no se usa el código interno de la planilla. Las columnas `Archivado` y `Fungible` aceptan Sí/No o verdadero/falso. Ingresa cantidades y precios como números, y conserva el código de barras en formato texto para no perder ceros iniciales. Si alguna fila contiene datos inválidos o duplicados, no se importa ninguna fila: el mensaje indica los números de fila que debes corregir. Completa la plantilla descargada sin cambiar los encabezados requeridos.

Las alertas automáticas de inventario se envían a los correos de clientes registrados en las áreas **Pañolero** o **Administración**. Para activarlas, registra esos clientes y configura los datos SMTP en el servidor (`SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_FROM` y, si el servidor los exige, `SMTP_USER` y `SMTP_PASSWORD`); luego reinicia StockFlow. En la primera actualización que incluya esta función, se notificará una vez el stock bajo o cero que ya exista. Después, se envía un correo cuando un producto activo pasa de existencias adecuadas a stock bajo, y otro si llega a cero. Mientras permanezca bajo o sin existencias no se repiten; al superar el nivel de reposición se considera recuperado y podrá generar una nueva alerta si vuelve a caer. Las alertas se generan automáticamente al crear o cambiar existencias o el nivel de reposición, incluso en préstamos, devoluciones, bajas e importaciones. Si aún no hay destinatarios registrados, la alerta queda pendiente; si el proveedor SMTP rechaza un envío, se reintenta y el error queda en los registros del servidor.

### Tabla de productos

Cada fila muestra:

- **Producto:** nombre, código interno generado por el sistema, imagen y, cuando estén disponibles, características y descripción.
- **Código de barras:** código opcional asignado al producto.
- **Categoría:** categoría y subcategoría, si se asignó una.
- **Sede:** ubicación del producto.
- **Existencias:** cantidad registrada actualmente.
- **Unidad:** unidad de medida con que se expresa la cantidad.
- **Precio:** precio unitario informado al registrar el producto.
- **Nivel de existencias:** indica **Existencias bajas** si el stock es igual o menor que el nivel de reposición; de lo contrario, indica **Nivel adecuado**.
- **Estado:** Disponible, En reparación, En préstamo o Dado de baja.
- **Calidad:** Excelente, Buena, Regular o Mala.
- **Fungible:** indica si el producto es consumible.
- **Proveedor:** proveedor asociado al producto.
- **Acciones:** permite editar o archivar un producto.

### Registrar o editar un producto

Selecciona **Registrar un producto** y completa los campos:

- **Nombre del producto:** nombre reconocible para la búsqueda y los préstamos.
- **Código de barras (opcional):** puedes escribirlo, usar un lector USB que actúe como teclado o escanearlo con la cámara. Los códigos no vacíos deben ser únicos dentro de la cuenta.
- **Imagen:** al crear el producto se requiere una imagen JPEG, PNG o WebP de hasta 2 MB. Al editar, puedes conservar la imagen actual o seleccionar otra.
- **Características del producto:** datos técnicos breves, por ejemplo, material o dimensiones.
- **Descripción del producto:** explicación más amplia del producto o de su uso.
- **Sede:** ubicación a la que pertenece. Solo se pueden incluir en un préstamo productos de la misma sede del préstamo.
- **Categoría:** clasificación principal creada en **Categorías y unidades**.
- **Subcategoría (opcional):** clasificación dependiente de la categoría seleccionada.
- **Unidad de medida:** forma en que se registra el stock, como unidades, metros o litros.
- **Existencias:** cantidad actual. Debe ser un número entero igual o mayor que cero.
- **Nivel de reposición:** umbral para marcar el producto con existencias bajas. La alerta se activa cuando el stock es igual o inferior a este valor.
- **Precio:** precio por unidad; se muestra como CLP.
- **Proveedor:** nombre del proveedor asociado.
- **Fungible / consumible:** activa esta opción para productos que se consumen y no se devuelven. Los productos fungibles no requieren fecha límite de devolución en un préstamo.
- **Estado del producto:** condición operativa. Los productos en reparación o dados de baja no se pueden prestar; un producto archivado tampoco se puede prestar.
- **Calidad del producto:** evaluación del estado de calidad según las opciones disponibles.

Presiona **Guardar producto**. Para editar, usa **Editar** en la fila: el formulario se abrirá con los valores actuales. Presiona **Guardar cambios** para aplicar la modificación o **Cancelar edición** para descartar la edición en curso.

### Escaneo de código de barras

Presiona **Escanear con cámara** y concede permiso cuando el navegador lo solicite. Apunta la cámara al código; al detectarlo, el valor se copia al campo y la cámara se detiene. Puedes detenerla manualmente con **Detener cámara**.

El escaneo requiere un navegador compatible con `BarcodeDetector` y una conexión segura mediante HTTPS o `localhost`. Si la cámara o el navegador no son compatibles, ingresa el código manualmente o conecta un lector USB. La imagen de la cámara se procesa en el navegador; no se envía a un servicio externo.

### Archivar y restaurar productos

**Archivar** retira el producto del inventario activo sin borrar su registro ni su historial. Los productos archivados dejan de estar disponibles para nuevos préstamos.

Usa **Ver archivados** para consultar esos registros. En esa vista puedes **Restaurar** un producto para que vuelva al inventario activo. Mientras consultas archivados, la pestaña para registrar productos se oculta; usa **Ver productos activos** para volver a la lista normal.

**Uso eficiente:** configura primero categorías, unidades y sedes; luego registra productos con nombres consistentes, una ubicación correcta y un nivel de reposición realista. Así las búsquedas, los préstamos y las alertas serán más útiles.

### Dar de baja existencias

En **Dar de baja** registra el retiro de unidades de un producto. Selecciona su código interno; el sistema muestra la bodega, que corresponde a la sede asignada al producto. Completa la fecha, ubicación, cantidad y razón; la observación es opcional. La cantidad no puede superar las existencias disponibles y se descuenta del inventario al guardar.

En la tabla puedes **Modificar** una baja activa. Si cambias el producto o la cantidad, el sistema revierte el descuento anterior y aplica el nuevo en una sola transacción. **Eliminar** anula el movimiento, restituye las existencias y conserva el registro como anulado. Usa **Ver bajas anuladas** para consultar esos registros; no se pueden editar ni eliminar nuevamente.

## 6. Categorías y unidades

Esta vista organiza las clasificaciones y opciones disponibles en el formulario de productos.

### Categorías y subcategorías

- **Agregar categoría:** escribe el nombre y selecciona **Agregar categoría**. Las categorías pueden representar grupos amplios de productos.
- **Agregar subcategoría:** selecciona primero la **Categoría principal**, ingresa el nombre y agrega la subcategoría. La subcategoría se ofrece al registrar productos que tengan seleccionada esa categoría.
- **Guardar:** cada nombre existente se puede editar directamente en la lista y guardar con el botón correspondiente.
- **Eliminar categoría / Eliminar:** elimina una categoría o subcategoría cuando ya no está asignada a productos. Si aún está en uso, primero actualiza los productos afectados.

Mantén un criterio común para evitar categorías duplicadas con diferencias menores de escritura.

### Unidades de medida

- **Agregar unidad de medida:** escribe el nombre y selecciona **Agregar unidad de medida**.
- **Guardar:** cambia el nombre de una unidad existente. El cambio también se refleja en los productos que la usan.
- **Eliminar:** solo se permite si la unidad no está asignada a productos y queda al menos una unidad disponible.

El catálogo inicial incluye unidades como Metros, Unidades, Litros, Kilos y Gramos. Administra aquí las opciones que necesites antes de registrar productos.

## 7. Control de sedes

La lista muestra las sedes disponibles y si cada una está asignada a productos o préstamos.

- **Agregar sede:** ingresa el nombre y selecciona **Agregar sede**.
- **Cambiar nombre:** edita el nombre en la lista y selecciona **Guardar**. La sede conserva su identidad y asignaciones.
- **Eliminar:** solo se puede eliminar una sede sin asignaciones. Debe quedar al menos una sede en el catálogo.

El catálogo inicial incluye sedes de Duoc UC y la opción **Sede por asignar**, que puede aparecer para datos migrados. Asigna los productos existentes a su sede real desde **Inventario**. Una sede con productos o préstamos asignados no se puede eliminar.

**Uso recomendado:** registra y revisa las sedes antes de ingresar productos. Al registrar un préstamo, elige la sede donde está asignado el producto; la aplicación limita la selección de productos a esa sede.

## 8. Carreras y asignaturas

Esta vista permite mantener el catálogo académico de la sede Plaza Oeste que se puede asociar a los préstamos. El catálogo comienza vacío para ingresar las carreras vigentes verificadas por la organización; también puedes administrar sus asignaturas desde esta vista.

- **Agregar carrera:** escribe el nombre y selecciona **Agregar carrera**.
- **Agregar asignatura:** selecciona la carrera, escribe el nombre de la asignatura y agrégala. Cada asignatura pertenece a una carrera.
- **Guardar:** edita el nombre directamente en la lista y guarda el cambio.
- **Eliminar asignatura:** se permite si la asignatura no está vinculada a un préstamo.
- **Eliminar carrera:** elimina la carrera y sus asignaturas cuando no están vinculadas a préstamos. Si una carrera o asignatura ya se usó, conserva la relación histórica y no se podrá eliminar.

Los nombres duplicados no se aceptan dentro del mismo catálogo; una asignatura puede repetirse en carreras distintas. Las carreras y asignaturas se comparten entre las cuentas de la organización.

## 9. Facturas

La vista **Facturas** permite registrar las facturas existentes y mantener una lista consultable por organización. Cada registro contiene únicamente:

- **RUT del proveedor:** se valida mediante el dígito verificador y se guarda con el formato chileno estándar.
- **Número de factura:** hasta 100 caracteres. No se puede repetir el mismo número para el mismo proveedor; el mismo número puede pertenecer a otro RUT.

Para registrar una factura, completa ambos campos y selecciona **Registrar factura**. La búsqueda superior encuentra registros por RUT de proveedor o número de factura; también puedes filtrar por proveedor. En la tabla puedes seleccionar **Editar** para actualizar los datos o **Eliminar** para borrar el registro tras confirmar la acción. El registro no se asocia a productos, compras ni movimientos de inventario.

## 10. Clientes

En **Clientes** puedes crear, consultar, editar y eliminar personas que solicitarán préstamos. Cada cliente tiene nombre, RUT chileno válido, correo electrónico y un área base: **Estudiante**, **Profesor**, **Administración** o **Pañolero**. El RUT se normaliza al formato estándar y no se puede repetir dentro de la organización.

La búsqueda superior filtra por nombre, RUT, correo o área; el selector permite limitar la lista a un área específica. El contador muestra los resultados coincidentes.

Usa **Exportar a Excel** para descargar todos los clientes o **Descargar plantilla** para obtener una planilla vacía con los encabezados requeridos: `Nombre`, `RUT`, `Correo` y `Área`. Para cargarla, selecciona **Importar Excel** y elige un archivo `.xlsx` de hasta 5 MB y 500 filas de datos. La importación valida el RUT y correo, acepta solo las áreas indicadas y no permite RUT repetidos. Agrega clientes nuevos; no actualiza fichas existentes. Si una fila es inválida o contiene un RUT ya registrado, no se importa ninguna fila y se indican los errores por número de fila.

Al registrar un préstamo, puedes seleccionar un cliente existente para completar automáticamente su RUT y área. La selección es opcional: también se permite ingresar manualmente los datos de una persona sin crear su ficha. El nombre del cliente y los datos de RUT y área quedan asociados al préstamo para identificarlos en las vistas de préstamos e historial. Si editas la ficha posteriormente, los préstamos anteriores conservan los datos que tenían al momento de registrarse. No se puede eliminar un cliente vinculado a préstamos, para preservar la referencia histórica.

## 11. Préstamos

La vista tiene dos pestañas: **Préstamos registrados** y **Registrar un préstamo**.

### Registrar un préstamo

Completa los datos generales:

- **Sede del préstamo:** sede a la que pertenece la operación.
- **Jornada:** selecciona **Diurna** o **Vespertina**. La jornada sirve para filtrar y dar seguimiento a los préstamos; no separa el inventario.
- **Fecha del préstamo:** fecha en que se realiza.
- **Hora de inicio:** hora en que se entrega el préstamo.
- **Fecha límite de devolución:** obligatoria si se incluye al menos un producto reutilizable. No puede ser anterior a la fecha del préstamo.
- **Hora de término:** hora límite de devolución en la fecha límite. Si el préstamo inicia y termina el mismo día, debe ser posterior a la hora de inicio.
- **Colaborador / RUT del estudiante:** persona responsable del préstamo.
- **Área:** área asociada.
- **Cliente registrado (opcional):** selecciona un cliente para completar el RUT y el área; también puedes registrar los datos manualmente.
- **Carrera (opcional):** carrera a la que pertenece la persona o actividad.
- **Asignatura (opcional):** asignatura del catálogo correspondiente a la carrera seleccionada. Si no hay asignaturas registradas para esa carrera, el campo queda deshabilitado. Puedes registrar el préstamo sin asociar carrera o asignatura.

El RUT ingresado manualmente se valida con su dígito verificador y se guarda con el formato chileno estándar. Si seleccionas un cliente registrado, se utiliza el RUT validado de su ficha.

En **Productos incluidos en este préstamo**:

1. Selecciona un producto y la cantidad.
2. Usa **Agregar producto** para añadir otras líneas; cada línea puede llevar una cantidad propia.
3. Usa **Quitar** para retirar una línea. Debe quedar al menos una línea.
4. Revisa la disponibilidad indicada junto al selector y la cantidad.
5. Presiona **Registrar préstamo** para guardar.

Cada producto solo puede aparecer una vez en el mismo préstamo. El sistema impide seleccionar productos sin existencias, archivados, en reparación o dados de baja, y no permite exceder el stock disponible. Todos los productos deben corresponder a la sede elegida. El stock se descuenta al registrar correctamente el préstamo.

Los datos generales (persona, cliente, fechas y horas, sede, área, carrera y asignatura) aplican a todas las líneas de ese préstamo. La hora de término, junto con la fecha límite, determina cuándo el préstamo pasa a vencido. Los estados de vencimiento se actualizan automáticamente mientras la vista está abierta. Los préstamos existentes conservan el texto de asignatura que tenían; no se les asigna automáticamente una carrera o una asignatura del nuevo catálogo. Un producto fungible queda registrado como consumido y no requiere devolución; para uno reutilizable, se requiere una fecha límite.

### Préstamos registrados y devoluciones

La tabla agrupa las líneas del mismo préstamo y muestra:

- sede, jornada, inicio del préstamo, término o vencimiento, fecha y hora de registro, cliente, RUT, área, carrera y asignatura;
- código y nombre del producto de cada línea;
- cantidad prestada, cantidad devuelta y cantidad pendiente;
- controles para registrar una devolución y eliminar el préstamo.

Usa los filtros **Jornada** y **Seguimiento de devolución** para localizar préstamos vespertinos, vigentes, vencidos o próximos a vencer. Un préstamo vence al pasar la hora de término en la fecha límite; si no se registró hora en una ficha histórica, se considera vencido al finalizar ese día. Se consideran próximos a vencer los préstamos con devolución pendiente cuyo vencimiento está dentro de los próximos siete días. Los vencidos y los que vencen hoy se resaltan en la lista. El aviso sobre la jornada vespertina resume cuántos préstamos están vencidos o próximos a vencer.

La búsqueda superior permite localizar préstamos por número, fecha, cliente, RUT, área, carrera, asignatura, sede o producto. Se puede combinar con los filtros de jornada y seguimiento; el contador muestra cuántos préstamos coinciden.

Para registrar una devolución, ingresa una cantidad positiva que no supere lo pendiente y presiona **Devolver**. Se admite devolver en varias partes. Al registrar la devolución, las existencias del producto se actualizan.

Las líneas fungibles muestran **Consumido** en vez de un control de devolución. Cuando ya no quedan unidades pendientes de una línea reutilizable, aparece **Completado**.

### Eliminar un préstamo

La opción **Eliminar préstamo** solicita confirmación. El registro no se borra definitivamente: se conserva en **Historial de préstamos**. Las unidades reutilizables que seguían pendientes se reintegran al inventario y quedan reflejadas como reintegradas en el historial. No uses esta acción como sustituto de registrar una devolución normal cuando la devolución sí ocurrió; registra primero la devolución correspondiente.

## 12. Historial de préstamos

Esta vista conserva las líneas de los préstamos activos y eliminados. Muestra la sede, jornada, fechas y horas de inicio y término, cliente y responsable, área, asignatura, producto, cantidad prestada y devuelta, unidades reintegradas al eliminar, estado y fecha de eliminación. Los préstamos existentes antes de agregar la jornada aparecen como **Sin especificar**; los registros históricos sin hora mantienen el vencimiento al final del día.

Estados habituales:

- **Vigente:** quedan unidades reutilizables por devolver y aún no ha pasado la fecha y hora límite.
- **Completado:** todas las unidades reutilizables se devolvieron.
- **Consumido:** la línea corresponde a un producto fungible.
- **Eliminado:** el préstamo se trasladó al historial mediante la acción de eliminación.

El historial sirve para consultar movimientos anteriores y verificar qué cantidades se devolvieron o reintegraron. La acción de eliminación desde **Préstamos** no elimina el registro de este historial.

## 13. Flujo de trabajo sugerido

1. Inicia sesión con una cuenta creada por el administrador.
2. En **Categorías y unidades**, define categorías, subcategorías y unidades que se usarán.
3. En **Control de sedes**, confirma que estén las ubicaciones correctas.
4. En **Inventario**, registra los productos con su sede, clasificación, unidad, stock inicial y nivel de reposición.
5. Usa **Panel** y la búsqueda de **Inventario** para revisar alertas y localizar productos.
6. En **Préstamos**, registra la persona, sede, fecha límite cuando corresponda y todas las líneas de productos.
7. Registra cada devolución en la vista de préstamos y consulta **Historial de préstamos** cuando necesites revisar operaciones previas.

## 14. Mensajes y problemas comunes

- **Código de barras duplicado:** revisa el inventario; los códigos no vacíos deben ser únicos por cuenta.
- **No se puede eliminar una sede:** está asignada a un producto o préstamo, o es la última sede. Reasigna o conserva los registros, y mantén al menos una sede.
- **No se puede eliminar una categoría, subcategoría o unidad:** está asignada a uno o más productos. Cambia primero la clasificación o unidad del producto.
- **No se puede prestar el producto:** confirma que pertenece a la sede seleccionada, que está activo, que su estado permite préstamos y que las existencias alcanzan para la cantidad solicitada.
- **No se puede eliminar un cliente:** tiene préstamos asociados; conserva su ficha para mantener el historial.
- **No aparece la fecha límite como obligatoria:** se vuelve obligatoria cuando se agrega un producto reutilizable; no es necesaria si todas las líneas son fungibles.
- **No se puede escanear con cámara:** comprueba que abriste la aplicación mediante HTTPS o `localhost`, que el navegador es compatible y que tiene permiso para usar la cámara. Como alternativa, ingresa el código o usa un lector USB.
- **La imagen no se acepta:** usa JPEG, PNG o WebP y verifica que no supere 2 MB.
