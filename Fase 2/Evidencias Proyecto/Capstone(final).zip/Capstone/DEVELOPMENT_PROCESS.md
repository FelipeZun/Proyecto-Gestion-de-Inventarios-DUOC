# Stock Management Webpage: Development Process

## Starting point

The project began as a clean webpage implementation. The repository contained a short project README and no existing application structure, framework, or stock-management code. To keep the first version easy to run and extend, the page was built with plain HTML, CSS, and JavaScript, without adding dependencies or a backend.

## Initial static prototype

The first version used plain HTML, CSS, and JavaScript. It introduced the dashboard layout, responsive styling, inventory summary cards, search, watchlist, and a temporary in-memory quick-add form.

## Database-backed application

The prototype was extended with an Express server and PostgreSQL. Accounts are authenticated with bcrypt-hashed passwords and server-side sessions. Each account can only access its own inventory.

The Inventory page supports creating, editing, and deleting product records. Each successful operation is written to PostgreSQL, and dashboard totals and low-stock information are recalculated from the saved inventory.

## Current file responsibilities

- `server.js` — Authentication, sessions, PostgreSQL schema initialization, and product API routes.
- `public/index.html` — Dashboard, inventory-management view, and account forms.
- `styles.css` — Visual design and responsive behavior.
- `script.js` — API requests, inventory rendering/search, and create/edit/delete interactions.
- `README.md` — Project overview and local run instructions.
- `test/product-validation.test.js` — Product input and identifier validation tests.

## Current behavior and boundaries

Product records are persistent and scoped to the signed-in user. The database tables are initialized when the server starts. Monthly sales, warehouse health, suppliers, orders, reports, export, and the recent activity entries remain illustrative and are not connected to live data.

## Run locally

Configure `DATABASE_URL` in `.env`, then run:

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000) in a browser. See [README.md](./README.md) for the full setup instructions.

## Possible next steps

1. Add stock movement history and populate the activity log from real operations.
2. Connect supplier, order, report, sales, and export interfaces to real data.
3. Add end-to-end tests for account isolation and database-backed inventory workflows.
