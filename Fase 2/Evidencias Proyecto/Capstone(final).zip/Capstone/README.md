# Capstone

StockFlow es un panel de gestión de inventario con cuentas de usuario y una base de datos PostgreSQL.

Consulta el [Manual de usuario](./MANUAL-USUARIO.md) para conocer las vistas, campos y flujos de trabajo de la aplicación.

El JavaScript del navegador usa módulos ECMAScript nativos, sin proceso de compilación. `public/script.js` coordina la aplicación; `api.js` reúne utilidades y solicitudes HTTP; `barcode-scanner.js`, `admin-users.js` y `loan-tracking.js` aíslan sus respectivas funcionalidades.

## Requisitos

- Node.js 18 o una versión posterior
- PostgreSQL con una base de datos llamada `stockflow`

## Configuración e inicio

1. Instala las dependencias:

   ```bash
   npm install
   ```

2. Configura `DATABASE_URL`, `SESSION_SECRET` y las credenciales de la cuenta administradora inicial en el archivo local `.env`. Usa `.env.example` como referencia:

   ```env
   DATABASE_URL=postgres://usuario:contraseña@localhost:5432/stockflow
   SESSION_SECRET=reemplaza-esto-por-un-secreto-largo-y-aleatorio
   ADMIN_EMAIL=admin@tu-organizacion.cl
   ADMIN_PASSWORD=una-contraseña-inicial-segura
   SMTP_HOST=smtp.tu-organizacion.cl
   SMTP_PORT=587
   SMTP_SECURE=false
   SMTP_USER=usuario-smtp
   SMTP_PASSWORD=contraseña-smtp
   SMTP_FROM=StockFlow <stockflow@tu-organizacion.cl>
   ```

   Codifica los caracteres especiales de la contraseña para usarlos en la URL. Mantén privado el archivo `.env`; Git lo ignora. Las variables SMTP son necesarias para enviar las alertas de stock; `SMTP_USER` y `SMTP_PASSWORD` se pueden dejar vacías si el servidor permite relay sin autenticación. Para conexiones TLS implícitas normalmente se usa el puerto 465 y `SMTP_SECURE=true`; para STARTTLS suele usarse el puerto 587 y `SMTP_SECURE=false`.

3. Inicia el servidor:

   ```bash
   npm start
   ```

4. Inicia sesión con la cuenta administradora configurada. El registro público está deshabilitado: solo el administrador puede crear cuentas desde la vista **Usuarios**. Las cuentas creadas por el administrador comparten los datos de inventario, sedes, categorías, carreras, asignaturas, facturas, clientes, bajas y préstamos de la organización. Guarda las credenciales iniciales en un lugar seguro y comunícalas a cada usuario por un canal privado. En **Inventario** puedes registrar productos, editar sus datos o existencias y archivarlos o restaurarlos sin perder su historial de préstamos. Los productos archivados no aparecen en el inventario activo y no se pueden prestar. Para registrar un producto nuevo, se requiere una imagen JPEG, PNG o WebP de hasta 2 MB; las imágenes se almacenan en PostgreSQL. Los productos también incluyen un código de barras opcional, que puedes ingresar manualmente, leer con un lector USB o escanear con la cámara. El escaneo utiliza `BarcodeDetector` del navegador y no envía imágenes a servicios externos; requiere HTTPS o `localhost` y un navegador compatible. Los códigos de barras no vacíos deben ser únicos por organización. Los productos incluyen además características y descripción, una sede administrada en **Control de sedes**, una categoría y una subcategoría opcional administradas en **Categorías y unidades**, una unidad de medida administrada en la misma vista (se incluyen Metros, Unidades, Litros, Kilos y Gramos), una opción para indicar si son fungibles, un estado (Disponible, En reparación, En préstamo o Dado de baja) y una calidad (Excelente, Buena, Regular o Mala). El catálogo inicial de sedes incluye ubicaciones de Duoc UC y puede personalizarse por organización. Las sedes asignadas a productos o préstamos no se pueden eliminar y debe conservarse al menos una.

   En **Carreras y asignaturas** puedes crear y editar carreras y sus asignaturas para el catálogo académico de la sede Plaza Oeste. El catálogo se crea vacío para que agregues las carreras vigentes verificadas por la organización. En **Facturas** puedes registrar, editar y eliminar facturas existentes indicando el RUT verificado del proveedor y su número. El número de factura debe ser único para el mismo proveedor; el registro no se asocia a productos ni modifica el inventario. En **Clientes** puedes crear, editar y eliminar personas con nombre, RUT chileno verificado, correo y área base (Estudiante, Profesor, Administración o Pañolero); los clientes vinculados a préstamos no se eliminan para conservar el historial. En el formulario de préstamo puedes elegir uno para completar el RUT y el área, o ingresar los datos manualmente. El nombre y los datos del cliente quedan guardados como referencia histórica del préstamo. En **Dar de baja** puedes registrar una salida de existencias por código de producto; el sistema guarda la sede del producto como bodega, descuenta la cantidad disponible y permite modificar o anular la baja. Al anularla, las unidades se restituyen y el registro permanece en el historial de anuladas. En **Préstamos** puedes registrar un préstamo para una persona con varias líneas de productos, cada una con su propia cantidad, y asociarlo opcionalmente a una carrera y asignatura. Cada préstamo pertenece a una sede y solo puede incluir productos asignados a esa misma sede. La fecha y hora del préstamo, la fecha de devolución, el RUT, el área, la carrera y la asignatura son compartidos por todas las líneas. Si se selecciona algún producto reutilizable, la fecha de devolución es obligatoria. Las existencias de todas las líneas se descuentan en una sola transacción y cada línea reutilizable se puede devolver de forma parcial o completa. Los productos fungibles se marcan como consumidos y no requieren una devolución. Al eliminar un préstamo, las unidades reutilizables pendientes se reintegran al inventario y el préstamo se marca como eliminado en lugar de borrarse físicamente. El **Historial de préstamos** muestra todas las líneas de productos de los préstamos activos y eliminados, incluida su sede, carrera, asignatura, fecha de eliminación y cantidad de unidades pendientes reintegradas.

   Las alertas de stock bajo y sin existencias se envían automáticamente a los correos de las fichas de **Clientes** cuya área sea **Pañolero** o **Administración**. Registra primero esas fichas y configura las variables SMTP antes de iniciar el servidor. La primera vez también se notificará una vez el stock bajo o cero ya existente. Se envía un correo al pasar de un nivel adecuado a stock bajo y otro si llega a cero; no se repiten mientras continúe la alerta. Al superar el nivel de reposición, el sistema considera recuperado el producto y podrá notificar una nueva caída. Los avisos se generan al crear o cambiar las existencias o el nivel de reposición, incluidos préstamos, devoluciones, bajas e importaciones. Se guardan en una cola de PostgreSQL, se reintentan ante fallos de envío y los errores se muestran en los registros del servidor.

Las tablas de usuarios, sedes, productos, categorías, subcategorías, unidades de medida, carreras, asignaturas, facturas, clientes, bajas de inventario, préstamos, líneas de préstamo y sesiones se crean automáticamente al conectarse el servidor a PostgreSQL. Las carreras y asignaturas comienzan vacías; las categorías y unidades existentes de los productos se migran a los catálogos de cada cuenta. Los productos y préstamos existentes se asignan inicialmente a **Sede por asignar** para conservar sus datos; puedes cambiar la sede del producto desde Inventario. Los préstamos existentes conservan su asignatura como texto y no reciben una carrera o asignatura del nuevo catálogo automáticamente. Los préstamos existentes de un solo producto se migran a líneas individuales sin perder su historial de devoluciones o eliminaciones. Los préstamos eliminados antes de instalar la función de historial se borraron físicamente y no se pueden recuperar; los que existían durante la migración y los eliminados desde entonces se conservan en el historial.

Al registrar un préstamo, selecciona su jornada **Diurna** o **Vespertina**. La jornada no crea inventarios separados: solo permite filtrar los préstamos y monitorear sus devoluciones. Los préstamos con devolución pendiente vencida o dentro de los próximos siete días se destacan; los registros anteriores a esta función quedan como **Sin especificar**.

Las cuentas nuevas creadas por el administrador acceden a los datos compartidos de la organización; sus contraseñas se almacenan como hashes bcrypt. En una base existente, configura como `ADMIN_EMAIL` una cuenta ya existente para promoverla a administradora y conservar sus datos. Si el correo no existe, el servidor crea la cuenta inicial usando `ADMIN_PASSWORD`. Una vez creada la primera cuenta administradora, puedes quitar estas dos variables del entorno; no se restablecerá la contraseña del administrador en reinicios. Las cuentas existentes que no se promuevan conservan su propio espacio de datos. Archivar un producto conserva su registro y su historial de préstamos.

Ejecuta las pruebas de validación con:

```bash
npm test
```

En producción, configura un `SESSION_SECRET` único y extenso, habilita HTTPS y utiliza un rol de PostgreSQL dedicado con solo los permisos necesarios para la aplicación, en lugar de la cuenta administradora de la base de datos.
