const ExcelJS = require('exceljs');

const MAX_IMPORT_ROWS = 500;
const MAX_IMPORT_BYTES = 5 * 1024 * 1024;
const SPREADSHEET_MIME_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

const IMPORT_COLUMNS = {
  clients: [
    { header: 'Nombre', key: 'name', required: true },
    { header: 'RUT', key: 'rut', required: true },
    { header: 'Correo', key: 'email', required: true },
    { header: 'Área', key: 'area', required: true }
  ],
  products: [
    { header: 'Nombre', key: 'name', required: true },
    { header: 'Código de barras', key: 'barcode' },
    { header: 'Sede', key: 'campus', required: true },
    { header: 'Categoría', key: 'category', required: true },
    { header: 'Subcategoría', key: 'subcategory' },
    { header: 'Unidad de medida', key: 'unitOfMeasure', required: true },
    { header: 'Existencias', key: 'stock', required: true },
    { header: 'Nivel de reposición', key: 'reorderLevel', required: true },
    { header: 'Precio', key: 'price', required: true },
    { header: 'Proveedor', key: 'supplier', required: true },
    { header: 'Fungible', key: 'isConsumable' },
    { header: 'Estado', key: 'state' },
    { header: 'Calidad', key: 'quality' },
    { header: 'Características', key: 'characteristics' },
    { header: 'Descripción', key: 'description' },
    { header: 'Archivado', key: 'isArchived' }
  ]
};

function normalizeHeader(value) {
  return String(value ?? '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('es')
    .replace(/[^a-z0-9]/g, '');
}

function readCell(cell, rowNumber) {
  const value = cell.value;
  if (value && typeof value === 'object') {
    if ('formula' in value || 'sharedFormula' in value) {
      throw new Error(`La fila ${rowNumber} contiene fórmulas; reemplázalas por valores antes de importar.`);
    }
    if ('richText' in value) return value.richText.map((item) => item.text).join('');
    if ('text' in value && ('hyperlink' in value || 'tooltip' in value)) return value.text;
    if (value instanceof Date) return value;
    throw new Error(`La fila ${rowNumber} contiene un tipo de celda no compatible.`);
  }
  return value;
}

async function readImportWorkbook(buffer, type) {
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
    throw new Error('Selecciona un archivo Excel .xlsx válido.');
  }
  if (buffer.length > MAX_IMPORT_BYTES) {
    throw new Error('El archivo Excel no puede superar 5 MB.');
  }
  if (!Object.hasOwn(IMPORT_COLUMNS, type)) {
    throw new Error('El tipo de planilla no es válido.');
  }

  const workbook = new ExcelJS.Workbook();
  try {
    await workbook.xlsx.load(buffer);
  } catch {
    throw new Error('No se pudo leer el archivo. Verifica que sea un Excel .xlsx válido y no esté dañado.');
  }

  const worksheet = workbook.worksheets[0];
  if (!worksheet || worksheet.rowCount < 1) throw new Error('La planilla está vacía.');
  if (worksheet.rowCount > MAX_IMPORT_ROWS * 10 + 1) {
    throw new Error(`La planilla supera el máximo de ${MAX_IMPORT_ROWS} filas de datos.`);
  }
  const columns = IMPORT_COLUMNS[type];
  const headerRow = worksheet.getRow(1);
  const headers = new Map();
  headerRow.eachCell({ includeEmpty: false }, (cell, columnNumber) => {
    const header = normalizeHeader(readCell(cell, 1));
    if (!header) return;
    if (headers.has(header)) throw new Error('La planilla contiene encabezados duplicados.');
    headers.set(header, columnNumber);
  });

  const columnIndexes = new Map();
  const missingHeaders = [];
  for (const column of columns) {
    const columnNumber = headers.get(normalizeHeader(column.header));
    if (columnNumber) columnIndexes.set(column.key, columnNumber);
    else if (column.required) missingHeaders.push(column.header);
  }
  if (missingHeaders.length) {
    throw new Error(`Faltan columnas requeridas: ${missingHeaders.join(', ')}.`);
  }

  const rows = [];
  worksheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
    if (rowNumber === 1) return;
    const record = {};
    let hasValue = false;
    for (const column of columns) {
      const columnNumber = columnIndexes.get(column.key);
      if (!columnNumber) continue;
      const value = readCell(row.getCell(columnNumber), rowNumber);
      record[column.key] = value;
      if (value !== null && value !== undefined && String(value).trim() !== '') hasValue = true;
    }
    if (hasValue) {
      rows.push({ rowNumber, record });
      if (rows.length > MAX_IMPORT_ROWS) {
        throw new Error(`La planilla supera el máximo de ${MAX_IMPORT_ROWS} filas de datos.`);
      }
    }
  });
  if (!rows.length) throw new Error('La planilla no contiene filas para importar.');
  return rows;
}

async function createWorkbook(type, records = null) {
  if (!Object.hasOwn(IMPORT_COLUMNS, type)) throw new Error('El tipo de planilla no es válido.');
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'StockFlow';
  workbook.created = new Date();
  const worksheet = workbook.addWorksheet(type === 'clients' ? 'Clientes' : 'Productos');
  const columns = [...IMPORT_COLUMNS[type]];
  if (type === 'products') {
    columns.push(
      { header: 'Código interno', key: 'code' }
    );
  }
  worksheet.columns = columns.map((column) => ({
    header: column.header,
    key: column.key,
    width: Math.min(Math.max(column.header.length + 4, 16), 32)
  }));
  worksheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFFFF' } };
  worksheet.getRow(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF335CFF' } };
  worksheet.views = [{ state: 'frozen', ySplit: 1 }];
  if (records) worksheet.addRows(records);
  return Buffer.from(await workbook.xlsx.writeBuffer());
}

module.exports = {
  IMPORT_COLUMNS,
  MAX_IMPORT_BYTES,
  MAX_IMPORT_ROWS,
  SPREADSHEET_MIME_TYPE,
  createWorkbook,
  readImportWorkbook
};
